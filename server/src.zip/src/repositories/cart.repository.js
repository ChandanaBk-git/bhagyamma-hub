const Cart = require("../models/cart.model");

const findCartByUser = async (userId) => {
  return await Cart.findOne({
    userId,
  }).populate("items.productId");
};

const findByUser = async (userId) => {
  return await findCartByUser(userId);
};

const createCart = async (cartData) => {
  return await Cart.create(cartData);
};

const saveCart = async (cart) => {
  return await cart.save();
};

const deleteCart = async (userId) => {
  return await Cart.findOneAndDelete({
    userId,
  });
};

const clearCart = async (userId) => {
  return await deleteCart(userId);
};

module.exports = {
  findCartByUser,
  findByUser,
  createCart,
  saveCart,
  deleteCart,
  clearCart,
};