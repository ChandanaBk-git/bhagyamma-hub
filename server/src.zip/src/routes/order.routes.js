const express = require("express");

const router =
  express.Router();

const controller =
  require("../controllers/order.controller");

const {
  protect,
  authorize,
} = require("../middleware/auth.middleware");

const validate =
  require("../middleware/validate.middleware");

const {
  updateOrderStatusValidation,
  guestOrderValidation,
} = require("../validations/order.validation");

/* ======================================================
   GUEST ORDER

   IMPORTANT:
   This route intentionally has NO protect middleware.

   Guests are allowed to create orders.
====================================================== */

router.post(
  "/guest",
  guestOrderValidation,
  validate,
  controller.placeGuestOrder
);

/* ======================================================
   MEMBER ORDER
====================================================== */

router.post(
  "/",
  protect,
  controller.placeOrder
);

/* ======================================================
   MEMBER ORDERS
====================================================== */

router.get(
  "/my-orders",
  protect,
  controller.getMyOrders
);

/* ======================================================
   ADMIN ORDERS
====================================================== */

router.get(
  "/",
  protect,
  authorize("ADMIN"),
  controller.getAllOrders
);

/* ======================================================
   ORDER DETAILS
====================================================== */

router.get(
  "/:id",
  protect,
  controller.getOrderById
);

/* ======================================================
   UPDATE ORDER STATUS
====================================================== */

router.patch(
  "/:id/status",
  protect,
  authorize("ADMIN"),
  updateOrderStatusValidation,
  validate,
  controller.updateOrderStatus
);

module.exports = router;