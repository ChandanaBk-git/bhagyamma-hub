const express = require("express");
const router = express.Router();

const controller = require("../controllers/product.controller");

const { protect } = require("../middleware/auth.middleware");
const authorize = require("../middleware/role.middleware");
const upload = require("../middleware/upload.middleware");

// ===================== PUBLIC =====================
router.get("/", controller.getAllProducts);
router.get("/:id", controller.getProductById);

// ===================== CREATE =====================
router.post(
  "/",
  protect,
  authorize("SUPER_ADMIN"),
  (req, res, next) => {
    console.log("🔥 Route reached before multer");
    next();
  },
  upload.array("images", 5),
  (req, res, next) => {
    console.log("🔥 After multer");
    console.log(req.files);
    next();
  },
  controller.createProduct
);

// ===================== UPDATE =====================
router.put(
  "/:id",
  protect,
  authorize("SUPER_ADMIN"),
  upload.array("images", 5),
  (req, res, next) => {
    console.log("========== UPDATE ==========");
    console.log("BODY:", req.body);
    console.log("FILES:", req.files);
    console.log("============================");
    next();
  },
  controller.updateProduct
);

// ===================== DELETE =====================
router.delete(
  "/:id",
  protect,
  authorize("SUPER_ADMIN"),
  controller.deleteProduct
);

module.exports = router;