const { body } = require("express-validator");

const categoryValidation = [
    body("name")
        .trim()
        .notEmpty()
        .withMessage("Category name is required")
        .isLength({ min: 3 })
        .withMessage("Category name must be at least 3 characters"),
];

module.exports = {
    categoryValidation,
};