const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const compression = require("compression");
const cookieParser = require("cookie-parser");
const morgan = require("morgan");
const path = require("path");
const fs = require("fs");
const routes = require("./routes");
const notFound = require("./middleware/notFound.middleware");
const errorMiddleware = require("./middleware/error.middleware");
const productRoutes = require("./routes/product.routes");
const app = express();




/* ------------------------- Security Middleware ------------------------- */

app.use(
  cors({
    origin: [
      "http://localhost:5173",
      "https://bhagyamma-hub-sigma.vercel.app",
    ],
    credentials: true,
  })
);

app.use(
  helmet({
    crossOriginResourcePolicy: false,
  })
);

/* -------------------------- Body Parsers -------------------------- */

app.use(
    express.json({
        limit: "10mb",
    })
);

app.use("/api/products", productRoutes);

app.use(
    express.urlencoded({
        extended: true,
        limit: "10mb",
    })
);

app.use(cookieParser());

/* ------------------------- Performance ------------------------- */

app.use(compression());

/* ---------------------------- Logging ---------------------------- */

app.use(morgan("dev"));

/* --------------------------- Health Check --------------------------- */

app.get("/", (req, res) => {
    res.status(200).json({
        success: true,
        message: "Bhagyamma Hub API Running",
        version: "v1",
    });
});

app.use(
  "/uploads",
  express.static(path.join(__dirname, "../uploads"))
);

app.get("/uploads/products/:filename", (req, res, next) => {
  const uploadDir = path.join(__dirname, "../uploads", "products");

  const requestedFile = req.params.filename;

  if (!fs.existsSync(uploadDir)) {
    return next();
  }

  const files = fs.readdirSync(uploadDir);
  const exactMatch = files.find((file) => file === requestedFile);

  if (exactMatch) {
    return res.sendFile(path.join(uploadDir, exactMatch));
  }

  const baseName = path.parse(requestedFile).name;
  const fallbackMatch = files.find(
    (file) => path.parse(file).name === baseName
  );

  if (fallbackMatch) {
    return res.sendFile(path.join(uploadDir, fallbackMatch));
  }

  return next();
});

app.get("/health", (req, res) => {
    res.status(200).json({
        success: true,
        status: "UP",
        timestamp: new Date().toISOString(),
    });
});

/* ---------------------------- API Routes ---------------------------- */

app.use("/api/v1", routes);

/* ------------------------- Error Handling ------------------------- */

app.use(notFound);

app.use(errorMiddleware);

module.exports = app;