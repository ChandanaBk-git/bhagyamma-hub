const asyncHandler = require("../utils/asyncHandler");

const ApiResponse = require("../utils/ApiResponse");

const orderService = require("../services/order.service");

/* ==========================================
   MEMBER PLACE ORDER
========================================== */

const placeOrder =
  asyncHandler(
    async (
      req,
      res
    ) => {
      const order =
        await orderService.placeOrder(
          req.user.id,
          req.body
        );

      return res
        .status(201)
        .json(
          new ApiResponse(
            201,
            "Order created successfully",
            order
          )
        );
    }
  );

/* ==========================================
   GUEST PLACE ORDER
========================================== */

const placeGuestOrder =
  asyncHandler(
    async (
      req,
      res
    ) => {
      const order =
        await orderService.placeGuestOrder(
          req.body
        );

      return res
        .status(201)
        .json(
          new ApiResponse(
            201,
            "Guest order created successfully",
            order
          )
        );
    }
  );

/* ==========================================
   MY ORDERS
========================================== */

const getMyOrders =
  asyncHandler(
    async (
      req,
      res
    ) => {
      const orders =
        await orderService.getMyOrders(
          req.user.id
        );

      return res
        .status(200)
        .json(
          new ApiResponse(
            200,
            "Orders fetched successfully",
            orders
          )
        );
    }
  );

/* ==========================================
   ORDER DETAILS
========================================== */

const getOrderById =
  asyncHandler(
    async (
      req,
      res
    ) => {
      const order =
        await orderService.getOrderById(
          req.params.id,
          req.user.id
        );

      return res
        .status(200)
        .json(
          new ApiResponse(
            200,
            "Order fetched successfully",
            order
          )
        );
    }
  );

/* ==========================================
   ADMIN ORDERS
========================================== */

const getAllOrders =
  asyncHandler(
    async (
      req,
      res
    ) => {
      const orders =
        await orderService.getAllOrders();

      return res
        .status(200)
        .json(
          new ApiResponse(
            200,
            "Orders fetched successfully",
            orders
          )
        );
    }
  );

/* ==========================================
   UPDATE STATUS
========================================== */

const updateOrderStatus =
  asyncHandler(
    async (
      req,
      res
    ) => {
      const order =
        await orderService.updateOrderStatus(
          req.params.id,
          req.body.status
        );

      return res
        .status(200)
        .json(
          new ApiResponse(
            200,
            "Order status updated successfully",
            order
          )
        );
    }
  );

module.exports = {
  placeOrder,

  placeGuestOrder,

  getMyOrders,

  getOrderById,

  getAllOrders,

  updateOrderStatus,
};