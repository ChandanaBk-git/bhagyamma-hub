const mongoose = require("mongoose");

const Order = require("../models/order.model");
const OrderItem = require("../models/orderItem.model");
const User = require("../models/user.model");

const cartService = require("./cart.service");
const sellingPointService = require("./sellingPoint.service");

const productOrderCommissionService =
    require("./productOrderCommission.service");

const PackagingAssignment =
    require("../models/packagingAssignment.model");

/* ==========================================================================
   GENERATE ORDER NUMBER
   ========================================================================== */

const generateOrderNumber = async () => {
    const lastOrder = await Order.findOne({})
        .sort({ createdAt: -1 })
        .select("orderNumber")
        .lean();

    let nextNumber = 1;

    if (lastOrder?.orderNumber) {
        const match =
            String(lastOrder.orderNumber).match(/(\d+)$/);

        if (match) {
            nextNumber =
                Number(match[1]) + 1;
        }
    }

    return `BHORD${String(nextNumber).padStart(6, "0")}`;
};


/* ==========================================================================
   NORMALIZE MOBILE
   ========================================================================== */

const normalizeMobile = (mobile) => {
    return String(mobile || "")
        .replace(/\D/g, "");
};


/* ==========================================================================
   CALCULATE ORDER SELLING POINTS
   ========================================================================== */

const calculateOrderSellingPoints = (amount) => {
    const purchaseAmount =
        Number(amount || 0);

    if (purchaseAmount < 100) {
        return 0;
    }

    return (
        Math.floor(
            purchaseAmount / 100
        ) * 2
    );
};


/* ==========================================================================
   CALCULATE GUEST ORDER SELLING POINTS
   ========================================================================== */

const calculateGuestOrderSellingPoints = async (
    order
) => {
    const currentMobile =
        normalizeMobile(
            order.customerMobile
        );

const purchaseAmount =
    Math.max(
        0,
        Number(order.finalAmount || 0) -
        Number(order.deliveryCharge || 0)
    );

    let previousCarry = 0;

    if (
        currentMobile.length === 10
    ) {
        const previousOrders =
            await Order.find({
                _id: {
                    $ne: order._id,
                },

                orderType: "GUEST",

                userId: null,

                customerMobile:
                    currentMobile,

                paymentStatus: "PAID",

                sellingPointsProcessed:
                    true,
            })
                .sort({
                    createdAt: 1,
                    _id: 1,
                })
                .select(
                    "subtotal discount deliveryCharge spEligibleAmount spCarryForward sellingPoints sellingPointsProcessed"
                )
                .lean();

        for (
            const previousOrder
            of previousOrders
        ) {
            if (
                previousOrder.spCarryForward !==
                    undefined &&
                previousOrder.spCarryForward !==
                    null
            ) {
                previousCarry =
                    Math.max(
                        0,
                        Number(
                            previousOrder.spCarryForward ||
                            0
                        )
                    );
            } else {
                const oldAmount =
                    Math.max(
                        0,
                        Number(
                            previousOrder.spEligibleAmount
                        ) > 0
                            ? Number(
                                previousOrder.spEligibleAmount
                            )
                            : Number(
                                previousOrder.subtotal ||
                                0
                            ) -
                              Number(
                                previousOrder.discount ||
                                0
                              ) -
                              Number(
                                previousOrder.deliveryCharge ||
                                0
                              )
                    );

                const oldTotal =
                    oldAmount +
                    previousCarry;

                previousCarry =
                    oldTotal % 100;
            }
        }
    }

    const calculationTotal =
        purchaseAmount +
        previousCarry;

    const completedBlocks =
        Math.floor(
            calculationTotal / 100
        );

    const pointsEarned =
        completedBlocks * 2;

    const pendingAmount =
        calculationTotal % 100;

    return {
        purchaseAmount,

        previousPendingAmount:
            previousCarry,

        totalAmount:
            calculationTotal,

        completeBlocks:
            completedBlocks,

        pointsEarned,

        pendingAmount,
    };
};


/* ==========================================================================
   CREATE ORDER
   ========================================================================== */

const createOrder = async (
    userId,
    orderData = {}
) => {
    try {

        const {
            customerName = "",
            customerMobile = "",
            customerEmail = "",
            deliveryDetails = {},
            paymentMethod = "PHONEPE",

            subtotal: guestSubtotal = 0,
            discount: guestDiscount = 0,
            walletAmount: guestWalletAmount = 0,
            deliveryCharge: guestDeliveryCharge = 0,

            items: guestItems = [],
        } = orderData;


        /* ------------------------------------------------------------------
           DETERMINE GUEST / MEMBER
           ------------------------------------------------------------------ */

        const isGuest =
            !userId ||
            userId === null ||
            userId === undefined;

        const orderType =
            isGuest
                ? "GUEST"
                : "MEMBER";


        let cart = null;


        /* ==================================================================
           MEMBER CART
           ================================================================== */

        if (!isGuest) {

            console.log(
                "======================================"
            );

            console.log(
                "CREATE ORDER - MEMBER CART DEBUG"
            );

            console.log(
                "ORDER userId:",
                userId
            );

            console.log(
                "ORDER userId string:",
                String(userId)
            );


            cart =
                await cartService.getCart(
                    userId
                );


            console.log(
                "CART FOUND:",
                !!cart
            );

            console.log(
                "CART ID:",
                cart?._id
            );

            console.log(
                "CART userId:",
                cart?.userId
            );

            console.log(
                "CART userId string:",
                cart?.userId
                    ? String(cart.userId)
                    : null
            );

            console.log(
                "CART ITEMS:",
                cart?.items
            );

            console.log(
                "CART ITEM COUNT:",
                cart?.items?.length
            );

            console.log(
                "CART TOTAL AMOUNT:",
                cart?.totalAmount
            );

            console.log(
                "CART TOTAL ITEMS:",
                cart?.totalItems
            );

            console.log(
                "======================================"
            );


            if (!cart) {
                throw new Error(
                    "Cart not found"
                );
            }


            if (
                !Array.isArray(
                    cart.items
                ) ||
                cart.items.length === 0
            ) {
                throw new Error(
                    "Cart is empty"
                );
            }
        }


        /* ------------------------------------------------------------------
           INITIALIZE PRICING
           ------------------------------------------------------------------ */

        let subtotal = 0;
        let discount = 0;
        let walletAmount = 0;
        let deliveryCharge = 0;


        /* ==================================================================
           MEMBER PRICING
           ==================================================================

           IMPORTANT:

           Only an EXISTING REGISTERED ACTIVE MEMBER gets 20% discount.

           Guest:
               handled separately

           Registered but inactive:
               0% discount

           Registered + Active:
               20% discount

           Delivery:
               always ₹50

           Delivery is never included in discount/commission.
           ================================================================== */

        if (!isGuest) {

            subtotal =
                Number(
                    cart.totalAmount || 0
                );


            /* --------------------------------------------------------------
               GET REGISTERED MEMBER
               -------------------------------------------------------------- */

            const buyer =
                await User.findById(
                    userId
                ).lean();


            if (!buyer) {
                throw new Error(
                    "User not found"
                );
            }


            /* --------------------------------------------------------------
               CHECK ACTIVE MEMBERSHIP
               -------------------------------------------------------------- */

            const isActiveMember =
                String(
                    buyer.membershipStatus ||
                    ""
                )
                    .trim()
                    .toLowerCase() ===
                "active";


            /* --------------------------------------------------------------
               20% DISCOUNT ONLY FOR ACTIVE MEMBERS
               -------------------------------------------------------------- */

            discount =
                isActiveMember
                    ? Math.round(
                        (
                            subtotal * 20
                        ) / 100 * 100
                    ) / 100
                    : 0;


            /* --------------------------------------------------------------
               WALLET
               -------------------------------------------------------------- */

            walletAmount =
                Number(
                    cart.walletAmount || 0
                );


            /* --------------------------------------------------------------
               DELIVERY
               --------------------------------------------------------------

               Always ₹50.

               It is NOT discounted.
               It is NOT included in commission.
               -------------------------------------------------------------- */

            deliveryCharge = 50;


            console.log(
                "======================================"
            );

            console.log(
                "MEMBER ORDER PRICING"
            );

            console.log(
                "Member:",
                buyer.userId
            );

            console.log(
                "Membership Status:",
                buyer.membershipStatus
            );

            console.log(
                "Active Member:",
                isActiveMember
            );

            console.log(
                "Original Subtotal: ₹",
                subtotal
            );

            console.log(
                "Member Discount: ₹",
                discount
            );

            console.log(
                "Product Payable: ₹",
                Math.max(
                    0,
                    subtotal - discount
                )
            );

            console.log(
                "Wallet Amount: ₹",
                walletAmount
            );

            console.log(
                "Delivery: ₹",
                deliveryCharge
            );

            console.log(
                "======================================"
            );

        } else {

            /* =================================================================
               GUEST PRICING
               =================================================================

               Guests DO NOT receive the 20% member discount.

               Their existing guest pricing is preserved.
               ================================================================= */

            subtotal =
                Number(
                    guestSubtotal || 0
                );


            discount =
                Number(
                    guestDiscount || 0
                );


            walletAmount =
                Number(
                    guestWalletAmount || 0
                );


            deliveryCharge =
                Number(
                    guestDeliveryCharge || 0
                );
        }


        /* ------------------------------------------------------------------
           FINAL AMOUNT
           ------------------------------------------------------------------ */

        const finalAmount =
            Math.max(
                0,
                subtotal -
                    discount -
                    walletAmount +
                    deliveryCharge
            );


        /* ------------------------------------------------------------------
           SELLING POINTS
           ------------------------------------------------------------------ */

const sellingPointAmount =
    Math.max(
        0,
        finalAmount -
            deliveryCharge
    );

const sellingPoints =
    calculateOrderSellingPoints(
        sellingPointAmount
    );

        /* ------------------------------------------------------------------
           ORDER NUMBER
           ------------------------------------------------------------------ */

        const orderNumber =
            await generateOrderNumber();


        /* ==================================================================
           CREATE ORDER
           ================================================================== */

        const order =
            await Order.create({

                userId:
                    isGuest
                        ? null
                        : userId,

                orderType,


                customerName:
                    String(
                        customerName || ""
                    ).trim(),


                customerMobile:
                    String(
                        customerMobile || ""
                    ).trim(),


                customerEmail:
                    String(
                        customerEmail || ""
                    ).trim(),


                orderNumber,


                subtotal,


                discount,


                walletAmount,


                deliveryCharge,


                finalAmount,


                sellingPoints,


                sellingPointsProcessed:
                    false,


                sellingPointsProcessedAt:
                    null,


                spPreviousCarryForward:
                    0,


                spCalculationTotal:
                    0,


                spCompletedBlocks:
                    0,


spEligibleAmount:
    sellingPointAmount,

                spCarryForward:
                    0,


                status:
                    "PLACED",


                paymentMethod,


                paymentStatus:
                    "PENDING",


                phonePeOrderId:
                    null,


                phonePeTransactionId:
                    null,


                paidAt:
                    null,


                membershipLinked:
                    false,


                linkedAt:
                    null,


                deliveryDetails: {

                    name:
                        deliveryDetails.name ||
                        customerName ||
                        "",


                    mobile:
                        deliveryDetails.mobile ||
                        customerMobile ||
                        "",


                    address:
                        deliveryDetails.address ||
                        "",


                    city:
                        deliveryDetails.city ||
                        "",


                    state:
                        deliveryDetails.state ||
                        "",


                    pincode:
                        deliveryDetails.pincode ||
                        "",
                },


                placedAt:
                    new Date(),
            });


        /* ==================================================================
           SAVE ORDER ITEMS
           ================================================================== */

        let itemsToSave = [];


        if (!isGuest) {

            itemsToSave =
                Array.isArray(
                    cart?.items
                )
                    ? cart.items
                    : [];

        } else {

            itemsToSave =
                Array.isArray(
                    guestItems
                )
                    ? guestItems
                    : [];
        }


        if (
            itemsToSave.length > 0
        ) {

            const orderItems =
                itemsToSave.map(
                    (item) => {

                        const quantity =
                            Number(
                                item.quantity ||
                                1
                            );


                        const price =
                            Number(
                                item.price ||
                                item.productId?.price ||
                                0
                            );


                        const total =
                            Number(
                                item.total ||
                                price * quantity
                            );


                        return {

                            orderId:
                                order._id,


                            productId:
                                item.productId?._id ||
                                item.productId ||
                                null,


                            productName:
                                item.productId?.name ||
                                item.productId?.productName ||
                                item.productName ||
                                item.name ||
                                "Product",


                            quantity,


                            price,


                            total,
                        };
                    }
                );


            const validOrderItems =
                orderItems.filter(
                    (item) =>
                        item.productId
                );


            if (
                validOrderItems.length > 0
            ) {

                await OrderItem.insertMany(
                    validOrderItems
                );
            }
        }


        /* ==================================================================
           LOG ORDER
           ================================================================== */

        console.log(
            "======================================"
        );

        console.log(
            "ORDER CREATED"
        );

        console.log(
            "Order:",
            order.orderNumber
        );

        console.log(
            "Type:",
            order.orderType
        );

        console.log(
            "User:",
            userId || "GUEST"
        );

        console.log(
            "Product Subtotal: ₹",
            subtotal
        );

        console.log(
            "Discount: ₹",
            discount
        );

        console.log(
            "Wallet: ₹",
            walletAmount
        );

        console.log(
            "Delivery Charge: ₹",
            deliveryCharge
        );

        console.log(
            "Final Amount: ₹",
            finalAmount
        );

console.log(
    "SP Eligible Amount: ₹",
    sellingPointAmount
);

console.log(
    "Order SP:",
    sellingPoints
);
        console.log(
            "Payment Status:",
            "PENDING"
        );

        console.log(
            "CART WAS NOT CLEARED"
        );

        console.log(
            "======================================"
        );


        return await Order.findById(
            order._id
        ).lean();

    } catch (error) {

        console.error(
            "CREATE ORDER ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   PLACE ORDER
   ========================================================================== */

const placeOrder = async (
    userId,
    orderData = {}
) => {

    return createOrder(
        userId,
        orderData
    );
};


/* ==========================================================================
   PLACE GUEST ORDER
   ========================================================================== */

const placeGuestOrder = async (
    orderData = {}
) => {

    try {

        const customerName =
            String(
                orderData.customerName ||
                orderData.name ||
                ""
            ).trim();


        const customerMobile =
            normalizeMobile(
                orderData.customerMobile ||
                orderData.mobile ||
                ""
            );


        const customerEmail =
            String(
                orderData.customerEmail ||
                orderData.email ||
                ""
            )
                .trim()
                .toLowerCase();


        const existingDeliveryDetails =
            orderData.deliveryDetails ||
            {};


        const deliveryDetails = {

            name:
                String(
                    existingDeliveryDetails.name ||
                    customerName ||
                    ""
                ).trim(),


            mobile:
                normalizeMobile(
                    existingDeliveryDetails.mobile ||
                    customerMobile ||
                    ""
                ),


            address:
                String(
                    existingDeliveryDetails.address ||
                    orderData.address ||
                    ""
                ).trim(),


            city:
                String(
                    existingDeliveryDetails.city ||
                    orderData.city ||
                    ""
                ).trim(),


            state:
                String(
                    existingDeliveryDetails.state ||
                    orderData.state ||
                    ""
                ).trim(),


            pincode:
                String(
                    existingDeliveryDetails.pincode ||
                    orderData.pincode ||
                    ""
                )
                    .replace(
                        /\D/g,
                        ""
                    ),
        };


        if (!customerName) {
            throw new Error(
                "Customer name is required"
            );
        }


        if (
            customerMobile.length !== 10
        ) {
            throw new Error(
                "Valid 10-digit mobile number is required"
            );
        }


        if (
            !deliveryDetails.address
        ) {
            throw new Error(
                "Delivery address is required"
            );
        }


        if (
            !deliveryDetails.city
        ) {
            throw new Error(
                "City is required"
            );
        }


        if (
            !deliveryDetails.state
        ) {
            throw new Error(
                "State is required"
            );
        }


        if (
            deliveryDetails.pincode.length !== 6
        ) {
            throw new Error(
                "Valid 6-digit pincode is required"
            );
        }


        const normalizedOrderData = {

            ...orderData,


            customerName,


            customerMobile,


            customerEmail,


            deliveryDetails,


            paymentMethod:
                orderData.paymentMethod ||
                "PHONEPE",


            subtotal:
                Number(
                    orderData.subtotal || 0
                ),


            /*
             * Guest discount remains whatever
             * the existing guest flow sends.
             *
             * Product member discount is NOT
             * applied here.
             */
discount: 0,


            walletAmount:
                Number(
                    orderData.walletAmount || 0
                ),


            /*
             * Guest delivery is always ₹50.
             */
            deliveryCharge:
                50,


            items:
                Array.isArray(
                    orderData.items
                )
                    ? orderData.items
                    : [],
        };


        return await createOrder(
            null,
            normalizedOrderData
        );

    } catch (error) {

        console.error(
            "PLACE GUEST ORDER ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   GET ORDER BY ID
   ========================================================================== */

const getOrderById = async (
    orderId,
    userId = null
) => {

    try {

        if (
            !mongoose.Types.ObjectId.isValid(
                orderId
            )
        ) {
            throw new Error(
                "Invalid order ID"
            );
        }


        const query = {
            _id:
                orderId,
        };


        if (userId) {
            query.userId =
                userId;
        }


        const order =
            await Order.findOne(
                query
            )
                .populate(
                    "userId",
                    "name userId email mobile role referralCode"
                )
                .lean();


        if (!order) {
            throw new Error(
                "Order not found"
            );
        }


        const items =
            await OrderItem.find({
                orderId:
                    order._id,
            })
                .populate(
                    "productId",
                    "name productName images price"
                )
                .lean();


        return {

            ...order,

            items,
        };

    } catch (error) {

        console.error(
            "GET ORDER BY ID ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   GET MY ORDERS
   ========================================================================== */

const getMyOrders = async (
    userId
) => {

    try {

        if (!userId) {
            return [];
        }


        const orders =
            await Order.find({
                userId,
            })
                .sort({
                    createdAt: -1,
                })
                .lean();


        if (!orders.length) {
            return [];
        }


        const orderIds =
            orders.map(
                (order) =>
                    order._id
            );


        const items =
            await OrderItem.find({
                orderId: {
                    $in:
                        orderIds,
                },
            })
                .populate(
                    "productId",
                    "name productName images price"
                )
                .lean();


        const itemsByOrder = {};


        for (
            const item
            of items
        ) {

            const key =
                item.orderId.toString();


            if (
                !itemsByOrder[key]
            ) {

                itemsByOrder[key] =
                    [];
            }


            itemsByOrder[key].push(
                item
            );
        }


        return orders.map(
            (order) => ({

                ...order,

                items:
                    itemsByOrder[
                        order._id.toString()
                    ] || [],
            })
        );

    } catch (error) {

        console.error(
            "GET MY ORDERS ERROR:",
            error
        );

        throw error;
    }
};


const getAllOrders = async (
    options = {}
) => {

    try {

        const {
            page = 1,
            limit = 20,
            status,
            paymentStatus,
            orderType,
            search,
        } = options;


        const filter = {};


        if (status) {

            filter.status =
                status;

        }


        if (paymentStatus) {

            filter.paymentStatus =
                paymentStatus;

        }


        if (orderType) {

            filter.orderType =
                orderType;

        }


        if (search) {

            filter.$or = [

                {
                    orderNumber: {
                        $regex:
                            search,
                        $options:
                            "i",
                    },
                },

                {
                    customerName: {
                        $regex:
                            search,
                        $options:
                            "i",
                    },
                },

                {
                    customerMobile: {
                        $regex:
                            search,
                        $options:
                            "i",
                    },
                },

                {
                    customerEmail: {
                        $regex:
                            search,
                        $options:
                            "i",
                    },
                },

            ];

        }


        const skip =
            (
                Number(page) - 1
            ) *
            Number(limit);


        /* =====================================================
           GET ORDERS
        ===================================================== */

        const [
            orders,
            total,
        ] = await Promise.all([

            Order.find(filter)
                .populate(
                    "userId",
                    "name userId email mobile role referralCode sellingPoints membershipStatus"
                )
                .sort({
                    createdAt: -1,
                })
                .skip(skip)
                .limit(
                    Number(limit)
                )
                .lean(),

            Order.countDocuments(
                filter
            ),

        ]);


        /* =====================================================
           NO ORDERS
        ===================================================== */

        if (!orders.length) {

            return {

                orders: [],

                pagination: {

                    page:
                        Number(page),

                    limit:
                        Number(limit),

                    total: 0,

                    pages: 0,

                },

            };

        }


        /* =====================================================
           GET ORDER IDS
        ===================================================== */

        const orderIds =
            orders.map(
                (order) =>
                    order._id
            );


        /* =====================================================
           GET ORDER ITEMS
        ===================================================== */

        const items =
            await OrderItem.find({

                orderId: {
                    $in:
                        orderIds,
                },

            })
                .populate(
                    "productId",
                    "name productName images price category brand"
                )
                .lean();


        /* =====================================================
           GROUP ITEMS BY ORDER
        ===================================================== */

        const itemsByOrder = {};


        for (
            const item of items
        ) {

            const key =
                item.orderId.toString();


            if (
                !itemsByOrder[key]
            ) {

                itemsByOrder[key] =
                    [];

            }


            /* =================================================
               PRODUCT NAME
            ================================================= */

            const productName =
                item.productName ||
                item.productId?.productName ||
                item.productId?.name ||
                item.product?.productName ||
                item.product?.name ||
                "Product";


            /* =================================================
               QUANTITY
            ================================================= */

            const quantity =
                Number(
                    item.quantity || 0
                );


            /* =================================================
               PRICE
            ================================================= */

            const price =
                Number(
                    item.price ??
                    item.productId?.price ??
                    item.product?.price ??
                    0
                );


            /* =================================================
               TOTAL
            ================================================= */

            const total =
                Number(
                    item.total ??
                    item.subtotal ??
                    (
                        price *
                        quantity
                    )
                );


            /* =================================================
               FINAL ITEM
            ================================================= */

            itemsByOrder[key].push({

                ...item,

                productName,

                quantity,

                price,

                total,

                /* Keep populated product */
                productId:
                    item.productId || null,

            });

        }


        /* =====================================================
           RETURN ORDERS WITH ITEMS
        ===================================================== */

        return {

            orders:

                orders.map(
                    (order) => ({

                        ...order,

                        items:
                            itemsByOrder[
                                order._id.toString()
                            ] || [],

                    })
                ),


            pagination: {

                page:
                    Number(page),

                limit:
                    Number(limit),

                total,

                pages:
                    Math.ceil(
                        total /
                        Number(limit)
                    ),

            },

        };

    } catch (error) {

        console.error(
            "GET ALL ORDERS ERROR:",
            error
        );

        throw error;

    }

};


/* ==========================================================================
   GET ORDERS BY MOBILE
   ========================================================================== */

const getOrdersByMobile = async (
    mobile
) => {

    try {

        const normalizedMobile =
            normalizeMobile(
                mobile
            );


        if (
            normalizedMobile.length !== 10
        ) {
            throw new Error(
                "Valid 10-digit mobile number is required"
            );
        }


        const orders =
            await Order.find({
                customerMobile:
                    normalizedMobile,
            })
                .sort({
                    createdAt: -1,
                })
                .lean();


        if (!orders.length) {
            return [];
        }


        const orderIds =
            orders.map(
                (order) =>
                    order._id
            );


        const items =
            await OrderItem.find({
                orderId: {
                    $in:
                        orderIds,
                },
            })
                .populate(
                    "productId",
                    "name productName images price category brand"
                )
                .lean();


        const itemsByOrder = {};


        for (
            const item
            of items
        ) {

            const key =
                item.orderId.toString();


            if (
                !itemsByOrder[key]
            ) {

                itemsByOrder[key] =
                    [];
            }


            itemsByOrder[key].push(
                item
            );
        }


        return orders.map(
            (order) => ({

                ...order,

                items:
                    itemsByOrder[
                        order._id.toString()
                    ] || [],
            })
        );

    } catch (error) {

        console.error(
            "GET ORDERS BY MOBILE ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   LINK GUEST ORDERS TO USER
   ========================================================================== */

const linkGuestOrdersToUser = async (
    userId,
    mobile
) => {

    try {

        if (!userId) {
            throw new Error(
                "User ID is required"
            );
        }


        if (
            !mongoose.Types.ObjectId.isValid(
                userId
            )
        ) {
            throw new Error(
                "Invalid user ID"
            );
        }


        const normalizedMobile =
            normalizeMobile(
                mobile
            );


        if (
            normalizedMobile.length !== 10
        ) {
            throw new Error(
                "Valid 10-digit mobile number is required"
            );
        }


        const result =
            await Order.updateMany(

                {
                    orderType:
                        "GUEST",

                    userId:
                        null,

                    customerMobile:
                        normalizedMobile,
                },

                {
                    $set: {

                        userId,

                        orderType:
                            "MEMBER",

                        membershipLinked:
                            true,

                        linkedAt:
                            new Date(),
                    },
                }
            );


        return {

            matchedCount:
                result.matchedCount,

            modifiedCount:
                result.modifiedCount,
        };

    } catch (error) {

        console.error(
            "LINK GUEST ORDERS ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   CLAIM GUEST ORDERS
   ========================================================================== */

const claimGuestOrders = async (
    userId,
    mobile
) => {

    try {

        if (!userId) {
            throw new Error(
                "User ID is required"
            );
        }


        const normalizedMobile =
            normalizeMobile(
                mobile
            );


        if (
            normalizedMobile.length !== 10
        ) {
            throw new Error(
                "Valid 10-digit mobile number is required"
            );
        }


        const result =
            await Order.updateMany(

                {
                    orderType:
                        "GUEST",

                    userId:
                        null,

                    customerMobile:
                        normalizedMobile,

                    paymentStatus:
                        "PAID",

                    membershipLinked:
                        false,
                },

                {
                    $set: {

                        userId,

                        orderType:
                            "MEMBER",

                        membershipLinked:
                            true,

                        linkedAt:
                            new Date(),
                    },
                }
            );


        return {

            matchedCount:
                result.matchedCount,

            modifiedCount:
                result.modifiedCount,
        };

    } catch (error) {

        console.error(
            "CLAIM GUEST ORDERS ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   CLAIM GUEST ORDERS FOR MEMBER
   ========================================================================== */

const claimGuestOrdersForMember = async (
    userId,
    mobile
) => {

    try {

        /* ------------------------------------------------------------------
           VALIDATE USER
           ------------------------------------------------------------------ */

        if (!userId) {
            throw new Error(
                "User ID is required"
            );
        }


        if (
            !mongoose.Types.ObjectId.isValid(
                userId
            )
        ) {
            throw new Error(
                "Invalid user ID"
            );
        }


        /* ------------------------------------------------------------------
           NORMALIZE MOBILE
           ------------------------------------------------------------------ */

        const normalizedMobile =
            normalizeMobile(
                mobile
            );


        if (
            normalizedMobile.length !== 10
        ) {
            throw new Error(
                "Valid 10-digit mobile number is required"
            );
        }


        /* ------------------------------------------------------------------
           FIND USER
           ------------------------------------------------------------------ */

        let user =
            await User.findById(
                userId
            );


        if (!user) {
            throw new Error(
                "User not found"
            );
        }


        /* ------------------------------------------------------------------
           FIND PAID GUEST ORDERS
           ------------------------------------------------------------------ */

        const guestOrders =
            await Order.find({

                orderType:
                    "GUEST",

                userId:
                    null,

                customerMobile:
                    normalizedMobile,

                paymentStatus:
                    "PAID",

                membershipLinked:
                    false,
            })
                .sort({
                    createdAt: 1,
                    _id: 1,
                });


        /* ------------------------------------------------------------------
           NO ORDERS
           ------------------------------------------------------------------ */

        if (
            guestOrders.length === 0
        ) {

            return {

                claimedCount:
                    0,

                totalPurchaseAmount:
                    0,

                sellingPoints:
                    Number(
                        user.sellingPoints ||
                        0
                    ),

                pendingPurchaseAmount:
                    Number(
                        user.pendingPurchaseAmount ||
                        0
                    ),

                lifetimePurchase:
                    Number(
                        user.lifetimePurchase ||
                        0
                    ),

                qualifyingPurchaseAmount:
                    Number(
                        user.qualifyingPurchaseAmount ||
                        0
                    ),

                membershipStatus:
                    user.membershipStatus ||
                    "Pending",

                membershipActivated:
                    String(
                        user.membershipStatus ||
                        ""
                    )
                        .trim()
                        .toUpperCase() ===
                    "ACTIVE",

                user,
            };
        }


        /* ------------------------------------------------------------------
           PROCESS ORDERS
           ------------------------------------------------------------------ */

        let claimedCount =
            0;

        let totalPurchaseAmount =
            0;


        for (
            const guestOrder
            of guestOrders
        ) {

            const purchaseAmount =
                Math.max(
                    0,
                    Number(
                        guestOrder.subtotal ||
                        0
                    )
                );


            /* --------------------------------------------------------------
               PROCESS SP
               -------------------------------------------------------------- */

            if (
                purchaseAmount > 0
            ) {

                await sellingPointService
                    .updateSellingPoints(
                        user._id,
                        purchaseAmount,
                        guestOrder._id
                    );


                totalPurchaseAmount +=
                    purchaseAmount;
            }


            /* --------------------------------------------------------------
               LINK ORDER
               -------------------------------------------------------------- */

            guestOrder.userId =
                user._id;


            guestOrder.orderType =
                "MEMBER";


            guestOrder.membershipLinked =
                true;


            guestOrder.linkedAt =
                new Date();


            await guestOrder.save();


            claimedCount +=
                1;


            /* --------------------------------------------------------------
               REFRESH USER
               -------------------------------------------------------------- */

            user =
                await User.findById(
                    user._id
                );


            if (!user) {
                throw new Error(
                    "User not found while recovering guest orders"
                );
            }
        }


        /* ------------------------------------------------------------------
           UPDATE QUALIFYING PURCHASE
           ------------------------------------------------------------------ */

        const existingQualifyingPurchase =
            Number(
                user.qualifyingPurchaseAmount ||
                0
            );


        const newQualifyingPurchase =
            existingQualifyingPurchase +
            totalPurchaseAmount;


        user.qualifyingPurchaseAmount =
            newQualifyingPurchase;


        await user.save();


        /* ------------------------------------------------------------------
           REFRESH USER
           ------------------------------------------------------------------ */

        user =
            await User.findById(
                user._id
            );


        /* ------------------------------------------------------------------
           MEMBERSHIP ACTIVATION SAFETY CHECK
           ------------------------------------------------------------------ */

        if (

            user &&

            String(
                user.membershipStatus ||
                ""
            )
                .trim()
                .toUpperCase() !==
            "ACTIVE" &&

            Number(
                user.qualifyingPurchaseAmount ||
                0
            ) >= 2000
        ) {

            if (
                typeof
                    sellingPointService
                        .activateMembership ===
                "function"
            ) {

                const lastOrder =
                    guestOrders[
                        guestOrders.length - 1
                    ];


                const activation =
                    await sellingPointService
                        .activateMembership(
                            user._id,

                            "ProductPurchase",

                            {
                                orderId:
                                    lastOrder?._id ||
                                    null,
                            }
                        );


                user =
                    activation.user;
            }
        }


        /* ------------------------------------------------------------------
           FINAL REFRESH
           ------------------------------------------------------------------ */

        user =
            await User.findById(
                user._id
            );


        /* ------------------------------------------------------------------
           RESULT
           ------------------------------------------------------------------ */

        return {

            claimedCount,

            totalPurchaseAmount,

            sellingPoints:
                Number(
                    user?.sellingPoints ||
                    0
                ),

            pendingPurchaseAmount:
                Number(
                    user?.pendingPurchaseAmount ||
                    0
                ),

            lifetimePurchase:
                Number(
                    user?.lifetimePurchase ||
                    0
                ),

            qualifyingPurchaseAmount:
                Number(
                    user?.qualifyingPurchaseAmount ||
                    0
                ),

            membershipStatus:
                user?.membershipStatus ||
                "Pending",

            membershipActivated:
                String(
                    user?.membershipStatus ||
                    ""
                )
                    .trim()
                    .toUpperCase() ===
                "ACTIVE",

            user,
        };

    } catch (error) {

        console.error(
            "CLAIM GUEST ORDERS FOR MEMBER ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   PROCESS SELLING POINTS
   ========================================================================== */

const processSellingPoints = async (
    orderId
) => {

    try {

        if (
            !mongoose.Types.ObjectId.isValid(
                orderId
            )
        ) {
            throw new Error(
                "Invalid order ID"
            );
        }


        const order =
            await Order.findById(
                orderId
            );


        if (!order) {
            throw new Error(
                "Order not found"
            );
        }


        /* ------------------------------------------------------------------
           ONLY PAID ORDERS
           ------------------------------------------------------------------ */

        if (
            String(
                order.paymentStatus ||
                ""
            )
                .trim()
                .toUpperCase() !==
            "PAID"
        ) {

            console.log(
                `SP SKIPPED: Payment not PAID ${order.orderNumber}`
            );


            return {

                success:
                    false,

                message:
                    "Order payment is not PAID",
            };
        }


        /* ------------------------------------------------------------------
           DUPLICATE PROTECTION
           ------------------------------------------------------------------ */

        if (
            order.sellingPointsProcessed
        ) {

            return {

                success:
                    true,

                alreadyProcessed:
                    true,

                sellingPoints:
                    Number(
                        order.sellingPoints ||
                        0
                    ),

                carryForward:
                    Number(
                        order.spCarryForward ||
                        0
                    ),
            };
        }


        /* ==================================================================
           GUEST ORDER
           ================================================================== */

        if (!order.userId) {

            const calculation =
                await calculateGuestOrderSellingPoints(
                    order
                );


            order.sellingPoints =
                Number(
                    calculation.pointsEarned ||
                    0
                );


            order.spPreviousCarryForward =
                Number(
                    calculation.previousPendingAmount ||
                    0
                );


            order.spCalculationTotal =
                Number(
                    calculation.totalAmount ||
                    0
                );


            order.spCompletedBlocks =
                Number(
                    calculation.completeBlocks ||
                    0
                );


            order.spEligibleAmount =
                Number(
                    calculation.purchaseAmount ||
                    0
                );


            order.spCarryForward =
                Number(
                    calculation.pendingAmount ||
                    0
                );


            order.sellingPointsProcessed =
                true;


            order.sellingPointsProcessedAt =
                new Date();


            await order.save();


            console.log(
                "======================================"
            );

            console.log(
                "GUEST SELLING POINTS PROCESSED"
            );

            console.log(
                "Order:",
                order.orderNumber
            );

            console.log(
                "Mobile:",
                order.customerMobile
            );

            console.log(
                "Purchase Amount: ₹",
                calculation.purchaseAmount
            );

            console.log(
                "Previous Carry: ₹",
                calculation.previousPendingAmount
            );

            console.log(
                "Calculation Total: ₹",
                calculation.totalAmount
            );

            console.log(
                "Completed Blocks:",
                calculation.completeBlocks
            );

            console.log(
                "SP Earned:",
                calculation.pointsEarned
            );

            console.log(
                "Carry Forward: ₹",
                calculation.pendingAmount
            );

            console.log(
                "======================================"
            );


            return {

                success:
                    true,

                alreadyProcessed:
                    false,

                waitingForMembership:
                    true,

                sellingPoints:
                    calculation.pointsEarned,

                previousCarry:
                    calculation.previousPendingAmount,

                calculationTotal:
                    calculation.totalAmount,

                completedBlocks:
                    calculation.completeBlocks,

                eligibleAmount:
                    calculation.purchaseAmount,

                carryForward:
                    calculation.pendingAmount,
            };
        }


        /* ==================================================================
           MEMBER ORDER
           ================================================================== */

        const user =
            await User.findById(
                order.userId
            );


        if (!user) {

            console.log(
                `SP SKIPPED: User not found for ${order.orderNumber}`
            );


            return {

                success:
                    false,

                message:
                    "User not found",
            };
        }


        /* ------------------------------------------------------------------
           VALID MEMBER ROLES
           ------------------------------------------------------------------ */

        const allowedRoles = [
            "MEMBER",
            "MANAGER",
            "SUPERVISOR",
        ];


        const userRole =
            String(
                user.role || ""
            )
                .trim()
                .toUpperCase();


        if (
            !allowedRoles.includes(
                userRole
            )
        ) {

            console.log(
                `SP SKIPPED: Role ${user.role} not eligible`
            );


            return {

                success:
                    false,

                message:
                    "User role is not eligible for selling points",
            };
        }


        /* ------------------------------------------------------------------
           SP ELIGIBLE AMOUNT
           ------------------------------------------------------------------ */

const sellingPointAmount =
    Number(
        order.spEligibleAmount
    ) > 0
        ? Number(
            order.spEligibleAmount
        )
        : Math.max(
            0,
            Number(
                order.finalAmount ||
                0
            ) -
            Number(
                order.deliveryCharge ||
                0
            )
        );
        if (
            sellingPointAmount <= 0
        ) {

            order.sellingPoints =
                0;


            order.sellingPointsProcessed =
                true;


            order.sellingPointsProcessedAt =
                new Date();


            await order.save();


            return {

                success:
                    true,

                sellingPoints:
                    0,
            };
        }


        /* ------------------------------------------------------------------
           USE EXISTING SELLING POINT SERVICE
           ------------------------------------------------------------------ */

        let spResult =
            null;


        if (
            typeof
                sellingPointService
                    .updateSellingPoints ===
            "function"
        ) {

            spResult =
                await sellingPointService
                    .updateSellingPoints(
                        user._id,
                        sellingPointAmount,
                        order._id
                    );

        } else if (
            typeof
                sellingPointService
                    .processPurchaseSellingPoints ===
            "function"
        ) {

            spResult =
                await sellingPointService
                    .processPurchaseSellingPoints(
                        user._id,
                        sellingPointAmount,
                        order._id
                    );

        } else if (
            typeof
                sellingPointService
                    .addPurchaseSellingPoints ===
            "function"
        ) {

            spResult =
                await sellingPointService
                    .addPurchaseSellingPoints(
                        user._id,
                        sellingPointAmount,
                        order._id
                    );

        } else {

            throw new Error(
                "No compatible selling point service method found"
            );
        }


        /* ------------------------------------------------------------------
           REFRESH ORDER
           ------------------------------------------------------------------ */

        const updatedOrder =
            await Order.findById(
                order._id
            );


        if (
            updatedOrder
        ) {

            updatedOrder.sellingPoints =
                Number(
                    updatedOrder.sellingPoints ||
                    0
                );


            updatedOrder.sellingPointsProcessed =
                true;


            updatedOrder.sellingPointsProcessedAt =
                updatedOrder.sellingPointsProcessedAt ||
                new Date();


            await updatedOrder.save();
        }


        return {

            success:
                true,

            alreadyProcessed:
                false,

            sellingPoints:
                Number(
                    updatedOrder?.sellingPoints ||
                    0
                ),

            result:
                spResult,
        };

    } catch (error) {

        console.error(
            "PROCESS SELLING POINTS ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   UPDATE PAYMENT STATUS
   ========================================================================== */

const updatePaymentStatus = async (
    orderId,
    paymentStatus,
    paymentData = {}
) => {

    try {

        if (
            !mongoose.Types.ObjectId.isValid(
                orderId
            )
        ) {
            throw new Error(
                "Invalid order ID"
            );
        }


        const normalizedStatus =
            String(
                paymentStatus || ""
            )
                .trim()
                .toUpperCase();


        const allowedStatuses = [
            "PENDING",
            "PAID",
            "FAILED",
            "REFUNDED",
            "CANCELLED",
        ];


        if (
            !allowedStatuses.includes(
                normalizedStatus
            )
        ) {
            throw new Error(
                `Invalid payment status: ${paymentStatus}`
            );
        }


        const updateData = {

            paymentStatus:
                normalizedStatus,
        };


        if (
            paymentData.phonePeOrderId
        ) {

            updateData.phonePeOrderId =
                paymentData.phonePeOrderId;
        }


        if (
            paymentData.phonePeTransactionId
        ) {

            updateData.phonePeTransactionId =
                paymentData.phonePeTransactionId;
        }


        if (
            paymentData.paymentResponse
        ) {

            updateData.paymentResponse =
                paymentData.paymentResponse;
        }


        if (
            normalizedStatus ===
            "PAID"
        ) {

            updateData.paidAt =
                paymentData.paidAt
                    ? new Date(
                        paymentData.paidAt
                    )
                    : new Date();
        }


        const order =
            await Order.findByIdAndUpdate(

                orderId,

                {
                    $set:
                        updateData,
                },

                {
                    new:
                        true,

                    runValidators:
                        true,
                }
            );


        if (!order) {
            throw new Error(
                "Order not found"
            );
        }


        /* ==================================================================
           PAID ORDER PROCESSING
           ================================================================== */

        if (
            normalizedStatus ===
            "PAID"
        ) {

            /* --------------------------------------------------------------
               1. EXISTING SELLING POINT PROCESSING
               -------------------------------------------------------------- */

            try {

                await processSellingPoints(
                    order._id
                );

            } catch (spError) {

                /*
                 * Payment is already successful.
                 *
                 * Do NOT change payment status
                 * to FAILED.
                 */

                console.error(
                    "SELLING POINT PROCESSING ERROR AFTER PAYMENT:",
                    spError
                );
            }


            /* --------------------------------------------------------------
               2. PRODUCT ORDER COMMISSION
               --------------------------------------------------------------

               Only registered Active members qualify.

               Product commission service handles:

               Manager:
                   50%

               Other eligible uplines:
                   remaining 30%

               Buyer:
                   20% discount

               Delivery:
                   excluded

               Wallet deduction:
                   excluded from commission base

               Joining commission:
                   completely separate
               -------------------------------------------------------------- */

            try {

                await productOrderCommissionService
                    .processProductOrderCommission(
                        order._id
                    );

            } catch (
                commissionError
            ) {

                /*
                 * Payment is already PAID.
                 *
                 * Do NOT change the order to FAILED.
                 *
                 * Commission processing can be retried.
                 */

                console.error(
                    "PRODUCT ORDER COMMISSION ERROR AFTER PAYMENT:",
                    commissionError
                );
            }
        }


        return await Order.findById(
            order._id
        ).lean();

    } catch (error) {

        console.error(
            "UPDATE PAYMENT STATUS ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   UPDATE ORDER STATUS
   ========================================================================== */

const updateOrderStatus = async (orderId, status) => {
  const allowedStatuses = [
    "PLACED",
    "CONFIRMED",
    "PACKING",
    "PACKED",
    "READY_FOR_DISPATCH",
    "SHIPPED",
    "OUT_FOR_DELIVERY",
    "DELIVERED",
    "CANCELLED",
  ];

  if (!allowedStatuses.includes(status)) {
    throw new ApiError(
      400,
      `Invalid order status. Allowed statuses: ${allowedStatuses.join(", ")}`
    );
  }

  const order = await Order.findById(orderId);

  if (!order) {
    throw new ApiError(404, "Order not found");
  }

  // =====================================================
  // UPDATE STATUS
  // =====================================================

  order.status = status;

  const now = new Date();

  // =====================================================
  // STATUS TIMESTAMPS
  // =====================================================

  switch (status) {
    case "CONFIRMED":
      if (!order.confirmedAt) {
        order.confirmedAt = now;
      }
      break;

    case "PACKING":
      if (!order.packingAt) {
        order.packingAt = now;
      }
      break;

    case "PACKED":
      if (!order.packedAt) {
        order.packedAt = now;
      }
      break;

    case "READY_FOR_DISPATCH":
      if (!order.readyForDispatchAt) {
        order.readyForDispatchAt = now;
      }
      break;

    case "SHIPPED":
      if (!order.shippedAt) {
        order.shippedAt = now;
      }
      break;

    case "OUT_FOR_DELIVERY":
      if (!order.outForDeliveryAt) {
        order.outForDeliveryAt = now;
      }
      break;

    case "DELIVERED":
      if (!order.deliveredAt) {
        order.deliveredAt = now;
      }
      break;

    case "CANCELLED":
      if (!order.cancelledAt) {
        order.cancelledAt = now;
      }
      break;

    case "PLACED":
      if (!order.placedAt) {
        order.placedAt = now;
      }
      break;

    default:
      break;
  }

  await order.save();

  return order;
};

/* ==========================================================================
   UPDATE STATUS ALIAS
   ========================================================================== */

const updateStatus = async (
    orderId,
    status
) => {

    return updateOrderStatus(
        orderId,
        status
    );
};


/* ==========================================================================
   CANCEL ORDER
   ========================================================================== */

const cancelOrder = async (
    orderId,
    userId = null,
    reason = ""
) => {

    try {

        if (
            !mongoose.Types.ObjectId.isValid(
                orderId
            )
        ) {
            throw new Error(
                "Invalid order ID"
            );
        }


        const query = {
            _id:
                orderId,
        };


        if (userId) {

            if (
                !mongoose.Types.ObjectId.isValid(
                    userId
                )
            ) {
                throw new Error(
                    "Invalid user ID"
                );
            }


            query.userId =
                userId;
        }


        const order =
            await Order.findOne(
                query
            );


        if (!order) {
            throw new Error(
                "Order not found"
            );
        }


        const paymentStatus =
            String(
                order.paymentStatus ||
                ""
            )
                .trim()
                .toUpperCase();


        if (
            paymentStatus ===
            "PAID"
        ) {

            throw new Error(
                "Paid order cannot be cancelled from this action"
            );
        }


        const currentStatus =
            String(
                order.status ||
                ""
            )
                .trim()
                .toUpperCase();


        if (
            [
                "SHIPPED",
                "OUT_FOR_DELIVERY",
                "DELIVERED",
            ].includes(
                currentStatus
            )
        ) {

            throw new Error(
                "Order cannot be cancelled after shipping"
            );
        }


        if (
            currentStatus ===
            "CANCELLED"
        ) {

            return order;
        }


        order.status =
            "CANCELLED";


        order.cancelledAt =
            new Date();


        order.cancellationReason =
            String(
                reason || ""
            ).trim();


        await order.save();


        return order;

    } catch (error) {

        console.error(
            "CANCEL ORDER ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   DELETE ORDER
   ========================================================================== */

const deleteOrder = async (
    orderId
) => {

    try {

        if (
            !mongoose.Types.ObjectId.isValid(
                orderId
            )
        ) {
            throw new Error(
                "Invalid order ID"
            );
        }


        const order =
            await Order.findById(
                orderId
            );


        if (!order) {
            throw new Error(
                "Order not found"
            );
        }


        if (
            String(
                order.paymentStatus ||
                ""
            )
                .trim()
                .toUpperCase() ===
            "PAID"
        ) {

            throw new Error(
                "Paid orders cannot be deleted"
            );
        }


        await OrderItem.deleteMany({
            orderId:
                order._id,
        });


        await Order.deleteOne({
            _id:
                order._id,
        });


        return {

            success:
                true,

            orderId:
                order._id,
        };

    } catch (error) {

        console.error(
            "DELETE ORDER ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   GET MANAGER ORDERS
   ========================================================================== */

/* ==========================================================================
   GET MANAGER ORDERS
   ========================================================================== */

const getManagerOrders = async (
    managerId,
    options = {}
) => {

    try {

        // =====================================================
        // VALIDATE MANAGER
        // =====================================================

        if (!managerId) {

            throw new Error(
                "Manager ID is required"
            );

        }


        if (
            !mongoose.Types.ObjectId.isValid(
                managerId
            )
        ) {

            throw new Error(
                "Invalid manager ID"
            );

        }


        // =====================================================
        // VERIFY MANAGER EXISTS
        // =====================================================

        const manager =
            await User.findById(
                managerId
            )
                .select(
                    "_id userId role"
                )
                .lean();


        if (!manager) {

            throw new Error(
                "Manager not found"
            );

        }


        // =====================================================
        // OPTIONS
        // =====================================================

        const {
            page = 1,
            limit = 20,
            status,
            paymentStatus,
        } = options;


        // =====================================================
        // FILTER
        // =====================================================

        const filter = {};


        if (status) {

            filter.status =
                status;

        }


        if (paymentStatus) {

            filter.paymentStatus =
                paymentStatus;

        }


        // =====================================================
        // PAGINATION
        // =====================================================

        const pageNumber =
            Math.max(
                1,
                Number(page) || 1
            );


        const limitNumber =
            Math.max(
                1,
                Number(limit) || 20
            );


        const skip =
            (
                pageNumber - 1
            ) *
            limitNumber;


        // =====================================================
        // GET ORDERS
        // =====================================================

        const [
            orders,
            total,
        ] = await Promise.all([

            Order.find(
                filter
            )
                .populate(
                    "userId",
                    "name userId email mobile role referralCode"
                )
                .sort({
                    createdAt: -1,
                })
                .skip(
                    skip
                )
                .limit(
                    limitNumber
                )
                .lean(),

            Order.countDocuments(
                filter
            ),

        ]);


        // =====================================================
        // NO ORDERS
        // =====================================================

        if (!orders.length) {

            return {

                orders: [],

                pagination: {

                    page:
                        pageNumber,

                    limit:
                        limitNumber,

                    total: 0,

                    pages: 0,

                },

            };

        }


        // =====================================================
        // ORDER IDS
        // =====================================================

        const orderIds =
            orders.map(
                (order) =>
                    order._id
            );


        // =====================================================
        // GET ORDER ITEMS
        // =====================================================

        const orderItems =
            await OrderItem.find({

                orderId: {
                    $in:
                        orderIds,
                },

            })
                .populate(
                    "productId",
                    "name productName images price category brand"
                )
                .lean();


        // =====================================================
        // GET PACKAGING ASSIGNMENTS
        // =====================================================

        const packagingAssignments =
            await PackagingAssignment.find({

                order: {
                    $in:
                        orderIds,
                },

            })
                .populate(
                    "staff",
                    "name loginId branchName branchMemberNumber isActive"
                )
                .lean();


        // =====================================================
        // GROUP ORDER ITEMS
        // =====================================================

        const itemsByOrder =
            {};


        for (
            const item
            of orderItems
        ) {

            const key =
                String(
                    item.orderId
                );


            if (
                !itemsByOrder[key]
            ) {

                itemsByOrder[key] =
                    [];

            }


            itemsByOrder[key].push(
                item
            );

        }


        // =====================================================
        // GROUP PACKAGING ASSIGNMENTS
        // =====================================================

        const packagingByOrder =
            {};


        for (
            const assignment
            of packagingAssignments
        ) {

            const key =
                String(
                    assignment.order
                );


            packagingByOrder[key] =
                assignment;

        }


        // =====================================================
        // ENRICH ORDERS
        // =====================================================

        const enrichedOrders =
            orders.map(
                (
                    order
                ) => {

                    const orderKey =
                        String(
                            order._id
                        );


                    const assignment =
                        packagingByOrder[
                            orderKey
                        ];


                    return {

                        ...order,


                        // ---------------------------------
                        // COMPLETE ORDER ITEMS
                        // ---------------------------------

                        items:
                            itemsByOrder[
                                orderKey
                            ] || [],


                        // ---------------------------------
                        // PACKAGING INFORMATION
                        // ---------------------------------

                        packaging:

                            assignment
                                ? {

                                    assignmentId:
                                        assignment._id,

                                    teamId:
                                        assignment.staff?._id ||
                                        null,

                                    teamName:
                                        assignment.staff?.name ||
                                        null,

                                    loginId:
                                        assignment.staff?.loginId ||
                                        null,

                                    branchName:
                                        assignment.staff?.branchName ||
                                        null,

                                    branchMemberNumber:
                                        assignment.staff?.branchMemberNumber ||
                                        null,

                                    isActive:
                                        assignment.staff?.isActive ??
                                        false,

                                    status:
                                        assignment.status ||
                                        "ASSIGNED",

                                    assignedAt:
                                        assignment.assignedAt ||
                                        null,

                                    packingStartedAt:
                                        assignment.packingStartedAt ||
                                        null,

                                    packedAt:
                                        assignment.packedAt ||
                                        null,

                                    readyForDispatchAt:
                                        assignment.readyForDispatchAt ||
                                        null,

                                }

                                : {

                                    assignmentId:
                                        null,

                                    teamId:
                                        null,

                                    teamName:
                                        null,

                                    loginId:
                                        null,

                                    branchName:
                                        null,

                                    branchMemberNumber:
                                        null,

                                    isActive:
                                        false,

                                    status:
                                        "UNASSIGNED",

                                    assignedAt:
                                        null,

                                    packingStartedAt:
                                        null,

                                    packedAt:
                                        null,

                                    readyForDispatchAt:
                                        null,

                                },

                    };

                }
            );


        // =====================================================
        // RETURN
        // =====================================================

        return {

            orders:
                enrichedOrders,

            pagination: {

                page:
                    pageNumber,

                limit:
                    limitNumber,

                total,

                pages:
                    Math.ceil(
                        total /
                        limitNumber
                    ),

            },

        };


    } catch (error) {

        console.error(
            "GET MANAGER ORDERS ERROR:",
            error
        );

        throw error;

    }

};
/* ==========================================================================
   GET ORDER STATS
   ========================================================================== */

const getOrderStats = async (
    filters = {}
) => {

    try {

        const {
            userId,
            orderType,
        } = filters;


        const query = {};


        if (userId) {

            if (
                mongoose.Types.ObjectId.isValid(
                    userId
                )
            ) {

                query.userId =
                    userId;
            }
        }


        if (orderType) {

            query.orderType =
                orderType;
        }


        const [
            totalOrders,
            paidOrders,
            pendingPaymentOrders,
            failedPaymentOrders,
            cancelledOrders,
            deliveredOrders,
        ] = await Promise.all([

            Order.countDocuments(
                query
            ),

            Order.countDocuments({

                ...query,

                paymentStatus:
                    "PAID",
            }),

            Order.countDocuments({

                ...query,

                paymentStatus:
                    "PENDING",
            }),

            Order.countDocuments({

                ...query,

                paymentStatus:
                    "FAILED",
            }),

            Order.countDocuments({

                ...query,

                status:
                    "CANCELLED",
            }),

            Order.countDocuments({

                ...query,

                status:
                    "DELIVERED",
            }),
        ]);


        const revenueResult =
            await Order.aggregate([

                {
                    $match: {

                        ...query,

                        paymentStatus:
                            "PAID",
                    },
                },

                {
                    $group: {

                        _id:
                            null,

                        totalRevenue: {

                            $sum:
                                "$finalAmount",
                        },
                    },
                },
            ]);


        const totalRevenue =
            Number(
                revenueResult?.[0]
                    ?.totalRevenue ||
                0
            );


        const subtotalResult =
            await Order.aggregate([

                {
                    $match: {

                        ...query,

                        paymentStatus:
                            "PAID",
                    },
                },

                {
                    $group: {

                        _id:
                            null,

                        totalSubtotal: {

                            $sum:
                                "$subtotal",
                        },
                    },
                },
            ]);


        const totalSubtotal =
            Number(
                subtotalResult?.[0]
                    ?.totalSubtotal ||
                0
            );


        const deliveryResult =
            await Order.aggregate([

                {
                    $match: {

                        ...query,

                        paymentStatus:
                            "PAID",
                    },
                },

                {
                    $group: {

                        _id:
                            null,

                        totalDelivery: {

                            $sum:
                                "$deliveryCharge",
                        },
                    },
                },
            ]);


        const totalDelivery =
            Number(
                deliveryResult?.[0]
                    ?.totalDelivery ||
                0
            );


        return {

            totalOrders,

            paidOrders,

            pendingPaymentOrders,

            failedPaymentOrders,

            cancelledOrders,

            deliveredOrders,

            totalRevenue,

            totalSubtotal,

            totalDelivery,
        };

    } catch (error) {

        console.error(
            "GET ORDER STATS ERROR:",
            error
        );

        throw error;
    }
};


/* ==========================================================================
   EXPORTS
   ========================================================================== */

module.exports = {

    createOrder,

    placeOrder,

    placeGuestOrder,

    getOrderById,

    getMyOrders,

    getAllOrders,

    getOrdersByMobile,

    linkGuestOrdersToUser,

    claimGuestOrders,

    claimGuestOrdersForMember,

    processSellingPoints,

    calculateOrderSellingPoints,

    updatePaymentStatus,

    updateOrderStatus,

    updateStatus,

    cancelOrder,

    deleteOrder,

    getManagerOrders,

    getOrderStats,
};