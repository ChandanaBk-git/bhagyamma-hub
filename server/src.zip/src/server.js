require("dotenv").config();

const app = require("./app");
const connectDB = require("./config/database");

const PORT = process.env.PORT || 5000;

const startServer = async () => {
    try {
        await connectDB();

        app.listen(PORT, () => {
            console.log(
                `🚀 Bhagyamma Hub Server running on http://localhost:${PORT}`
            );
        });
    } catch (error) {
        console.error("❌ Failed to start server");
        console.error(error.message);

        process.exit(1);
    }
};

startServer();