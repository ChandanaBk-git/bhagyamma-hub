
const PDFDocument = require("pdfkit");
const QRCode = require("qrcode");

const createOrderBillPdf = async (order, orderItems = []) => {
  const WIDTH = 298.3;
  const HEIGHT = 1100;
  const MARGIN = 22;
  const CONTENT = WIDTH - MARGIN * 2;

  const doc = new PDFDocument({
    size: [WIDTH, HEIGHT],
    margin: MARGIN,
    compress: true,
  });

  const chunks = [];
  doc.on("data", (chunk) => chunks.push(chunk));

  const pdfPromise = new Promise((resolve, reject) => {
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
  });

  const money = (value) =>
    `Rs. ${Number(value || 0).toFixed(2)}`;

  const value = (v) =>
    v === undefined || v === null || v === "" ? "-" : String(v);

  const amount = (...keys) => {
    for (const key of keys) {
      const v = order[key];
      if (v !== undefined && v !== null && v !== "" &&
          Number.isFinite(Number(v))) {
        return Number(v);
      }
    }
    return undefined;
  };

  const date = (v) => {
    if (!v) return "-";
    const d = new Date(v);
    return Number.isNaN(d.getTime())
      ? "-"
      : d.toLocaleDateString("en-IN", {
          day: "2-digit",
          month: "short",
          year: "numeric",
        });
  };

  const line = () => {
    const y = doc.y + 6;
    doc.moveTo(MARGIN, y)
      .lineTo(WIDTH - MARGIN, y)
      .lineWidth(0.6)
      .strokeColor("#D1D5DB")
      .stroke();
    doc.y = y + 10;
  };

  const heading = (label) => {
    doc.font("Helvetica-Bold")
      .fontSize(8)
      .fillColor("#111827")
      .text(label.toUpperCase(), MARGIN, doc.y, {
        width: CONTENT,
      });
    doc.moveDown(0.6);
  };

  const field = (label, val) => {
    doc.font("Helvetica")
      .fontSize(7)
      .fillColor("#6B7280")
      .text(label, MARGIN, doc.y, { width: CONTENT });

    doc.font("Helvetica-Bold")
      .fontSize(8)
      .fillColor("#111827")
      .text(value(val), MARGIN, doc.y, { width: CONTENT });

    doc.moveDown(0.45);
  };

  try {
    // Order and customer
    const customer =
      order.userId && typeof order.userId === "object"
        ? order.userId
        : order.user || order.customer || order.member || {};

    const delivery =
      order.deliveryDetails ||
      order.shippingAddress ||
      order.deliveryAddress ||
      order.address ||
      {};

    const orderNumber =
      order.orderNumber || order.orderId || order._id || "N/A";

    const customerName =
      delivery.name ||
      customer.name ||
      customer.fullName ||
      order.customerName;

    const address = (
      typeof delivery === "string"
        ? [delivery]
        : [
            delivery.addressLine1,
            delivery.addressLine2,
            delivery.address,
            delivery.street,
            delivery.landmark,
            delivery.city,
            delivery.district,
            delivery.state,
            delivery.pincode,
            delivery.postalCode,
          ]
    )
      .filter(Boolean)
      .map(String)
      .filter((v, i, arr) => arr.indexOf(v) === i)
      .join(", ");

    const mobile =
      delivery.mobile ||
      delivery.phone ||
      customer.mobile ||
      customer.phone ||
      order.mobile;

    const email = customer.email || delivery.email || order.email;

    // Order items
    const items = Array.isArray(orderItems) ? orderItems : [];

    const product = (item) => {
      const p = item.productId || item.product || {};
      return typeof p === "object" ? p : {};
    };

    const productName = (item) => {
      const p = product(item);
      return p.name || p.productName || item.productName || "Product";
    };

    const quantity = (item) =>
      Number(item.quantity ?? item.qty ?? 1);

    const price = (item) => {
      const p = product(item);
      return Number(
        item.unitPrice ??
        item.price ??
        item.sellingPrice ??
        p.sellingPrice ??
        p.price ??
        0
      );
    };

    const itemTotal = (item) => {
      const saved =
        item.totalPrice ??
        item.itemTotal ??
        item.subtotal ??
        item.lineTotal;

      return saved !== undefined && saved !== null
        ? Number(saved)
        : price(item) * quantity(item);
    };

    // Amounts
    const subtotal =
      amount("subtotal", "subTotal", "itemsTotal", "totalBeforeDiscount") ??
      items.reduce((sum, item) => sum + itemTotal(item), 0);

    const discount = Math.abs(
      amount("discountAmount", "discount", "memberDiscount") ?? 0
    );

    const deliveryCharge =
      amount("deliveryCharge", "shippingCharge", "deliveryFee") ?? 0;

    const total =
      amount("finalAmount", "grandTotal", "payableAmount", "totalAmount", "total") ??
      Math.max(0, subtotal - discount + deliveryCharge);

    const paymentMethod =
      order.paymentMethod ||
      order.paymentDetails?.method ||
      order.payment?.method ||
      "Not specified";

    const paymentStatus =
      order.paymentStatus ||
      order.paymentDetails?.status ||
      order.payment?.status ||
      "Not specified";

    const qr = await QRCode.toBuffer(
      JSON.stringify({
        orderNumber: String(orderNumber),
        orderId: String(order._id || ""),
      }),
      { type: "png", width: 160, margin: 1 }
    );

    // Header
    doc.font("Helvetica-Bold")
      .fontSize(15)
      .fillColor("#111827")
      .text("BHAGYAMMA HUB", MARGIN, MARGIN, {
        width: CONTENT,
        align: "center",
      });

    doc.moveDown(0.25);

    doc.font("Helvetica")
      .fontSize(7)
      .fillColor("#4B5563")
      .text("ORDER INVOICE / PACKING SLIP", {
        width: CONTENT,
        align: "center",
      });

    doc.moveDown(0.7);
    line();

    // Order number, date and QR
    const top = doc.y;
    const qrSize = 53;

    doc.image(qr, WIDTH - MARGIN - qrSize, top, {
      width: qrSize,
      height: qrSize,
    });

    doc.font("Helvetica")
      .fontSize(7)
      .fillColor("#6B7280")
      .text("ORDER NUMBER", MARGIN, top + 2);

    doc.font("Helvetica-Bold")
      .fontSize(9)
      .fillColor("#111827")
      .text(value(orderNumber), MARGIN, top + 14, {
        width: CONTENT - qrSize - 8,
      });

    doc.font("Helvetica")
      .fontSize(7)
      .fillColor("#6B7280")
      .text("ORDER DATE", MARGIN, top + 34);

    doc.font("Helvetica-Bold")
      .fontSize(8)
      .fillColor("#111827")
      .text(date(order.createdAt || order.orderDate || order.date),
        MARGIN, top + 44);

    doc.y = top + qrSize + 8;
    line();

    // Shipping details
    heading("Ship To");

    doc.font("Helvetica-Bold")
      .fontSize(9)
      .fillColor("#111827")
      .text(value(customerName), MARGIN, doc.y, {
        width: CONTENT,
      });

    doc.moveDown(0.3);

    if (address) {
      doc.font("Helvetica")
        .fontSize(8)
        .fillColor("#374151")
        .text(address, MARGIN, doc.y, {
          width: CONTENT,
          lineGap: 2,
        });
      doc.moveDown(0.5);
    }

    if (mobile) field("MOBILE", mobile);
    if (email) field("EMAIL", email);

    line();

    // Payment
    heading("Payment Information");
    field("Payment Method", paymentMethod);
    field("Payment Status", paymentStatus);

    line();

    // Product table
    heading("Order Summary");

    const qtyX = WIDTH - MARGIN - 91;
    const priceX = WIDTH - MARGIN - 54;
    const totalX = WIDTH - MARGIN - 37;
    const productWidth = qtyX - MARGIN - 5;
    const headerY = doc.y;

    doc.font("Helvetica-Bold")
      .fontSize(6.3)
      .fillColor("#374151")
      .text("PRODUCT", MARGIN, headerY, {
        width: productWidth,
      })
      .text("QTY", qtyX, headerY, {
        width: 23,
        align: "center",
      })
      .text("PRICE", priceX - 6, headerY, {
        width: 35,
        align: "right",
      })
      .text("TOTAL", totalX, headerY, {
        width: 37,
        align: "right",
      });

    doc.y = headerY + 12;
    line();

    if (!items.length) {
      doc.font("Helvetica")
        .fontSize(8)
        .fillColor("#6B7280")
        .text("No order items found.", MARGIN, doc.y);
      doc.moveDown();
      line();
    }

    for (const item of items) {
      const y = doc.y;
      const name = productName(item);

      doc.font("Helvetica")
        .fontSize(7.2)
        .fillColor("#111827")
        .text(name, MARGIN, y, {
          width: productWidth,
          lineGap: 1,
        });

      const nameHeight = doc.heightOfString(name, {
        width: productWidth,
        font: "Helvetica",
        fontSize: 7.2,
      });

      doc.fontSize(6.5)
        .text(String(quantity(item)), qtyX, y, {
          width: 23,
          align: "center",
        })
        .text(money(price(item)), priceX - 6, y, {
          width: 35,
          align: "right",
        })
        .text(money(itemTotal(item)), totalX, y, {
          width: 37,
          align: "right",
        });

      doc.y = y + Math.max(nameHeight, 12) + 7;
      line();
    }

    // Compact amount summary
    const summaryRow = (label, val) => {
      const y = doc.y;

      doc.font("Helvetica")
        .fontSize(7.5)
        .fillColor("#4B5563")
        .text(label, MARGIN, y, {
          width: CONTENT - 78,
        })
        .text(money(val), WIDTH - MARGIN - 78, y, {
          width: 78,
          align: "right",
        });

      doc.y = y + 15;
    };

    summaryRow("Product Subtotal", subtotal);
    summaryRow("Delivery Charge", deliveryCharge);

    line();

    // Total payable with bracketed text
    const boxY = doc.y;
    const boxHeight = 58;

    doc.roundedRect(MARGIN, boxY, CONTENT, boxHeight, 4)
      .fill("#F3F4F6");

    doc.font("Helvetica-Bold")
      .fontSize(8)
      .fillColor("#111827")
      .text("TOTAL PAYABLE", MARGIN + 8, boxY + 7);

    doc.font("Helvetica-Bold")
      .fontSize(11)
      .fillColor("#111827")
      .text(money(total), MARGIN + 8, boxY + 19);

    doc.font("Helvetica")
      .fontSize(6.3)
      .fillColor("#4B5563")
      .text(
        `(Inclusive of all applicable taxes; ${
          discount > 0
            ? `discount of ${money(discount)} applied`
            : "no discount applied"
        })`,
        MARGIN + 8,
        boxY + 39,
        { width: CONTENT - 16 }
      );

    doc.y = boxY + boxHeight + 10;
    line();

    // Footer
    doc.font("Helvetica-Bold")
      .fontSize(8)
      .fillColor("#111827")
      .text("Thank you for choosing Bhagyamma Hub!", {
        width: CONTENT,
        align: "center",
      });

    doc.moveDown(0.4);

    doc.font("Helvetica")
      .fontSize(6.5)
      .fillColor("#6B7280")
      .text("Order bill / packing reference. Not a GST tax invoice.", {
        width: CONTENT,
        align: "center",
      });

    doc.end();
    return await pdfPromise;
  } catch (error) {
    doc.destroy();
    throw error;
  }
};

module.exports = { createOrderBillPdf };
