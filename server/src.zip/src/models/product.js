const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
  {
    // =================================================
    // BASIC PRODUCT INFORMATION
    // =================================================

    productName: {
      type: String,
      required: true,
      trim: true,
    },

    parentCategory: {
  type: mongoose.Schema.Types.ObjectId,
  ref: "Category",
  required: false,
  default: null,
},
    // Existing category field — preserve old products
    category: {
      type: String,
      required: true,
      trim: true,
    },

    // NEW: Multiple category references
    categories: {
      type: [
        {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Category",
        },
      ],
      default: [],
    },

    brand: {
      type: String,
      default: "Bhagyamma Hub",
      trim: true,
    },

    description: {
      type: String,
      required: true,
      trim: true,
    },

    benefits: {
      type: String,
      default: "",
      trim: true,
    },

    ingredients: {
      type: String,
      default: "",
      trim: true,
    },

    usage: {
      type: String,
      default: "",
      trim: true,
    },

    storage: {
      type: String,
      default: "",
      trim: true,
    },

    // =================================================
    // PRODUCT QUANTITY / PACK SIZE
    // =================================================

    weight: {
      type: String,
      default: "",
      trim: true,
    },

    quantity: {
      type: String,
      default: "",
      trim: true,
    },

    shelfLife: {
      type: String,
      default: "",
      trim: true,
    },

    // =================================================
    // MANUFACTURING INFORMATION
    // =================================================

    manufacturer: {
      type: String,
      default: "Bhagyamma Hub",
      trim: true,
    },

    countryOfOrigin: {
      type: String,
      default: "India",
      trim: true,
    },

    // =================================================
    // SKU
    // =================================================

    sku: {
      type: String,
      default: "",
      trim: true,
    },

    // =================================================
    // PRICE
    // =================================================

    price: {
      type: Number,
      required: true,
      min: 0,
    },

    // =================================================
    // PRODUCT IMAGES
    // =================================================

    images: {
      type: [String],

      validate: {
        validator: function (value) {
          return value.length <= 4;
        },

        message: "Maximum 4 images are allowed.",
      },

      default: [],
    },

    // =================================================
    // STATUS
    // =================================================

    status: {
      type: String,
      enum: ["Active", "Inactive"],
      default: "Active",
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Product", productSchema);