
const mongoose = require("mongoose");

const phonePeCheckoutSessionSchema = new mongoose.Schema(
  {
    // Unique PhonePe payment reference
    merchantOrderId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    // PRODUCT checkout or new MEMBER registration
    sessionType: {
      type: String,
      required: true,
      enum: ["PRODUCT", "MEMBERSHIP"],
      index: true,
    },

    // Store only the hash of the session access token
    sessionTokenHash: {
      type: String,
      required: true,
      select: false,
    },

    // Payment amount in paise
    amountPaise: {
      type: Number,
      required: true,
      min: 1,
    },

    // Temporary checkout or registration information
    // Never store a plain-text password here.
    checkoutData: {
      type: mongoose.Schema.Types.Mixed,
      default: null,
    },

    registrationData: {
      type: mongoose.Schema.Types.Mixed,
      default: null,
      select: false,
    },

    // Internal payment-session lifecycle
    status: {
      type: String,
      enum: [
        "PENDING",
        "PROCESSING",
        "COMPLETED",
        "FAILED",
        "EXPIRED",
      ],
      default: "PENDING",
      index: true,
    },

    phonePeState: {
      type: String,
      default: "PENDING",
    },

    phonePeOrderId: {
      type: String,
      default: null,
    },

    phonePeTransactionId: {
      type: String,
      default: null,
    },

    // Set after successful payment processing
    createdOrderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
      default: null,
    },

    createdUserId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },

    completedAt: {
      type: Date,
      default: null,
    },

    // MongoDB TTL automatically removes expired sessions
    expiresAt: {
      type: Date,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// TTL cleanup for temporary sessions
phonePeCheckoutSessionSchema.index(
  { expiresAt: 1 },
  { expireAfterSeconds: 0 }
);

// Prevent multiple active sessions with the same merchant order ID
phonePeCheckoutSessionSchema.index(
  { merchantOrderId: 1 },
  { unique: true }
);

module.exports = mongoose.model(
  "PhonePeCheckoutSession",
  phonePeCheckoutSessionSchema
);
