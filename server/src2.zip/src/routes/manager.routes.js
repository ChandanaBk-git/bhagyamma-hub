const express = require("express");

const router = express.Router();

const managerController =
    require("../controllers/manager.controller");

const {
    protect,
    authorize,
} = require("../middleware/auth.middleware");


/*
=========================================================
MANAGER ROUTER
Base URL:

/api/v1/manager
=========================================================
*/


/*
=========================================================
AUTHENTICATION

Every manager API requires a valid JWT.
=========================================================
*/

router.use(protect);


/*
=========================================================
MANAGER ROLE ONLY

Every route below this line is restricted to MANAGER.
=========================================================
*/

router.use(
    authorize("MANAGER")
);


/*
=========================================================
DASHBOARD
=========================================================
*/

router.get(
    "/dashboard",
    managerController.getDashboard
);


/*
=========================================================
PRODUCTS
=========================================================
Manager can view products only.
No add/edit/delete routes here.
=========================================================
*/

/*
=========================================================
COMMISSIONS
=========================================================
*/

router.get(
    "/commissions",
    managerController.getManagerCommissions
);

router.get(
    "/products",
    managerController.getManagerProducts
);


/*
=========================================================
MEMBERS
=========================================================
*/

router.get(
    "/members",
    managerController.getMembers
);


/*
=========================================================
BASIC MEMBER DETAILS
=========================================================
*/

router.get(
    "/members/:id",
    managerController.getMemberById
);


/*
=========================================================
COMPLETE MEMBER DETAILS
=========================================================
*/

router.get(
    "/members/:id/details",
    managerController.getMemberDetails
);


/*
=========================================================
REFERRAL TREE
=========================================================
*/

router.get(
    "/referral-tree",
    managerController.getReferralTree
);


/*
=========================================================
PROFILE
=========================================================
*/

router.get(
    "/profile",
    managerController.getProfile
);


module.exports = router;