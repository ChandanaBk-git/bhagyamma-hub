const managerService =
    require("../services/manager.service");

const ApiError =
    require("../utils/ApiError");


/*
=========================================================
GET MANAGER ID
=========================================================
The manager ID comes from the verified JWT.
=========================================================
*/

const getManagerId = (req) => {

    const managerId =
        req.user?.id;

    if (!managerId) {
        throw new ApiError(
            401,
            "Manager ID not found in authentication token."
        );
    }

    return managerId;
};


/*
=========================================================
DASHBOARD
=========================================================
*/

const getDashboard = async (
    req,
    res,
    next
) => {

    try {

        const managerId =
            getManagerId(req);

        const data =
            await managerService.getDashboard(
                managerId
            );

        res.status(200).json({
            success: true,
            data,
        });

    } catch (error) {

        next(error);

    }
};


/*
=========================================================
MEMBERS
=========================================================
*/

const getMembers = async (
    req,
    res,
    next
) => {

    try {

        const managerId =
            getManagerId(req);

        const members =
            await managerService.getMembers(
                managerId
            );

        res.status(200).json({
            success: true,
            data: members,
        });

    } catch (error) {

        next(error);

    }
};


/*
=========================================================
BASIC MEMBER DETAILS
=========================================================
*/

const getMemberById = async (
    req,
    res,
    next
) => {

    try {

        const managerId =
            getManagerId(req);

        const member =
            await managerService.getMemberById(
                managerId,
                req.params.id
            );

        if (!member) {

            throw new ApiError(
                404,
                "Member not found or not assigned to this manager."
            );

        }

        res.status(200).json({
            success: true,
            data: member,
        });

    } catch (error) {

        next(error);

    }
};


/*
=========================================================
COMPLETE MEMBER DETAILS
=========================================================
*/

const getMemberDetails = async (
    req,
    res,
    next
) => {

    try {

        const managerId =
            getManagerId(req);

        const data =
            await managerService.getMemberDetails(
                managerId,
                req.params.id
            );

        if (!data) {

            throw new ApiError(
                404,
                "Member not found or not assigned to this manager."
            );

        }

        res.status(200).json({
            success: true,
            data,
        });

    } catch (error) {

        next(error);

    }
};


/*
=========================================================
REFERRAL TREE
=========================================================
*/

const getReferralTree = async (
    req,
    res,
    next
) => {

    try {

        const managerId =
            getManagerId(req);

        const data =
            await managerService.getReferralTree(
                managerId
            );

        if (!data) {

            throw new ApiError(
                404,
                "Manager not found."
            );

        }

        res.status(200).json({
            success: true,
            data,
        });

    } catch (error) {

        next(error);

    }
};


/*
=========================================================
PROFILE
=========================================================
*/

const getProfile = async (
    req,
    res,
    next
) => {

    try {

        const managerId =
            getManagerId(req);

        const data =
            await managerService.getProfile(
                managerId
            );

        if (!data) {

            throw new ApiError(
                404,
                "Manager not found."
            );

        }

        res.status(200).json({
            success: true,
            data,
        });

    } catch (error) {

        next(error);

    }
};

/*
=========================================================
MANAGER PRODUCTS
=========================================================
*/

const getManagerProducts = async (
    req,
    res,
    next
) => {

    try {

        const managerId =
            getManagerId(req);


        const products =
            await managerService.getManagerProducts(
                managerId
            );


        res.status(200).json({

            success: true,

            data: products,

        });

    } catch (error) {

        next(error);

    }

};
/*
=========================================================
MANAGER COMMISSIONS
=========================================================
*/

const getManagerCommissions = async (
    req,
    res,
    next
) => {

    try {

        const managerId =
            getManagerId(req);


        const commissions =
            await managerService.getManagerCommissions(
                managerId
            );


        res.status(200).json({

            success: true,

            data: commissions,

        });

    } catch (error) {

        next(error);

    }

};

module.exports = {

    getDashboard,

    getMembers,

    getMemberById,

    getMemberDetails,

    getReferralTree,

    getProfile,

    getManagerProducts,

    getManagerCommissions,

};