const User =
  require("../models/user.model");

const Wallet =
  require("../models/wallet.model");

const Order =
  require("../models/order.model");

const OrderItem =
  require("../models/orderItem.model");

const Product =
  require("../models/product");

const ApiError =
  require("../utils/ApiError");

const walletRepository =
  require("../repositories/wallet.repository");

const walletTransactionRepository =
  require("../repositories/walletTransaction.repository");

const withdrawRepository =
  require("../repositories/withdraw.repository");

const commissionRepository =
  require("../repositories/commission.repository");

const sellingPointRepository =
  require("../repositories/sellingPoint.repository");

const orderRepository =
  require("../repositories/order.repository");


// =====================================================
// GET COMPLETE DOWNLINE
// =====================================================

const getDownline = (
  users,
  parentId,
  result = []
) => {

  const children =
    users.filter(
      (user) =>
        user.sponsorId &&
        String(
          user.sponsorId
        ) ===
        String(
          parentId
        )
    );


  children.forEach(
    (child) => {

      result.push(
        child
      );


      getDownline(
        users,
        child._id,
        result
      );

    }
  );


  return result;

};


// =====================================================
// BUILD MANAGER MEMBER NETWORK
// =====================================================

const getManagerMembers = (
  users,
  managerId
) => {

  const managerIdString =
    String(managerId);


  const result =
    new Map();


  // ---------------------------------------------------
  // DIRECTLY ASSIGNED MEMBERS
  // ---------------------------------------------------

  users
    .filter(
      (user) =>
        String(
          user.managerId || ""
        ) ===
        managerIdString &&
        String(
          user.role || ""
        ).toUpperCase() ===
        "MEMBER"
    )
    .forEach(
      (user) => {

        result.set(
          String(
            user._id
          ),
          user
        );

      }
    );


  // ---------------------------------------------------
  // REFERRAL NETWORK
  // ---------------------------------------------------

  const queue = [
    managerIdString,
  ];


  const visited =
    new Set();


  while (
    queue.length > 0
  ) {

    const parentId =
      queue.shift();


    if (
      visited.has(
        parentId
      )
    ) {

      continue;

    }


    visited.add(
      parentId
    );


    users
      .filter(
        (user) =>
          String(
            user.sponsorId || ""
          ) ===
          parentId
      )
      .forEach(
        (child) => {

          const childId =
            String(
              child._id
            );


          if (
            String(
              child.role || ""
            ).toUpperCase() ===
            "MEMBER"
          ) {

            result.set(
              childId,
              child
            );

          }


          if (
            !visited.has(
              childId
            )
          ) {

            queue.push(
              childId
            );

          }

        }
      );

  }


  return Array.from(
    result.values()
  );

};


// =====================================================
// GET MANAGER NETWORK MEMBER IDS
// =====================================================

const getManagerNetworkMemberIds =
  async (
    managerId
  ) => {

    const users =
      await User.find()
        .select(
          [
            "_id",
            "role",
            "managerId",
            "sponsorId",
          ].join(" ")
        )
        .lean();


    const members =
      getManagerMembers(
        users,
        managerId
      );


    return members.map(
      (member) =>
        member._id
    );

  };


// =====================================================
// GET MANAGER DASHBOARD
// =====================================================

const getDashboard = async (
  managerId
) => {

  // ---------------------------------------------------
  // LOAD USERS
  // ---------------------------------------------------

  const users =
    await User.find()
      .select(
        [
          "_id",
          "name",
          "userId",
          "email",
          "mobile",
          "role",
          "referralCode",
          "sponsorId",
          "managerId",
          "isActive",
          "kycStatus",
          "paymentStatus",
          "welcomeKitStatus",
          "sellingPoints",
          "lifetimePurchase",
          "createdAt",
        ].join(" ")
      )
      .lean();


  // ---------------------------------------------------
  // MANAGER
  // ---------------------------------------------------

  const manager =
    users.find(
      (user) =>
        String(
          user._id
        ) ===
        String(
          managerId
        )
    );


  if (!manager) {

    throw new ApiError(
      404,
      "Manager not found."
    );

  }


  // ---------------------------------------------------
  // MANAGED MEMBERS
  // ---------------------------------------------------

  const members =
    getManagerMembers(
      users,
      managerId
    );


  const memberIds =
    members.map(
      (member) =>
        member._id
    );


  // ---------------------------------------------------
  // MEMBER COUNTS
  // ---------------------------------------------------

  const totalMembers =
    members.length;


  const activeMembers =
    members.filter(
      (member) =>
        member.isActive !== false
    ).length;


  const pendingMembers =
    members.filter(
      (member) =>
        String(
          member.paymentStatus || ""
        ).toUpperCase() !==
        "PAID"
    ).length;


  const pendingKyc =
    members.filter(
      (member) =>
        String(
          member.kycStatus || ""
        ).toUpperCase() !==
        "VERIFIED"
    ).length;


  // ---------------------------------------------------
  // MANAGED MEMBER ORDERS
  // ---------------------------------------------------

  const orders =
    memberIds.length > 0
      ? await Order.find({
          userId: {
            $in: memberIds,
          },
        })
          .select(
            [
              "_id",
              "userId",
              "orderNumber",
              "finalAmount",
              "status",
              "paymentStatus",
              "createdAt",
            ].join(" ")
          )
          .sort({
            createdAt: -1,
          })
          .lean()
      : [];


  // ---------------------------------------------------
  // ORDER TOTAL
  // ---------------------------------------------------

  const totalOrders =
    orders.length;


  const totalSales =
    orders.reduce(
      (
        total,
        order
      ) =>
        total +
        Number(
          order.finalAmount || 0
        ),
      0
    );


  // ---------------------------------------------------
  // MANAGER COMMISSIONS ONLY
  //
  // IMPORTANT:
  // Do NOT sum all member commissions here.
  //
  // Dashboard commission belongs ONLY to manager.
  // ---------------------------------------------------

  const managerCommissions =
    await commissionRepository.findByReceivers(
      [
        managerId,
      ]
    );


  // ---------------------------------------------------
  // COMMISSION TOTAL
  // ---------------------------------------------------

  const totalCommission =
    managerCommissions.reduce(
      (
        total,
        commission
      ) =>
        total +
        Number(
          commission.commissionAmount || 0
        ),
      0
    );


  // ---------------------------------------------------
  // PAID COMMISSION
  // ---------------------------------------------------

  const paidCommission =
    managerCommissions
      .filter(
        (commission) =>
          String(
            commission.status || ""
          ).toUpperCase() ===
          "PAID"
      )
      .reduce(
        (
          total,
          commission
        ) =>
          total +
          Number(
            commission.commissionAmount || 0
          ),
        0
      );


  // ---------------------------------------------------
  // PENDING COMMISSION
  // ---------------------------------------------------

  const pendingCommission =
    managerCommissions
      .filter(
        (commission) =>
          String(
            commission.status || ""
          ).toUpperCase() ===
          "PENDING"
      )
      .reduce(
        (
          total,
          commission
        ) =>
          total +
          Number(
            commission.commissionAmount || 0
          ),
        0
      );


  // ---------------------------------------------------
  // PRODUCTS
  // ---------------------------------------------------

  const totalProducts =
    await Product.countDocuments();


  const activeProducts =
    await Product.countDocuments({
      status:
        "Active",
    });


  // ---------------------------------------------------
  // RECENT ORDERS
  // ---------------------------------------------------

  const recentOrders =
    orders.slice(
      0,
      10
    );


  // ---------------------------------------------------
  // MEMBER SUMMARY
  // ---------------------------------------------------

  const memberSummary =
    members.map(
      (member) => {

        const memberId =
          String(
            member._id
          );


        const memberOrders =
          orders.filter(
            (order) =>
              String(
                order.userId
              ) ===
              memberId
          );


        return {

          _id:
            member._id,

          name:
            member.name || "",

          userId:
            member.userId || "",

          mobile:
            member.mobile || "",

          isActive:
            member.isActive !== false,

          kycStatus:
            member.kycStatus || "",

          paymentStatus:
            member.paymentStatus || "",

          orders: {

            count:
              memberOrders.length,

            sales:
              memberOrders.reduce(
                (
                  total,
                  order
                ) =>
                  total +
                  Number(
                    order.finalAmount || 0
                  ),
                0
              ),

          },

        };

      }
    );


  // ---------------------------------------------------
  // RETURN DASHBOARD
  // ---------------------------------------------------

  return {

    summary: {

      totalMembers,

      activeMembers,

      pendingMembers,

      pendingKyc,

      // DO NOT USE THESE ON MANAGER DASHBOARD
      totalWalletBalance: 0,

      totalSellingPoints: 0,

      // MANAGER ONLY
      totalCommission,

      paidCommission,

      pendingCommission,

      // NETWORK ORDERS
      totalOrders,

      totalSales,

      totalProducts,

      activeProducts,

    },


    commissionSummary: {

      total:
        totalCommission,

      paid:
        paidCommission,

      pending:
        pendingCommission,

      transactionCount:
        managerCommissions.length,

    },


    networkSummary: {

      totalMembers,

      activeMembers,

      pendingPayment:
        pendingMembers,

      pendingKyc,

    },


    members:
      memberSummary,


    recentOrders,

  };

};


// =====================================================
// GET MANAGER MEMBERS
// =====================================================

const getMembers = async (
  managerId
) => {

  const users =
    await User.find()
      .select(
        [
          "_id",
          "name",
          "userId",
          "email",
          "mobile",
          "role",
          "referralCode",
          "sponsorId",
          "managerId",
          "isActive",
          "kycStatus",
          "paymentStatus",
          "welcomeKitStatus",
          "sellingPoints",
          "lifetimePurchase",
          "createdAt",
        ].join(" ")
      )
      .lean();


  const members =
    getManagerMembers(
      users,
      managerId
    );


  const memberIds =
    members.map(
      (member) =>
        member._id
    );


  if (
    memberIds.length ===
    0
  ) {

    return [];

  }


  // ---------------------------------------------------
  // WALLETS
  // ---------------------------------------------------

  const wallets =
    await Wallet.find({
      user: {
        $in:
          memberIds,
      },
    }).lean();


  const walletMap =
    new Map();


  wallets.forEach(
    (wallet) => {

      walletMap.set(
        String(
          wallet.user
        ),
        wallet
      );

    }
  );


  // ---------------------------------------------------
  // COMMISSIONS
  // ---------------------------------------------------

  const commissions =
    await commissionRepository
      .findByReceivers(
        memberIds
      );


  const commissionMap =
    new Map();


  commissions.forEach(
    (commission) => {

      const receiverId =
        String(
          commission.receiver
        );


      if (
        !commissionMap.has(
          receiverId
        )
      ) {

        commissionMap.set(
          receiverId,
          []
        );

      }


      commissionMap
        .get(
          receiverId
        )
        .push(
          commission
        );

    }
  );


  // ---------------------------------------------------
  // ORDERS
  // ---------------------------------------------------

  const orders =
    await Order.find({
      userId: {
        $in:
          memberIds,
      },
    })
      .select(
        [
          "_id",
          "userId",
          "orderNumber",
          "finalAmount",
          "sellingPoints",
          "paymentStatus",
          "status",
          "createdAt",
        ].join(" ")
      )
      .lean();


  const orderMap =
    new Map();


  orders.forEach(
    (order) => {

      const userId =
        String(
          order.userId
        );


      if (
        !orderMap.has(
          userId
        )
      ) {

        orderMap.set(
          userId,
          []
        );

      }


      orderMap
        .get(
          userId
        )
        .push(
          order
        );

    }
  );


  // ---------------------------------------------------
  // FINAL MEMBER RESPONSE
  // ---------------------------------------------------

  return members.map(
    (member) => {

      const id =
        String(
          member._id
        );


      const wallet =
        walletMap.get(
          id
        );


      const memberCommissions =
        commissionMap.get(
          id
        ) || [];


      const memberOrders =
        orderMap.get(
          id
        ) || [];


      const commissionTotal =
        memberCommissions.reduce(
          (
            total,
            item
          ) =>
            total +
            Number(
              item.commissionAmount || 0
            ),
          0
        );


      const commissionPaid =
        memberCommissions
          .filter(
            (item) =>
              String(
                item.status || ""
              ).toUpperCase() ===
              "PAID"
          )
          .reduce(
            (
              total,
              item
            ) =>
              total +
              Number(
                item.commissionAmount || 0
              ),
            0
          );


      const commissionPending =
        memberCommissions
          .filter(
            (item) =>
              String(
                item.status || ""
              ).toUpperCase() ===
              "PENDING"
          )
          .reduce(
            (
              total,
              item
            ) =>
              total +
              Number(
                item.commissionAmount || 0
              ),
            0
          );


      const salesValue =
        memberOrders.reduce(
          (
            total,
            order
          ) =>
            total +
            Number(
              order.finalAmount || 0
            ),
          0
        );


      return {

        ...member,

        wallet: {

          balance:
            Number(
              wallet?.balance || 0
            ),

          totalCommission:
            Number(
              wallet?.totalCommission || 0
            ),

          totalBonus:
            Number(
              wallet?.totalBonus || 0
            ),

          totalWithdrawn:
            Number(
              wallet?.totalWithdrawn || 0
            ),

        },


        sellingPoints:
          Number(
            member.sellingPoints || 0
          ),


        commission: {

          total:
            commissionTotal,

          paid:
            commissionPaid,

          pending:
            commissionPending,

          count:
            memberCommissions.length,

        },


        orders: {

          count:
            memberOrders.length,

          salesValue,

          paidCount:
            memberOrders.filter(
              (order) =>
                String(
                  order.paymentStatus || ""
                ).toUpperCase() ===
                "PAID"
            ).length,

        },

      };

    }
  );

};


// =====================================================
// GET BASIC MEMBER DETAILS
// =====================================================

const getMemberById = async (
  managerId,
  memberId
) => {

  const users =
    await User.find()
      .select(
        [
          "_id",
          "name",
          "userId",
          "email",
          "mobile",
          "role",
          "referralCode",
          "sponsorId",
          "managerId",
          "isActive",
          "kycStatus",
          "paymentStatus",
          "welcomeKitStatus",
          "sellingPoints",
          "lifetimePurchase",
          "createdAt",
        ].join(" ")
      )
      .lean();


  const members =
    getManagerMembers(
      users,
      managerId
    );


  const member =
    members.find(
      (item) =>
        String(
          item._id
        ) ===
        String(
          memberId
        )
    );


  if (!member) {

    return null;

  }


  const wallet =
    await walletRepository
      .findWalletByUser(
        member._id
      );


  const orders =
    await orderRepository
      .findByUser(
        member._id
      );


  const commissions =
    await commissionRepository
      .findByUser(
        member._id
      );


  return {

    ...member,

    wallet: {

      balance:
        Number(
          wallet?.balance || 0
        ),

      totalCommission:
        Number(
          wallet?.totalCommission || 0
        ),

      totalBonus:
        Number(
          wallet?.totalBonus || 0
        ),

      totalWithdrawn:
        Number(
          wallet?.totalWithdrawn || 0
        ),

    },


    orders: {

      count:
        orders.length,

      salesValue:
        orders.reduce(
          (
            total,
            order
          ) =>
            total +
            Number(
              order.finalAmount || 0
            ),
          0
        ),

    },


    commission: {

      count:
        commissions.length,

      total:
        commissions.reduce(
          (
            total,
            item
          ) =>
            total +
            Number(
              item.commissionAmount || 0
            ),
          0
        ),

    },

  };

};


// =====================================================
// GET COMPLETE MEMBER DETAILS
// =====================================================

const getMemberDetails = async (
  managerId,
  memberId
) => {

  const users =
    await User.find()
      .select(
        [
          "_id",
          "name",
          "userId",
          "email",
          "mobile",
          "role",
          "referralCode",
          "sponsorId",
          "managerId",
          "isActive",
          "kycStatus",
          "paymentStatus",
          "welcomeKitStatus",
          "sellingPoints",
          "lifetimePurchase",
          "createdAt",
        ].join(" ")
      )
      .lean();


  const managerMembers =
    getManagerMembers(
      users,
      managerId
    );


  const belongsToManager =
    managerMembers.some(
      (item) =>
        String(
          item._id
        ) ===
        String(
          memberId
        )
    );


  if (
    !belongsToManager
  ) {

    return null;

  }


  const member =
    await User.findOne({
      _id:
        memberId,
    })
      .select(
        "-password -otp -otpExpiry -resetPasswordToken -resetPasswordExpiry"
      )
      .populate(
        "managerId",
        "name userId mobile"
      )
      .lean();


  if (!member) {

    return null;

  }


  // ---------------------------------------------------
  // WALLET
  // ---------------------------------------------------

  const wallet =
    await walletRepository
      .findWalletByUser(
        member._id
      );


  // ---------------------------------------------------
  // WALLET TRANSACTIONS
  // ---------------------------------------------------

  let walletTransactions =
    [];


  if (wallet) {

    walletTransactions =
      await walletTransactionRepository
        .getTransactions(
          wallet._id
        );

  }


  // ---------------------------------------------------
  // WITHDRAWALS
  // ---------------------------------------------------

  const withdrawals =
    await withdrawRepository
      .findByUser(
        member._id
      );


  // ---------------------------------------------------
  // COMMISSIONS
  // ---------------------------------------------------

  const commissions =
    await commissionRepository
      .findByUser(
        member._id
      );


  // ---------------------------------------------------
  // SELLING POINT HISTORY
  // ---------------------------------------------------

  const sellingPointHistory =
    await sellingPointRepository
      .getTransactions(
        member._id
      );


  // ---------------------------------------------------
  // ORDERS
  // ---------------------------------------------------

  const orders =
    await orderRepository
      .findByUser(
        member._id
      );


  // ---------------------------------------------------
  // DIRECT DOWNLINE
  // ---------------------------------------------------

  const downline =
    await User.find({
      sponsorId:
        member._id,

      managerId:
        managerId,

      role:
        "MEMBER",

    })
      .select(
        [
          "name",
          "userId",
          "mobile",
          "role",
          "sponsorId",
          "managerId",
          "referralCode",
          "isActive",
          "sellingPoints",
          "lifetimePurchase",
          "createdAt",
        ].join(" ")
      )
      .sort({
        createdAt:
          1,
      })
      .lean();


  // ---------------------------------------------------
  // WALLET SUMMARY
  // ---------------------------------------------------

  const walletSummary = {

    balance:
      Number(
        wallet?.balance || 0
      ),

    totalCommission:
      Number(
        wallet?.totalCommission || 0
      ),

    totalBonus:
      Number(
        wallet?.totalBonus || 0
      ),

    totalWithdrawn:
      Number(
        wallet?.totalWithdrawn || 0
      ),

  };


  // ---------------------------------------------------
  // COMMISSION SUMMARY
  // ---------------------------------------------------

  const commissionSummary = {

    total:
      commissions.reduce(
        (
          sum,
          item
        ) =>
          sum +
          Number(
            item.commissionAmount || 0
          ),
        0
      ),

    paid:
      commissions
        .filter(
          (item) =>
            String(
              item.status || ""
            ).toUpperCase() ===
            "PAID"
        )
        .reduce(
          (
            sum,
            item
          ) =>
            sum +
            Number(
              item.commissionAmount || 0
            ),
          0
        ),

    pending:
      commissions
        .filter(
          (item) =>
            String(
              item.status || ""
            ).toUpperCase() ===
            "PENDING"
        )
        .reduce(
          (
            sum,
            item
          ) =>
            sum +
            Number(
              item.commissionAmount || 0
            ),
          0
        ),

    transactionCount:
      commissions.length,

  };


  // ---------------------------------------------------
  // ORDER SUMMARY
  // ---------------------------------------------------

  const orderSummary = {

    total:
      orders.length,

    paid:
      orders.filter(
        (order) =>
          String(
            order.paymentStatus || ""
          ).toUpperCase() ===
          "PAID"
      ).length,

    pending:
      orders.filter(
        (order) =>
          String(
            order.paymentStatus || ""
          ).toUpperCase() !==
          "PAID"
      ).length,

    totalPurchase:
      orders.reduce(
        (
          sum,
          order
        ) =>
          sum +
          Number(
            order.finalAmount || 0
          ),
        0
      ),

  };


  return {

    member,

    wallet:
      walletSummary,

    walletTransactions,

    withdrawals,

    commissions,

    commissionSummary,

    sellingPoints:
      Number(
        member.sellingPoints || 0
      ),

    sellingPointHistory,

    orders,

    orderSummary,

    downline,

    referralTree: {

      userId:
        member.userId,

      name:
        member.name,

      children:
        downline,

    },

  };

};


// =====================================================
// GET MANAGER REFERRAL TREE
// =====================================================

const getReferralTree = async (
  managerId
) => {

  const manager =
    await User.findById(
      managerId
    )
      .select(
        [
          "name",
          "userId",
          "mobile",
          "role",
          "referralCode",
          "isActive",
          "createdAt",
          "sellingPoints",
          "lifetimePurchase",
        ].join(" ")
      )
      .lean();


  if (!manager) {

    return null;

  }


  const users =
    await User.find()
      .select(
        [
          "_id",
          "name",
          "userId",
          "email",
          "mobile",
          "role",
          "referralCode",
          "sponsorId",
          "managerId",
          "isActive",
          "sellingPoints",
          "lifetimePurchase",
          "createdAt",
        ].join(" ")
      )
      .lean();


  const managerMembers =
    getManagerMembers(
      users,
      managerId
    );


  const memberIds =
    managerMembers.map(
      (member) =>
        member._id
    );


  const wallets =
    memberIds.length > 0
      ? await walletRepository
          .findWalletsByUsers(
            memberIds
          )
      : [];


  const walletMap =
    new Map();


  wallets.forEach(
    (wallet) => {

      if (
        wallet?.user
      ) {

        walletMap.set(
          String(
            wallet.user
          ),
          wallet
        );

      }

    }
  );


  // ---------------------------------------------------
  // CHILDREN MAP
  // ---------------------------------------------------

  const childrenMap =
    new Map();


  managerMembers.forEach(
    (member) => {

      const sponsorId =
        member.sponsorId
          ? String(
              member.sponsorId
            )
          : null;


      if (!sponsorId) {

        return;

      }


      if (
        !childrenMap.has(
          sponsorId
        )
      ) {

        childrenMap.set(
          sponsorId,
          []
        );

      }


      childrenMap
        .get(
          sponsorId
        )
        .push(
          member
        );

    }
  );


  childrenMap.forEach(
    (children) => {

      children.sort(
        (
          a,
          b
        ) =>
          new Date(
            a.createdAt || 0
          ) -
          new Date(
            b.createdAt || 0
          )
      );

    }
  );


  // ---------------------------------------------------
  // BUILD TREE NODE
  // ---------------------------------------------------

  const buildMemberNode =
    (
      member,
      level
    ) => {

      const memberId =
        String(
          member._id
        );


      const wallet =
        walletMap.get(
          memberId
        );


      const children =
        childrenMap.get(
          memberId
        ) || [];


      return {

        _id:
          member._id,

        id:
          member._id,

        userId:
          member.userId || "",

        name:
          member.name || "",

        email:
          member.email || "",

        mobile:
          member.mobile || "",

        role:
          member.role ||
          "MEMBER",

        referralCode:
          member.referralCode || "",

        sponsorId:
          member.sponsorId ||
          null,

        managerId:
          member.managerId ||
          null,

        isActive:
          member.isActive !== false,

        sellingPoints:
          Number(
            member.sellingPoints || 0
          ),

        lifetimePurchase:
          Number(
            member.lifetimePurchase || 0
          ),

        walletBalance:
          Number(
            wallet?.balance || 0
          ),

        wallet: {

          balance:
            Number(
              wallet?.balance || 0
            ),

          totalCommission:
            Number(
              wallet?.totalCommission || 0
            ),

          totalBonus:
            Number(
              wallet?.totalBonus || 0
            ),

          totalWithdrawn:
            Number(
              wallet?.totalWithdrawn || 0
            ),

        },

        createdAt:
          member.createdAt,

        level,

        children:
          children.map(
            (child) =>
              buildMemberNode(
                child,
                level + 1
              )
          ),

      };

    };


  // ---------------------------------------------------
  // ROOT MEMBERS
  // ---------------------------------------------------

  const rootMembers =
    managerMembers.filter(
      (member) => {

        const sponsorId =
          member.sponsorId
            ? String(
                member.sponsorId
              )
            : null;


        const managerIdValue =
          String(
            member.managerId || ""
          );


        return (
          sponsorId ===
            String(managerId) ||
          managerIdValue ===
            String(managerId)
        );

      }
    );


  return {

    _id:
      manager._id,

    id:
      manager._id,

    userId:
      manager.userId || "",

    name:
      manager.name || "",

    mobile:
      manager.mobile || "",

    role:
      manager.role ||
      "MANAGER",

    referralCode:
      manager.referralCode || "",

    isActive:
      manager.isActive !== false,

    sellingPoints:
      Number(
        manager.sellingPoints || 0
      ),

    lifetimePurchase:
      Number(
        manager.lifetimePurchase || 0
      ),

    walletBalance:
      0,

    level:
      0,

    children:
      rootMembers.map(
        (member) =>
          buildMemberNode(
            member,
            1
          )
      ),

  };

};


// =====================================================
// GET MANAGER PROFILE
// =====================================================

const getProfile = async (
  managerId
) => {

  return await User.findById(
    managerId
  )
    .select(
      "-password -otp -otpExpiry -resetPasswordToken -resetPasswordExpiry"
    );

};


// =====================================================
// GET MANAGER PRODUCTS
// =====================================================

const getManagerProducts = async () => {

  const products =
    await Product.find()
      .sort({
        createdAt: -1,
      })
      .lean();


  if (
    products.length === 0
  ) {

    return [];

  }


  const productIds =
    products.map(
      (product) =>
        product._id
    );


  // ---------------------------------------------------
  // FIND PAID ORDERS
  // ---------------------------------------------------

  const paidOrders =
    await Order.find({
      paymentStatus:
        "PAID",
    })
      .select(
        "_id"
      )
      .lean();


  const paidOrderIds =
    paidOrders.map(
      (order) =>
        order._id
    );


  // ---------------------------------------------------
  // SOLD ITEMS
  // ---------------------------------------------------

  const soldData =
    paidOrderIds.length > 0
      ? await OrderItem.aggregate([

          {
            $match: {

              orderId: {
                $in:
                  paidOrderIds,
              },

              productId: {
                $in:
                  productIds,
              },

            },

          },

          {
            $group: {

              _id:
                "$productId",

              soldItems: {

                $sum:
                  "$quantity",

              },

            },

          },

        ])
      : [];


  const soldMap =
    new Map();


  soldData.forEach(
    (item) => {

      soldMap.set(
        String(
          item._id
        ),

        Number(
          item.soldItems || 0
        )

      );

    }
  );


  return products.map(
    (product) => {

      const productId =
        String(
          product._id
        );


      const soldItems =
        Number(
          soldMap.get(
            productId
          ) || 0
        );


      const stock =
        Number(
          product.stock || 0
        );


      return {

        ...product,

        soldItems,

        remainingItems:
          Math.max(
            stock,
            0
          ),

      };

    }
  );

};


// =====================================================
// GET MANAGER COMMISSIONS
// =====================================================
//
// Returns commission records received by:
//
// 1. Manager
// 2. Every member in manager network
//
// receiverType makes the distinction explicit.
// =====================================================

const getManagerCommissions = async (
  managerId
) => {

  const manager =
    await User.findById(
      managerId
    ).lean();


  if (!manager) {

    throw new ApiError(
      404,
      "Manager not found"
    );

  }


  // ---------------------------------------------------
  // MANAGER NETWORK
  // ---------------------------------------------------

  const users =
    await User.find()
      .select(
        [
          "_id",
          "name",
          "userId",
          "email",
          "mobile",
          "role",
          "referralCode",
          "sponsorId",
          "managerId",
          "isActive",
        ].join(" ")
      )
      .lean();


  const members =
    getManagerMembers(
      users,
      managerId
    );


  const memberIds =
    members.map(
      (member) =>
        member._id
    );


  // ---------------------------------------------------
  // INCLUDE MANAGER
  // ---------------------------------------------------

  const receiverIds = [

    managerId,

    ...memberIds,

  ];


  // ---------------------------------------------------
  // REMOVE DUPLICATES
  // ---------------------------------------------------

  const uniqueReceiverIds =
    [
      ...new Set(
        receiverIds.map(
          (id) =>
            String(id)
        )
      ),
    ];


  // ---------------------------------------------------
  // GET COMMISSIONS
  // ---------------------------------------------------

  const commissions =
    await commissionRepository
      .findByReceivers(
        uniqueReceiverIds
      );


  // ---------------------------------------------------
  // FORMAT
  // ---------------------------------------------------

  return commissions.map(
    (commission) => {

      const receiver =
        commission.receiver;

      const seller =
        commission.fromUser;

      const order =
        commission.order;


      return {

        _id:
          commission._id,

        date:
          commission.createdAt,

        // ------------------------------------------------
        // RECEIVER TYPE
        // ------------------------------------------------

        receiverType:
          String(
            receiver?._id
          ) ===
          String(
            managerId
          )
            ? "MANAGER"
            : "MEMBER",


        // ------------------------------------------------
        // RECEIVER / MEMBER
        // ------------------------------------------------

        member: {

          id:
            receiver?._id ||
            null,

          name:
            receiver?.name ||
            "Unknown Member",

          userId:
            receiver?.userId ||
            "",

          referralCode:
            receiver?.referralCode ||
            "",

        },


        // ------------------------------------------------
        // SELLER
        // ------------------------------------------------

        seller: {

          id:
            seller?._id ||
            null,

          name:
            seller?.name ||
            "Unknown Member",

          userId:
            seller?.userId ||
            "",

          referralCode:
            seller?.referralCode ||
            "",

        },


        // ------------------------------------------------
        // ORDER
        // ------------------------------------------------

        order: {

          id:
            order?._id ||
            commission.order ||
            null,

          orderNumber:
            order?.orderNumber ||
            "",

          status:
            order?.status ||
            "",

          paymentStatus:
            order?.paymentStatus ||
            "",

        },


        // ------------------------------------------------
        // COMMISSION DETAILS
        // ------------------------------------------------

        level:
          Number(
            commission.level || 0
          ),

        percentage:
          Number(
            commission.percentage || 0
          ),

        joiningAmount:
          Number(
            commission.joiningAmount || 0
          ),

        commissionAmount:
          Number(
            commission.commissionAmount || 0
          ),

        status:
          commission.status ||
          "PENDING",

      };

    }
  );

};


// =====================================================
// EXPORTS
// =====================================================

module.exports = {

  getDashboard,

  getMembers,

  getMemberById,

  getMemberDetails,

  getReferralTree,

  getProfile,

  getManagerProducts,

  getManagerCommissions,

};