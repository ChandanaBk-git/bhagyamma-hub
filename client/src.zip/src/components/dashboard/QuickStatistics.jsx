import {
  Card,
  CardContent,
  Grid,
  Typography,
  Box,
} from "@mui/material";

import {
  Group,
  AccountTree,
  Layers,
} from "@mui/icons-material";

const QuickStatistics = ({ network = [] }) => {
  const getTotalMembers = (members) => {
    let total = 0;

    members.forEach((member) => {
      total += 1;

      if (member.children?.length) {
        total += getTotalMembers(member.children);
      }
    });

    return total;
  };

  const getMaxLevel = (members, level = 1) => {
    let max = level;

    members.forEach((member) => {
      if (member.children?.length) {
        const childLevel = getMaxLevel(
          member.children,
          level + 1
        );

        if (childLevel > max) {
          max = childLevel;
        }
      }
    });

    return max;
  };

  const stats = [
    {
      title: "Direct Members",
      value: network.length,
      icon: <Group fontSize="large" />,
      color: "#2E7D32",
    },
    {
      title: "Total Team",
      value: getTotalMembers(network),
      icon: <AccountTree fontSize="large" />,
      color: "#1976D2",
    },
    {
      title: "Total Levels",
      value:
        network.length === 0
          ? 0
          : getMaxLevel(network),
      icon: <Layers fontSize="large" />,
      color: "#ED6C02",
    },
  ];

  return (
    <Grid
      container
      spacing={2}
      sx={{ mt: 2 }}
    >
      {stats.map((item) => (
        <Grid
          item
          xs={12}
          sm={4}
          key={item.title}
        >
          <Card
            elevation={3}
            sx={{
              borderRadius: 3,
              height: "100%",
            }}
          >
            <CardContent>

              <Box
                sx={{
                  color: item.color,
                  mb: 2,
                }}
              >
                {item.icon}
              </Box>

              <Typography
                variant="body2"
                color="text.secondary"
              >
                {item.title}
              </Typography>

              <Typography
                variant="h4"
                fontWeight="bold"
              >
                {item.value}
              </Typography>

            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default QuickStatistics;