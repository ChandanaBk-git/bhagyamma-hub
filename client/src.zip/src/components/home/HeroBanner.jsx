
import {
  Box,
  Button,
  Container,
  Stack,
  Typography,
} from "@mui/material";
import { Link } from "react-router-dom";
import banner from "../../assets/banner/banner.jpg";

const HeroBanner = () => {
  return (
    <Box
      component="section"
      sx={{
        bgcolor: "#F3F7F1",
        py: { xs: 2, sm: 3, md: 4 },
        overflow: "hidden",
      }}
    >
      <Container maxWidth="xl">
        <Box
          sx={{
            position: "relative",
            minHeight: { xs: 340, sm: 390, md: 450 },
            display: "flex",
            alignItems: "center",
            overflow: "hidden",
            borderRadius: { xs: 3, md: 5 },
            bgcolor: "#E5EEDC",
            backgroundImage: {
              xs: `linear-gradient(90deg, rgba(243,247,241,.96) 0%, rgba(243,247,241,.85) 55%, rgba(243,247,241,.2) 100%), url(${banner})`,
              md: `linear-gradient(90deg, rgba(243,247,241,.97) 0%, rgba(243,247,241,.9) 35%, rgba(243,247,241,.12) 76%), url(${banner})`,
            },
            backgroundSize: "cover",
            backgroundPosition: "center",
            boxShadow: "0 8px 28px rgba(20,65,35,.08)",
          }}
        >
          <Container maxWidth="lg" sx={{ position: "relative", zIndex: 1 }}>
            <Stack
              spacing={{ xs: 2, md: 2.5 }}
              sx={{ maxWidth: { xs: "100%", sm: 440, md: 560 } }}
            >
              <Box
                sx={{
                  display: "inline-flex",
                  alignSelf: "flex-start",
                  alignItems: "center",
                  gap: 1,
                  px: 1.5,
                  py: 0.75,
                  borderRadius: 10,
                  bgcolor: "rgba(255,255,255,.85)",
                  color: "#17643A",
                  fontSize: 12,
                  fontWeight: 800,
                  letterSpacing: 1,
                }}
              >
                BHAGYAMMA HUB
              </Box>

              <Typography
                component="h1"
                sx={{
                  color: "#143D29",
                  fontSize: {
                    xs: "2rem",
                    sm: "2.8rem",
                    md: "3.6rem",
                  },
                  lineHeight: 1.08,
                  fontWeight: 800,
                  letterSpacing: "-1.5px",
                  maxWidth: 560,
                }}
              >
                Everyday Essentials.
                <Box component="span" sx={{ display: "block", color: "#247A42" }}>
                  Better Choices.
                </Box>
              </Typography>

              <Typography
                sx={{
                  color: "#405747",
                  fontSize: { xs: 14, sm: 16, md: 17 },
                  lineHeight: 1.8,
                  maxWidth: 450,
                }}
              >
                Discover products from Kisra and Vedgiri,
                with convenient shopping and a trusted
                customer experience.
              </Typography>

              <Stack
                direction="row"
                flexWrap="wrap"
                gap={1.5}
                sx={{ pt: 1 }}
              >
                <Button
                  component={Link}
                  to="/products"
                  variant="contained"
                  sx={{
                    bgcolor: "#176B3A",
                    color: "#fff",
                    px: 3.5,
                    py: 1.35,
                    borderRadius: 2,
                    textTransform: "none",
                    fontSize: 15,
                    fontWeight: 700,
                    boxShadow: "0 5px 14px rgba(23,107,58,.18)",
                    "&:hover": { bgcolor: "#10552D" },
                  }}
                >
                  Shop Products →
                </Button>

                <Button
                  component={Link}
                  to="/about"
                  variant="outlined"
                  sx={{
                    color: "#176B3A",
                    borderColor: "#176B3A",
                    px: 3,
                    py: 1.35,
                    borderRadius: 2,
                    textTransform: "none",
                    fontWeight: 700,
                    "&:hover": {
                      borderColor: "#10552D",
                      bgcolor: "rgba(23,107,58,.06)",
                    },
                  }}
                >
                  Discover Our Story
                </Button>
              </Stack>

              <Typography
                sx={{
                  color: "#52705A",
                  fontSize: 12,
                  fontWeight: 600,
                  pt: 0.5,
                }}
              >
                Explore • Discover • Shop with Confidence
              </Typography>
            </Stack>
          </Container>
        </Box>
      </Container>
    </Box>
  );
};

export default HeroBanner;
