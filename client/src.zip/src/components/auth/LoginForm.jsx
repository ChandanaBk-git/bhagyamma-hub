import { useState } from "react";

import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Checkbox,
  CircularProgress,
  Divider,
  FormControlLabel,
  IconButton,
  InputAdornment,
  Stack,
  TextField,
  Typography,
} from "@mui/material";

import {
  Visibility,
  VisibilityOff,
  LockOutlined,
  PersonOutline,
} from "@mui/icons-material";

import {
  Link,
  useNavigate,
} from "react-router-dom";

import { login } from "../../services/auth.service";

const LoginForm = () => {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const [showPassword, setShowPassword] =
    useState(false);

  const [rememberMe, setRememberMe] =
    useState(true);

  const [loading, setLoading] =
    useState(false);

  const [error, setError] =
    useState("");

  const handleChange = (e) => {
    setForm((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));

    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");

    if (!form.email.trim()) {
      setError(
        "Please enter your email address."
      );
      return;
    }

    if (!form.password) {
      setError(
        "Please enter your password."
      );
      return;
    }

    try {
      setLoading(true);

      const response = await login({
        email: form.email
          .trim()
          .toLowerCase(),

        password: form.password,
      });

      const token =
        response?.data?.token;

      const user =
        response?.data?.user;

      if (!token || !user) {
        setError(
          "Login response is incomplete. Please try again."
        );

        return;
      }

      /*
      ======================================================
      STORE AUTHENTICATION
      ======================================================
      */

      if (rememberMe) {
        localStorage.setItem(
          "token",
          token
        );

        localStorage.setItem(
          "user",
          JSON.stringify(user)
        );

        /*
        Remove old session data so that
        two authentication states do not
        exist at the same time.
        */

        sessionStorage.removeItem(
          "token"
        );

        sessionStorage.removeItem(
          "user"
        );
      } else {
        sessionStorage.setItem(
          "token",
          token
        );

        sessionStorage.setItem(
          "user",
          JSON.stringify(user)
        );

        /*
        Remove old localStorage auth.
        */

        localStorage.removeItem(
          "token"
        );

        localStorage.removeItem(
          "user"
        );
      }

      /*
      ======================================================
      IMPORTANT — GUEST CART MERGE EVENT
      ======================================================

      CartContext listens for this event.

      If the user had products in:

      bhagyamma_guest_cart

      CartContext will merge those products
      into the authenticated MongoDB cart.

      This event does NOT itself modify the cart.
      It only tells CartContext that login
      has completed successfully.
      */

      window.dispatchEvent(
        new Event("auth-login")
      );

      /*
      ======================================================
      ROLE BASED NAVIGATION
      ======================================================
      */

      switch (user.role) {
        case "SUPER_ADMIN":
          navigate(
            "/admin/dashboard"
          );
          break;

        case "MANAGER":
          navigate(
            "/manager/dashboard"
          );
          break;

        case "SUPERVISOR":
          navigate(
            "/member/dashboard"
          );
          break;

        case "MEMBER":
          navigate(
            "/member/dashboard"
          );
          break;

        default:
          navigate("/");
      }
    } catch (error) {
      console.error(
        "LOGIN ERROR:",
        error
      );

      setError(
        error?.response?.data
          ?.message ||
          error?.message ||
          "Unable to login. Please check your credentials."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box
      sx={{
        minHeight:
          "calc(100vh - 75px)",

        display: "flex",

        alignItems: "center",

        justifyContent: "center",

        px: 2,

        py: 5,

        background:
          "linear-gradient(135deg, #f5f8f3 0%, #ffffff 50%, #eef7ef 100%)",
      }}
    >
      <Card
        elevation={0}
        sx={{
          width: "100%",

          maxWidth: 460,

          borderRadius: 4,

          border:
            "1px solid #e5e7eb",

          boxShadow:
            "0 20px 50px rgba(0,0,0,0.08)",

          overflow: "hidden",
        }}
      >
        {/* ==================================================
            HEADER
        ================================================== */}

        <Box
          sx={{
            background:
              "linear-gradient(135deg, #2e7d32 0%, #43a047 100%)",

            color: "#fff",

            px: {
              xs: 3,
              sm: 4,
            },

            py: 4,

            textAlign: "center",
          }}
        >
          <Box
            sx={{
              width: 58,

              height: 58,

              mx: "auto",

              mb: 2,

              borderRadius: "50%",

              bgcolor:
                "rgba(255,255,255,0.16)",

              display: "flex",

              alignItems: "center",

              justifyContent: "center",
            }}
          >
            <PersonOutline
              sx={{
                fontSize: 30,
              }}
            />
          </Box>

          <Typography
            variant="h4"
            fontWeight={800}
            sx={{
              fontSize: {
                xs: "1.8rem",
                sm: "2.1rem",
              },
            }}
          >
            Welcome Back
          </Typography>

          <Typography
            sx={{
              mt: 1,

              color:
                "rgba(255,255,255,0.88)",

              fontSize: 14,
            }}
          >
            Login to your Bhagyamma Hub
            account
          </Typography>
        </Box>

        {/* ==================================================
            FORM CONTENT
        ================================================== */}

        <CardContent
          sx={{
            p: {
              xs: 3,
              sm: 4,
            },
          }}
        >
          {error && (
            <Alert
              severity="error"
              sx={{
                mb: 3,
                borderRadius: 2,
              }}
            >
              {error}
            </Alert>
          )}

          <Box
            component="form"
            onSubmit={handleSubmit}
            noValidate
          >
            <Stack spacing={2.2}>
              {/* EMAIL */}

              <TextField
                fullWidth
                label="Email Address"
                name="email"
                type="email"
                value={form.email}
                onChange={
                  handleChange
                }
                autoComplete="email"
                required
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <PersonOutline color="action" />
                    </InputAdornment>
                  ),
                }}
              />

              {/* PASSWORD */}

              <TextField
                fullWidth
                label="Password"
                name="password"
                type={
                  showPassword
                    ? "text"
                    : "password"
                }
                value={
                  form.password
                }
                onChange={
                  handleChange
                }
                autoComplete="current-password"
                required
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <LockOutlined color="action" />
                    </InputAdornment>
                  ),

                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() =>
                          setShowPassword(
                            (prev) =>
                              !prev
                          )
                        }
                        edge="end"
                        aria-label={
                          showPassword
                            ? "Hide password"
                            : "Show password"
                        }
                      >
                        {showPassword ? (
                          <VisibilityOff />
                        ) : (
                          <Visibility />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />

              {/* REMEMBER / FORGOT PASSWORD */}

              <Box
                sx={{
                  display: "flex",

                  alignItems:
                    "center",

                  justifyContent:
                    "space-between",

                  gap: 1,
                }}
              >
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={
                        rememberMe
                      }
                      onChange={(e) =>
                        setRememberMe(
                          e.target
                            .checked
                        )
                      }
                      color="success"
                      size="small"
                    />
                  }
                  label={
                    <Typography
                      fontSize={14}
                    >
                      Remember me
                    </Typography>
                  }
                />

                <Link
                  to="/forgot-password"
                  style={{
                    color:
                      "#2e7d32",

                    textDecoration:
                      "none",

                    fontSize: "14px",

                    fontWeight: 600,
                  }}
                >
                  Forgot password?
                </Link>
              </Box>

              {/* LOGIN BUTTON */}

              <Button
                fullWidth
                type="submit"
                variant="contained"
                color="success"
                size="large"
                disabled={loading}
                sx={{
                  mt: 1,

                  py: 1.5,

                  borderRadius: 2.5,

                  textTransform:
                    "none",

                  fontSize: 16,

                  fontWeight: 700,

                  boxShadow: "none",

                  "&:hover": {
                    boxShadow:
                      "none",
                  },
                }}
              >
                {loading ? (
                  <CircularProgress
                    size={24}
                    color="inherit"
                  />
                ) : (
                  "Login"
                )}
              </Button>
            </Stack>
          </Box>

          <Divider
            sx={{
              my: 3,
            }}
          />

          {/* REGISTER */}

          <Typography
            textAlign="center"
            color="text.secondary"
            fontSize={14}
          >
            Don't have an account?
          </Typography>

          <Button
            component={Link}
            to="/register"
            fullWidth
            variant="outlined"
            color="success"
            sx={{
              mt: 1.5,

              py: 1.25,

              borderRadius: 2.5,

              textTransform:
                "none",

              fontWeight: 700,
            }}
          >
            Create New Account
          </Button>
        </CardContent>
      </Card>
    </Box>
  );
};

export default LoginForm;