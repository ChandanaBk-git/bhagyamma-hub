import { useState } from "react";
import {
  Grid,
  TextField,
  Button,
  MenuItem,
  Box,
} from "@mui/material";

const ProductForm = ({ initialValues, onSubmit, loading }) => {
  const [form, setForm] = useState(
    initialValues || {
      productName: "",
      category: "",
      brand: "Bhagyamma Hub",
      description: "",
      benefits: "",
      ingredients: "",
      mrp: "",
      sellingPrice: "",
      stock: "",
      status: "Active",
      images: [],
    }
  );

  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleImageChange = (e) => {
    setForm((prev) => ({
      ...prev,
      images: Array.from(e.target.files),
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = new FormData();

    Object.keys(form).forEach((key) => {
      if (key !== "images") {
        formData.append(key, form[key]);
      }
    });

    form.images.forEach((image) => {
      formData.append("images", image);
    });

    onSubmit(formData);
  };

  return (
    <Box component="form" onSubmit={handleSubmit}>
      <Grid container spacing={3}>

        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            label="Product Name"
            name="productName"
            value={form.productName}
            onChange={handleChange}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            label="Category"
            name="category"
            value={form.category}
            onChange={handleChange}
          />
        </Grid>

        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Brand"
            name="brand"
            value={form.brand}
            onChange={handleChange}
          />
        </Grid>

        <Grid item xs={12}>
          <TextField
            multiline
            rows={3}
            fullWidth
            label="Description"
            name="description"
            value={form.description}
            onChange={handleChange}
          />
        </Grid>

        <Grid item xs={12}>
          <TextField
            multiline
            rows={3}
            fullWidth
            label="Benefits"
            name="benefits"
            value={form.benefits}
            onChange={handleChange}
          />
        </Grid>

        <Grid item xs={12}>
          <TextField
            multiline
            rows={3}
            fullWidth
            label="Ingredients"
            name="ingredients"
            value={form.ingredients}
            onChange={handleChange}
          />
        </Grid>

        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            type="number"
            label="MRP"
            name="mrp"
            value={form.mrp}
            onChange={handleChange}
          />
        </Grid>

        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            type="number"
            label="Selling Price"
            name="sellingPrice"
            value={form.sellingPrice}
            onChange={handleChange}
          />
        </Grid>

        <Grid item xs={12} md={4}>
          <TextField
            fullWidth
            type="number"
            label="Stock"
            name="stock"
            value={form.stock}
            onChange={handleChange}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <TextField
            select
            fullWidth
            label="Status"
            name="status"
            value={form.status}
            onChange={handleChange}
          >
            <MenuItem value="Active">Active</MenuItem>
            <MenuItem value="Inactive">Inactive</MenuItem>
          </TextField>
        </Grid>

        <Grid item xs={12} md={6}>
          <Button
            component="label"
            variant="outlined"
            fullWidth
          >
            Upload Images
            <input
              hidden
              multiple
              type="file"
              accept="image/*"
              onChange={handleImageChange}
            />
          </Button>
        </Grid>

        <Grid item xs={12}>
          <Button
            type="submit"
            variant="contained"
            size="large"
            disabled={loading}
          >
            {loading ? "Saving..." : "Save Product"}
          </Button>
        </Grid>

      </Grid>
    </Box>
  );
};

export default ProductForm;