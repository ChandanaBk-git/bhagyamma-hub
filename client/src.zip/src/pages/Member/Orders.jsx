import {
  Box,
  CircularProgress,
  Typography,
} from "@mui/material";

import { useEffect, useState } from "react";

import { getMyOrders } from "../../services/order.service";

import OrdersSummary from "../../components/members/orders/OrdersSummary";
import OrdersTable from "../../components/members/orders/OrdersTable";

const Orders = () => {

  const [orders, setOrders] = useState([]);

  const [loading, setLoading] = useState(true);

  useEffect(() => {

    loadOrders();

  }, []);

  const loadOrders = async () => {

    try {

      const data = await getMyOrders();

      setOrders(data);

    } catch (error) {

      console.error(error);

    } finally {

      setLoading(false);

    }

  };

  if (loading) {

    return (

      <Box
        height="70vh"
        display="flex"
        justifyContent="center"
        alignItems="center"
      >

        <CircularProgress color="success" />

      </Box>

    );

  }

  return (

    <Box
      sx={{
        p:3,
        bgcolor:"#F5F7FA",
        minHeight:"100vh",
      }}
    >

      <Typography
        variant="h4"
        fontWeight="bold"
        mb={3}
      >
        My Orders
      </Typography>

      <OrdersSummary
        orders={orders}
      />

      <OrdersTable
        orders={orders}
      />

    </Box>

  );

};

export default Orders;