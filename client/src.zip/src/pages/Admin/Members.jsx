import { useEffect, useState } from "react";
import {
  Container,
  Typography,
  Paper,
  Box,
  CircularProgress,
  Alert,
} from "@mui/material";

import { getAllMembers } from "../../services/admin.service";
import MemberSearch from "../../components/members/MemberSearch";
import MemberTable from "../../components/members/MemberTable";
import MemberDetails from "../pages/Admin/MemberDetails";

const Members = () => {
  const [members, setMembers] = useState([]);
  const [filteredMembers, setFilteredMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchMembers();
  }, []);

  const fetchMembers = async () => {
    try {
      setLoading(true);

      const response = await getAllMembers();

      setMembers(response.data);
      setFilteredMembers(response.data);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to fetch members."
      );
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        mt={8}
      >
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="xl">
      <Typography
        variant="h4"
        fontWeight={700}
        mb={3}
      >
        Members
      </Typography>

      {error && (
        <Alert severity="error">
          {error}
        </Alert>
      )}

      <Paper sx={{ p: 3 }}>
        <MemberSearch
          members={members}
          setFilteredMembers={setFilteredMembers}
        />

        <MemberTable
          members={filteredMembers}
        />
      </Paper>
    </Container>
  );
};

export default Members;