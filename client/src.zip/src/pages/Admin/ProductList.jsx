const ProductList = () => {
  return (
    <div style={{ padding: 20 }}>
      <h1>Product List Working ✅</h1>
    </div>
  );
};

export default ProductList;