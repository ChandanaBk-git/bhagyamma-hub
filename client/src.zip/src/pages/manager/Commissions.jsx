import {
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  Box,
  Card,
  Chip,
  CircularProgress,
  InputAdornment,
  MenuItem,
  Tab,
  Tabs,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Alert,
} from "@mui/material";

import SearchIcon from "@mui/icons-material/Search";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import PaidIcon from "@mui/icons-material/Paid";
import PendingIcon from "@mui/icons-material/Pending";
import ReceiptLongIcon from "@mui/icons-material/ReceiptLong";
import GroupsIcon from "@mui/icons-material/Groups";
import PersonIcon from "@mui/icons-material/Person";

import {
  getManagerCommissions,
} from "../../services/manager.service";


/* =====================================================
   MONEY FORMAT
===================================================== */

const money = (value) => {

  const amount =
    Number(value);

  const safeAmount =
    Number.isFinite(amount)
      ? amount
      : 0;

  return `₹${safeAmount.toLocaleString(
    "en-IN",
    {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    }
  )}`;

};


/* =====================================================
   DATE FORMAT
===================================================== */

const formatDate = (value) => {

  if (!value) {
    return "-";
  }

  const date =
    new Date(value);

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return "-";
  }

  return date.toLocaleDateString(
    "en-IN",
    {
      day: "2-digit",
      month: "short",
      year: "numeric",
    }
  );

};


/* =====================================================
   STATUS COLOR
===================================================== */

const getStatusColor = (
  status
) => {

  const value =
    String(
      status || ""
    ).toUpperCase();


  if (
    value === "PAID"
  ) {
    return "success";
  }


  if (
    value === "PENDING"
  ) {
    return "warning";
  }


  if (
    value === "CANCELLED" ||
    value === "REJECTED" ||
    value === "FAILED"
  ) {
    return "error";
  }


  return "default";

};


/* =====================================================
   SUMMARY CARD
===================================================== */

const SummaryCard = ({
  title,
  value,
  subtitle,
  icon,
  color,
}) => {

  return (

    <Card
      elevation={0}
      sx={{
        border:
          "1px solid #E5E7EB",

        borderRadius: 3,

        height: "100%",
      }}
    >

      <Box
        sx={{
          p: {
            xs: 1.5,
            sm: 2,
          },

          display: "flex",

          alignItems: "center",

          gap: 1.2,
        }}
      >

        <Box
          sx={{
            width: {
              xs: 42,
              sm: 48,
            },

            height: {
              xs: 42,
              sm: 48,
            },

            flexShrink: 0,

            borderRadius: 2,

            bgcolor:
              `${color}14`,

            color,

            display: "flex",

            alignItems: "center",

            justifyContent: "center",
          }}
        >
          {icon}
        </Box>


        <Box
          sx={{
            minWidth: 0,
          }}
        >

          <Typography
            fontSize={{
              xs: 10,
              sm: 11,
            }}
            color="text.secondary"
            noWrap
          >
            {title}
          </Typography>


          <Typography
            fontSize={{
              xs: 19,
              sm: 23,
            }}
            fontWeight={800}
            noWrap
          >
            {value}
          </Typography>


          <Typography
            fontSize={10}
            color="text.secondary"
            noWrap
          >
            {subtitle}
          </Typography>

        </Box>

      </Box>

    </Card>

  );

};


/* =====================================================
   PAGE
===================================================== */

const Commissions = () => {

  const [
    commissions,
    setCommissions,
  ] = useState([]);


  const [
    loading,
    setLoading,
  ] = useState(true);


  const [
    error,
    setError,
  ] = useState("");


  const [
    view,
    setView,
  ] = useState("MY");


  const [
    search,
    setSearch,
  ] = useState("");


  const [
    statusFilter,
    setStatusFilter,
  ] = useState("ALL");


  /* ===================================================
     LOAD DATA
  =================================================== */

  useEffect(() => {

    loadCommissions();

  }, []);


  const loadCommissions =
    async () => {

      try {

        setLoading(true);

        setError("");


        const response =
          await getManagerCommissions();


        const data =
          Array.isArray(
            response
          )
            ? response
            : Array.isArray(
                response?.data
              )
              ? response.data
              : [];


        setCommissions(
          data
        );

      } catch (
        requestError
      ) {

        console.error(
          "Manager commissions error:",
          requestError
        );


        setError(
          requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to load commission details."
        );

      } finally {

        setLoading(false);

      }

    };


  /* ===================================================
     SEPARATE MANAGER / NETWORK
  =================================================== */

  const myCommissions =
    useMemo(
      () => {

        return commissions.filter(
          (
            commission
          ) =>
            String(
              commission?.receiverType ||
              ""
            ).toUpperCase() ===
            "MANAGER"
        );

      },
      [
        commissions,
      ]
    );


  const networkCommissions =
    useMemo(
      () => {

        return commissions.filter(
          (
            commission
          ) =>
            String(
              commission?.receiverType ||
              ""
            ).toUpperCase() ===
            "MEMBER"
        );

      },
      [
        commissions,
      ]
    );


  /* ===================================================
     CURRENT DATASET
  =================================================== */

  const currentCommissions =
    useMemo(
      () => {

        if (
          view === "MY"
        ) {

          return myCommissions;

        }


        if (
          view === "NETWORK"
        ) {

          return networkCommissions;

        }


        return commissions;

      },
      [
        view,
        myCommissions,
        networkCommissions,
        commissions,
      ]
    );


  /* ===================================================
     SEARCH + STATUS FILTER
  =================================================== */

  const filteredCommissions =
    useMemo(
      () => {

        const searchValue =
          search
            .trim()
            .toLowerCase();


        return currentCommissions.filter(
          (
            commission
          ) => {

            const receiverName =
              String(
                commission?.member?.name ||
                ""
              ).toLowerCase();


            const receiverId =
              String(
                commission?.member?.userId ||
                ""
              ).toLowerCase();


            const sellerName =
              String(
                commission?.seller?.name ||
                ""
              ).toLowerCase();


            const sellerId =
              String(
                commission?.seller?.userId ||
                ""
              ).toLowerCase();


            const orderNumber =
              String(
                commission?.order?.orderNumber ||
                ""
              ).toLowerCase();


            const matchesSearch =
              !searchValue ||
              receiverName.includes(
                searchValue
              ) ||
              receiverId.includes(
                searchValue
              ) ||
              sellerName.includes(
                searchValue
              ) ||
              sellerId.includes(
                searchValue
              ) ||
              orderNumber.includes(
                searchValue
              );


            const commissionStatus =
              String(
                commission?.status ||
                ""
              ).toUpperCase();


            const matchesStatus =
              statusFilter ===
                "ALL" ||
              commissionStatus ===
                statusFilter;


            return (
              matchesSearch &&
              matchesStatus
            );

          }
        );

      },
      [
        currentCommissions,
        search,
        statusFilter,
      ]
    );


  /* ===================================================
     SUMMARY CALCULATOR
  =================================================== */

  const getSummary =
    (records) => {

      const total =
        records.reduce(
          (
            sum,
            item
          ) =>
            sum +
            Number(
              item?.commissionAmount ||
              0
            ),
          0
        );


      const paid =
        records
          .filter(
            (
              item
            ) =>
              String(
                item?.status ||
                ""
              ).toUpperCase() ===
              "PAID"
          )
          .reduce(
            (
              sum,
              item
            ) =>
              sum +
              Number(
                item?.commissionAmount ||
                0
              ),
            0
          );


      const pending =
        records
          .filter(
            (
              item
            ) =>
              String(
                item?.status ||
                ""
              ).toUpperCase() ===
              "PENDING"
          )
          .reduce(
            (
              sum,
              item
            ) =>
              sum +
              Number(
                item?.commissionAmount ||
                0
              ),
            0
          );


      return {
        total,
        paid,
        pending,
        transactions:
          records.length,
      };

    };


  /* ===================================================
     SUMMARY
  =================================================== */

  const summary =
    getSummary(
      currentCommissions
    );


  /* ===================================================
     NETWORK RECEIVERS
  =================================================== */

  const networkMembers =
    useMemo(
      () => {

        const ids =
          new Set();


        networkCommissions.forEach(
          (
            commission
          ) => {

            const id =
              commission?.member?.userId ||
              commission?.member?.id;


            if (id) {
              ids.add(
                String(id)
              );
            }

          }
        );


        return ids.size;

      },
      [
        networkCommissions,
      ]
    );


  /* ===================================================
     VIEW TITLES
  =================================================== */

  const pageTitle =
    view === "MY"
      ? "My Commission"
      : view === "NETWORK"
        ? "Network Commission"
        : "All Commission";


  const pageDescription =
    view === "MY"
      ? "Commission earned directly by the manager."
      : view === "NETWORK"
        ? "Commission earned by members in your network."
        : "Complete commission activity across your network.";


  /* ===================================================
     LOADING
  =================================================== */

  if (loading) {

    return (

      <Box
        sx={{
          minHeight: "60vh",

          display: "flex",

          alignItems:
            "center",

          justifyContent:
            "center",
        }}
      >

        <CircularProgress
          color="success"
        />

      </Box>

    );

  }


  return (

    <Box
      sx={{
        width: "100%",

        maxWidth: 1500,

        mx: "auto",

        minWidth: 0,

        overflowX: "hidden",
      }}
    >

      {/* =================================================
          HEADER
      ================================================= */}

      <Box
        sx={{
          mb: 2,
        }}
      >

        <Typography
          sx={{
            fontSize: {
              xs: 22,
              sm: 27,
              md: 30,
            },

            fontWeight: 800,
          }}
        >
          Commission Details
        </Typography>


        <Typography
          sx={{
            mt: 0.4,

            fontSize: {
              xs: 12,
              sm: 13,
            },

            color:
              "text.secondary",
          }}
        >
          {pageDescription}
        </Typography>

      </Box>


      {/* =================================================
          ERROR
      ================================================= */}

      {error && (

        <Alert
          severity="error"
          sx={{
            mb: 2,

            borderRadius: 2,
          }}
        >
          {error}
        </Alert>

      )}


      {/* =================================================
          COMMISSION VIEW TABS
      ================================================= */}

      <Card
        elevation={0}
        sx={{
          border:
            "1px solid #E5E7EB",

          borderRadius: 3,

          mb: 2,

          overflow: "hidden",
        }}
      >

        <Tabs
          value={view}
          onChange={(
            event,
            newValue
          ) => {

            setView(
              newValue
            );

            setSearch("");

            setStatusFilter(
              "ALL"
            );

          }}
          variant="fullWidth"
          sx={{
            minHeight: {
              xs: 52,
              sm: 58,
            },

            "& .MuiTab-root": {
              minHeight: {
                xs: 52,
                sm: 58,
              },

              fontSize: {
                xs: 10,
                sm: 12,
              },

              fontWeight: 700,

              textTransform:
                "none",
            },

            "& .Mui-selected": {
              color:
                "#15803D !important",
            },

            "& .MuiTabs-indicator": {
              backgroundColor:
                "#16A34A",
            },
          }}
        >

          <Tab
            value="MY"
            icon={
              <PersonIcon
                fontSize="small"
              />
            }
            iconPosition="start"
            label="My Commission"
          />


          <Tab
            value="NETWORK"
            icon={
              <GroupsIcon
                fontSize="small"
              />
            }
            iconPosition="start"
            label="Network Commission"
          />


          <Tab
            value="ALL"
            icon={
              <ReceiptLongIcon
                fontSize="small"
              />
            }
            iconPosition="start"
            label="All Commission"
          />

        </Tabs>

      </Card>


      {/* =================================================
          SUMMARY
      ================================================= */}

      <Box
        sx={{
          display: "grid",

          gridTemplateColumns: {
            xs: "1fr",
            sm:
              "repeat(2, minmax(0, 1fr))",
            md:
              "repeat(4, minmax(0, 1fr))",
          },

          gap: {
            xs: 1.3,
            sm: 2,
          },

          mb: 2,
        }}
      >

        <SummaryCard
          title={
            view === "MY"
              ? "My Commission"
              : view === "NETWORK"
                ? "Network Commission"
                : "Total Commission"
          }
          value={
            money(
              summary.total
            )
          }
          subtitle={
            view === "MY"
              ? "Earned by manager"
              : view === "NETWORK"
                ? "Earned by network members"
                : "Manager + network"
          }
          color="#2563EB"
          icon={
            <AccountBalanceWalletIcon />
          }
        />


        <SummaryCard
          title="Paid Commission"
          value={
            money(
              summary.paid
            )
          }
          subtitle="Successfully paid"
          color="#16A34A"
          icon={
            <PaidIcon />
          }
        />


        <SummaryCard
          title="Pending Commission"
          value={
            money(
              summary.pending
            )
          }
          subtitle="Awaiting payment"
          color="#EA580C"
          icon={
            <PendingIcon />
          }
        />


        <SummaryCard
          title={
            view === "NETWORK"
              ? "Network Members"
              : "Transactions"
          }
          value={
            view === "NETWORK"
              ? networkMembers
              : summary.transactions
          }
          subtitle={
            view === "NETWORK"
              ? "With commission records"
              : "Commission records"
          }
          color="#7C3AED"
          icon={
            view === "NETWORK"
              ? <GroupsIcon />
              : <ReceiptLongIcon />
          }
        />

      </Box>


      {/* =================================================
          FILTERS
      ================================================= */}

      <Card
        elevation={0}
        sx={{
          border:
            "1px solid #E5E7EB",

          borderRadius: 3,

          mb: 2,
        }}
      >

        <Box
          sx={{
            p: {
              xs: 1.5,
              sm: 2,
            },

            display: "grid",

            gridTemplateColumns: {
              xs: "1fr",
              sm:
                "1fr 1fr",
            },

            gap: 1.2,
          }}
        >

          <TextField
            fullWidth
            size="small"
            placeholder={
              view === "MY"
                ? "Search seller or order..."
                : "Search receiver, seller or order..."
            }
            value={
              search
            }
            onChange={(
              event
            ) =>
              setSearch(
                event.target.value
              )
            }
            InputProps={{
              startAdornment: (
                <InputAdornment
                  position="start"
                >
                  <SearchIcon
                    fontSize="small"
                  />
                </InputAdornment>
              ),
            }}
          />


          <TextField
            select
            fullWidth
            size="small"
            label="Commission Status"
            value={
              statusFilter
            }
            onChange={(
              event
            ) =>
              setStatusFilter(
                event.target.value
              )
            }
          >

            <MenuItem
              value="ALL"
            >
              All Status
            </MenuItem>


            <MenuItem
              value="PAID"
            >
              Paid
            </MenuItem>


            <MenuItem
              value="PENDING"
            >
              Pending
            </MenuItem>


            <MenuItem
              value="CANCELLED"
            >
              Cancelled
            </MenuItem>

          </TextField>

        </Box>

      </Card>


      {/* =================================================
          TABLE HEADER
      ================================================= */}

      <Box
        sx={{
          display: "flex",

          alignItems: "center",

          justifyContent:
            "space-between",

          gap: 1,

          mb: 1.2,
        }}
      >

        <Box>

          <Typography
            fontSize={{
              xs: 17,
              sm: 19,
            }}
            fontWeight={800}
          >
            {pageTitle} Ledger
          </Typography>


          <Typography
            fontSize={11}
            color="text.secondary"
          >
            {view === "MY"
              ? "Money earned directly by you"
              : view === "NETWORK"
                ? "Money earned by your network members"
                : "All commission transactions"}
          </Typography>

        </Box>


        <Typography
          fontSize={12}
          color="text.secondary"
          sx={{
            flexShrink: 0,
          }}
        >
          {filteredCommissions.length} result
          {filteredCommissions.length !== 1
            ? "s"
            : ""}
        </Typography>

      </Box>


      {/* =================================================
          EMPTY
      ================================================= */}

      {filteredCommissions.length === 0 ? (

        <Card
          elevation={0}
          sx={{
            border:
              "1px solid #E5E7EB",

            borderRadius: 3,
          }}
        >

          <Box
            sx={{
              py: 6,

              px: 2,

              textAlign: "center",
            }}
          >

            <ReceiptLongIcon
              sx={{
                fontSize: 48,

                color:
                  "text.disabled",

                mb: 1,
              }}
            />


            <Typography
              fontWeight={800}
            >
              No commission records found
            </Typography>


            <Typography
              fontSize={12}
              color="text.secondary"
            >
              No commission transactions match the current filters.
            </Typography>

          </Box>

        </Card>

      ) : (

        /* =================================================
           TABLE
        ================================================= */

        <Card
          elevation={0}
          sx={{
            border:
              "1px solid #E5E7EB",

            borderRadius: 3,

            overflow: "hidden",
          }}
        >

          <TableContainer
            sx={{
              width: "100%",

              overflowX: "auto",

              "&::-webkit-scrollbar": {
                height: 7,
              },

              "&::-webkit-scrollbar-thumb": {
                backgroundColor:
                  "#CBD5E1",

                borderRadius: 10,
              },
            }}
          >

            <Table
              sx={{
                minWidth:
                  view === "MY"
                    ? 950
                    : 1100,
              }}
            >

              <TableHead>

                <TableRow
                  sx={{
                    bgcolor:
                      "#F8FAFC",
                  }}
                >

                  <TableCell
                    sx={{
                      fontWeight: 800,
                      fontSize: 12,
                      whiteSpace:
                        "nowrap",
                    }}
                  >
                    Date
                  </TableCell>


                  <TableCell
                    sx={{
                      fontWeight: 800,
                      fontSize: 12,
                      whiteSpace:
                        "nowrap",
                    }}
                  >
                    Commission Receiver
                  </TableCell>


                  <TableCell
                    sx={{
                      fontWeight: 800,
                      fontSize: 12,
                      whiteSpace:
                        "nowrap",
                    }}
                  >
                    Sale By
                  </TableCell>


                  <TableCell
                    align="center"
                    sx={{
                      fontWeight: 800,
                      fontSize: 12,
                      whiteSpace:
                        "nowrap",
                    }}
                  >
                    Level
                  </TableCell>


                  <TableCell
                    align="center"
                    sx={{
                      fontWeight: 800,
                      fontSize: 12,
                      whiteSpace:
                        "nowrap",
                    }}
                  >
                    %
                  </TableCell>


                  <TableCell
                    align="right"
                    sx={{
                      fontWeight: 800,
                      fontSize: 12,
                      whiteSpace:
                        "nowrap",
                    }}
                  >
                    Sale Amount
                  </TableCell>


                  <TableCell
                    align="right"
                    sx={{
                      fontWeight: 800,
                      fontSize: 12,
                      whiteSpace:
                        "nowrap",
                    }}
                  >
                    Commission
                  </TableCell>


                  <TableCell
                    align="center"
                    sx={{
                      fontWeight: 800,
                      fontSize: 12,
                      whiteSpace:
                        "nowrap",
                    }}
                  >
                    Status
                  </TableCell>

                </TableRow>

              </TableHead>


              <TableBody>

                {filteredCommissions.map(
                  (
                    commission,
                    index
                  ) => {

                    const status =
                      String(
                        commission?.status ||
                        "PENDING"
                      ).toUpperCase();


                    return (

                      <TableRow
                        key={
                          commission?._id ||
                          index
                        }
                        hover
                        sx={{
                          "&:last-child td":
                            {
                              borderBottom: 0,
                            },
                        }}
                      >

                        {/* DATE */}

                        <TableCell
                          sx={{
                            whiteSpace:
                              "nowrap",
                          }}
                        >

                          <Typography
                            fontSize={12}
                            fontWeight={600}
                          >
                            {formatDate(
                              commission?.date
                            )}
                          </Typography>

                        </TableCell>


                        {/* RECEIVER */}

                        <TableCell>

                          <Typography
                            fontSize={13}
                            fontWeight={800}
                            noWrap
                          >
                            {
                              commission?.member?.name ||
                              "Unknown Member"
                            }
                          </Typography>


                          <Typography
                            fontSize={10}
                            color="text.secondary"
                            noWrap
                          >
                            {
                              commission?.member?.userId ||
                              "-"
                            }
                          </Typography>

                        </TableCell>


                        {/* SALE BY */}

                        <TableCell>

                          <Typography
                            fontSize={13}
                            fontWeight={700}
                            noWrap
                          >
                            {
                              commission?.seller?.name ||
                              "Unknown Member"
                            }
                          </Typography>


                          <Typography
                            fontSize={10}
                            color="text.secondary"
                            noWrap
                          >
                            {
                              commission?.seller?.userId ||
                              "-"
                            }
                          </Typography>

                        </TableCell>


                        {/* LEVEL */}

                        <TableCell
                          align="center"
                        >

                          <Chip
                            size="small"
                            label={
                              `Level ${
                                commission?.level ||
                                0
                              }`
                            }
                            sx={{
                              fontSize: 10,

                              fontWeight: 700,

                              bgcolor:
                                "#EEF2FF",

                              color:
                                "#4338CA",
                            }}
                          />

                        </TableCell>


                        {/* PERCENTAGE */}

                        <TableCell
                          align="center"
                        >

                          <Typography
                            fontSize={13}
                            fontWeight={800}
                          >
                            {
                              Number(
                                commission?.percentage ||
                                0
                              )
                            }%
                          </Typography>

                        </TableCell>


                        {/* SALE AMOUNT */}

                        <TableCell
                          align="right"
                        >

                          <Typography
                            fontSize={13}
                            fontWeight={700}
                          >
                            {
                              money(
                                commission?.joiningAmount
                              )
                            }
                          </Typography>

                        </TableCell>


                        {/* COMMISSION */}

                        <TableCell
                          align="right"
                        >

                          <Typography
                            fontSize={14}
                            fontWeight={800}
                            color="#15803D"
                          >
                            {
                              money(
                                commission?.commissionAmount
                              )
                            }
                          </Typography>

                        </TableCell>


                        {/* STATUS */}

                        <TableCell
                          align="center"
                        >

                          <Chip
                            size="small"
                            label={
                              status
                            }
                            color={
                              getStatusColor(
                                status
                              )
                            }
                            sx={{
                              fontSize: 10,

                              fontWeight: 700,
                            }}
                          />

                        </TableCell>

                      </TableRow>

                    );

                  }
                )}

              </TableBody>

            </Table>

          </TableContainer>

        </Card>

      )}


      {/* =================================================
          INFORMATION
      ================================================= */}

      <Alert
        severity="info"
        sx={{
          mt: 2,

          borderRadius: 2,

          fontSize: {
            xs: 11,
            sm: 13,
          },
        }}
      >

        <strong>
          My Commission
        </strong>{" "}
        shows only commissions received by the manager.
        <strong>
          {" "}Network Commission
        </strong>{" "}
        shows commissions received by members in the
        manager's network.
        <strong>
          {" "}All Commission
        </strong>{" "}
        combines both views.

      </Alert>

    </Box>

  );

};


export default Commissions;