import { useEffect, useState } from "react";

import {
  Box,
  Typography,
  Paper,
  Alert,
  CircularProgress,
} from "@mui/material";

import PeopleIcon from "@mui/icons-material/People";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import ShoppingBagIcon from "@mui/icons-material/ShoppingBag";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import Inventory2Icon from "@mui/icons-material/Inventory2";
import PendingActionsIcon from "@mui/icons-material/PendingActions";

/* =========================================================
   API
========================================================= */

const API_BASE_URL =
  import.meta.env.VITE_API_URL ||
  "http://localhost:5000/api/v1";

/* =========================================================
   DASHBOARD
========================================================= */

const Dashboard = () => {
  /* =======================================================
     STATE
  ======================================================= */

  const [dashboard, setDashboard] = useState({
    totalMembers: 0,
    activeMembers: 0,
    totalCommission: 0,
    totalOrders: 0,
    totalSales: 0,
    totalProducts: 0,
    pendingKyc: 0,
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  /* =======================================================
     FETCH MANAGER DASHBOARD
  ======================================================= */

  useEffect(() => {
    let mounted = true;

    const fetchDashboard = async () => {
      try {
        setLoading(true);
        setError("");

        const token = localStorage.getItem("token");

        if (!token) {
          throw new Error(
            "Authentication token not found."
          );
        }

        const response = await fetch(
          `${API_BASE_URL}/manager/dashboard`,
          {
            method: "GET",

            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );

        const result = await response.json();

        console.log(
          "MANAGER DASHBOARD API:",
          result
        );

        if (!response.ok) {
          throw new Error(
            result?.message ||
              "Failed to load manager dashboard."
          );
        }

        /* =================================================
           IMPORTANT

           Backend responses can be:

           1.
           {
             success: true,
             data: {
               summary: {...}
             }
           }

           OR

           2.
           {
             success: true,
             data: {
               totalMembers: 23,
               totalCommission: 2680,
               ...
             }
           }

           OR

           3.
           {
             success: true,
             dashboard: {...}
           }

           We handle all three safely.
        ================================================= */

const summary =
  result?.data?.summary || {};

console.log(
  "MANAGER DASHBOARD SUMMARY:",
  summary
);

        if (!mounted) {
          return;
        }

        /*
        =====================================================
        IMPORTANT BUSINESS RULES

        Manager dashboard should show:

        - Total Members
        - Total Commission
        - Total Orders
        - Total Sales
        - Products
        - Pending KYC

        Do NOT show:

        - Wallet Balance
        - Selling Points
        - Commission Summary
        - Network Summary
        =====================================================
        */

       setDashboard({
  totalMembers: Number(
    summary.totalMembers ?? 0
  ),

  activeMembers: Number(
    summary.activeMembers ?? 0
  ),

  totalCommission: Number(
    summary.totalCommission ?? 0
  ),

  totalOrders: Number(
    summary.totalOrders ?? 0
  ),

  totalSales: Number(
    summary.totalSales ?? 0
  ),

  totalProducts: Number(
    summary.totalProducts ?? 0
  ),

  pendingKyc: Number(
    summary.pendingKyc ?? 0
  ),
});

        /*
        =====================================================
        DO NOT SHOW FALSE ERROR

        The API returned successfully.
        Even if some individual values are zero,
        the dashboard itself is valid.
        =====================================================
        */

        setError("");
      } catch (err) {
        console.error(
          "Manager dashboard error:",
          err
        );

        if (mounted) {
          setError(
            err?.message ||
              "Unable to load manager dashboard."
          );
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    fetchDashboard();

    return () => {
      mounted = false;
    };
  }, []);

  /* =======================================================
     FORMAT NUMBER
  ======================================================= */

  const formatNumber = (value) => {
    return new Intl.NumberFormat("en-IN").format(
      Number(value) || 0
    );
  };

  /* =======================================================
     FORMAT CURRENCY
  ======================================================= */

  const formatCurrency = (value) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(Number(value) || 0);
  };

  /* =======================================================
     DASHBOARD CARDS
  ======================================================= */

  const cards = [
    {
      title: "Total Members",

      value: formatNumber(
        dashboard.totalMembers
      ),

      subtitle: `${formatNumber(
        dashboard.activeMembers
      )} active`,

      icon: <PeopleIcon />,

      iconBg: "#EAF6ED",

      iconColor: "#2E7D32",
    },

    {
      title: "Total Commission",

      value: formatCurrency(
        dashboard.totalCommission
      ),

      subtitle:
        "Commission earned by manager",

      icon: (
        <AccountBalanceWalletIcon />
      ),

      iconBg: "#EAF6ED",

      iconColor: "#2E7D32",
    },

    {
      title: "Total Orders",

      value: formatNumber(
        dashboard.totalOrders
      ),

      subtitle:
        "Orders from managed members",

      icon: <ShoppingBagIcon />,

      iconBg: "#EAF6ED",

      iconColor: "#2E7D32",
    },

    {
      title: "Total Sales",

      value: formatCurrency(
        dashboard.totalSales
      ),

      subtitle:
        "Total sales by managed members",

      icon: <TrendingUpIcon />,

      iconBg: "#EAF6ED",

      iconColor: "#2E7D32",
    },

    {
      title: "Products",

      value: formatNumber(
        dashboard.totalProducts
      ),

      subtitle: `${formatNumber(
        dashboard.totalProducts
      )} active`,

      icon: <Inventory2Icon />,

      iconBg: "#EAF6ED",

      iconColor: "#2E7D32",
    },

    {
      title: "Pending KYC",

      value: formatNumber(
        dashboard.pendingKyc
      ),

      subtitle:
        "Members requiring verification",

      icon: <PendingActionsIcon />,

      iconBg: "#FFF5E6",

      iconColor: "#FF9800",
    },
  ];

  /* =======================================================
     LOADING
  ======================================================= */

  if (loading) {
    return (
      <Box
        sx={{
          minHeight: "50vh",

          display: "flex",

          alignItems: "center",

          justifyContent: "center",
        }}
      >
        <CircularProgress
          sx={{
            color: "#2E7D32",
          }}
        />
      </Box>
    );
  }

  /* =======================================================
     PAGE
  ======================================================= */

  return (
    <Box
      sx={{
        width: "100%",

        maxWidth: 1600,

        mx: "auto",

        minWidth: 0,

        boxSizing: "border-box",

        overflowX: "hidden",
      }}
    >
      {/* =================================================
          HEADER
      ================================================= */}

      <Box
        sx={{
          mb: {
            xs: 3,
            sm: 4,
          },
        }}
      >
        <Typography
          component="h1"
          sx={{
            fontSize: {
              xs: 30,
              sm: 34,
              md: 38,
            },

            lineHeight: 1.15,

            fontWeight: 800,

            color: "#252525",

            mb: 1,
          }}
        >
          Manager Dashboard
        </Typography>

        <Typography
          sx={{
            fontSize: {
              xs: 15,
              sm: 16,
            },

            lineHeight: 1.6,

            color: "#666",

            maxWidth: 850,
          }}
        >
          Complete read-only overview of your
          managed members, commissions, orders,
          sales and products.
        </Typography>
      </Box>

      {/* =================================================
          ERROR
      ================================================= */}

      {error && (
        <Alert
          severity="error"
          sx={{
            mb: 3,
            borderRadius: 3,
          }}
        >
          {error}
        </Alert>
      )}

      {/* =================================================
          DASHBOARD CARDS

          1 column mobile
          2 columns tablet
          3 columns desktop

          ALL CARDS SAME SIZE
      ================================================= */}

      <Box
        sx={{
          display: "grid",

          gridTemplateColumns: {
            xs: "1fr",

            sm: "repeat(2, minmax(0, 1fr))",

            lg: "repeat(3, minmax(0, 1fr))",
          },

          gap: {
            xs: 2,

            sm: 2.5,

            md: 3,
          },

          width: "100%",

          minWidth: 0,

          alignItems: "stretch",
        }}
      >
        {cards.map((card) => (
          <Paper
            key={card.title}
            elevation={0}
            sx={{
              width: "100%",

              height: {
                xs: 160,
                sm: 175,
                md: 180,
              },

              minHeight: {
                xs: 160,
                sm: 175,
                md: 180,
              },

              borderRadius: 4,

              border:
                "1px solid #E2E5E8",

              bgcolor: "#FFFFFF",

              display: "flex",

              alignItems: "center",

              px: {
                xs: 2.5,
                sm: 3,
                md: 3.5,
              },

              boxSizing: "border-box",

              boxShadow:
                "0 8px 25px rgba(15,23,42,0.06)",

              overflow: "hidden",
            }}
          >
            {/* =================================================
                ICON
            ================================================= */}

            <Box
              sx={{
                width: {
                  xs: 60,
                  sm: 64,
                  md: 68,
                },

                height: {
                  xs: 60,
                  sm: 64,
                  md: 68,
                },

                minWidth: {
                  xs: 60,
                  sm: 64,
                  md: 68,
                },

                borderRadius: "50%",

                bgcolor:
                  card.iconBg,

                color:
                  card.iconColor,

                display: "flex",

                alignItems: "center",

                justifyContent: "center",

                mr: {
                  xs: 2,
                  sm: 2.5,
                },

                flexShrink: 0,

                "& svg": {
                  fontSize: {
                    xs: 30,
                    sm: 32,
                    md: 34,
                  },
                },
              }}
            >
              {card.icon}
            </Box>

            {/* =================================================
                TEXT
            ================================================= */}

            <Box
              sx={{
                minWidth: 0,

                flex: 1,
              }}
            >
              <Typography
                sx={{
                  fontSize: {
                    xs: 14,
                    sm: 15,
                    md: 16,
                  },

                  fontWeight: 500,

                  color: "#555",

                  mb: 0.7,

                  whiteSpace:
                    "nowrap",

                  overflow:
                    "hidden",

                  textOverflow:
                    "ellipsis",
                }}
              >
                {card.title}
              </Typography>

              <Typography
                sx={{
                  fontSize: {
                    xs: 28,
                    sm: 31,
                    md: 34,
                  },

                  lineHeight: 1.15,

                  fontWeight: 800,

                  color: "#252525",

                  mb: 0.8,

                  whiteSpace:
                    "nowrap",

                  overflow:
                    "hidden",

                  textOverflow:
                    "ellipsis",
                }}
              >
                {card.value}
              </Typography>

              <Typography
                sx={{
                  fontSize: {
                    xs: 12,
                    sm: 13,
                  },

                  color: "#666",

                  lineHeight: 1.4,

                  whiteSpace:
                    "nowrap",

                  overflow:
                    "hidden",

                  textOverflow:
                    "ellipsis",
                }}
              >
                {card.subtitle}
              </Typography>
            </Box>
          </Paper>
        ))}
      </Box>

      {/* =================================================
          READ ONLY NOTICE
      ================================================= */}

      <Paper
        elevation={0}
        sx={{
          mt: 3,

          p: {
            xs: 2,
            sm: 2.5,
          },

          borderRadius: 4,

          border:
            "1px solid #BFDBFE",

          bgcolor:
            "#EFF6FF",
        }}
      >
        <Typography
          sx={{
            fontSize: {
              xs: 13,
              sm: 14,
            },

            lineHeight: 1.6,

            color: "#163B63",
          }}
        >
          Manager access is read-only. Member,
          commission, order, referral and product
          details are available from the respective
          sidebar pages.
        </Typography>
      </Paper>
    </Box>
  );
};

export default Dashboard;