import {
  useEffect,
  useState,
} from "react";

import {
  useNavigate,
  useParams,
} from "react-router-dom";

import {
  Alert,
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  Divider,
  Grid,
  Stack,
  Typography,
} from "@mui/material";

import {
  ArrowBack,
  AccountBalanceWallet,
  Star,
  ReceiptLong,
  Payments,
  Groups,
  TrendingUp,
  History,
  AccountTree,
} from "@mui/icons-material";

import {
  getMemberDetails,
} from "../../services/manager.service";


/*
=========================================================
HELPERS
=========================================================
*/

const money = (
  value
) => {

  const number =
    Number(value || 0);

  return `₹${number.toLocaleString(
    "en-IN",
    {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    }
  )}`;

};


const dateFormat = (
  value
) => {

  if (!value) {
    return "-";
  }

  const date =
    new Date(value);

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return "-";
  }

  return date.toLocaleDateString(
    "en-IN",
    {
      day: "2-digit",
      month: "short",
      year: "numeric",
    }
  );

};


/*
=========================================================
SUMMARY CARD
=========================================================
*/

const SummaryCard = ({
  icon,
  title,
  value,
  subtitle,
}) => {

  return (

    <Card
      elevation={0}
      sx={{
        height: "100%",

        border:
          "1px solid #E5E7EB",

        borderRadius: 3,

        boxShadow:
          "0 2px 8px rgba(15,23,42,0.04)",
      }}
    >

      <CardContent
        sx={{
          p: {
            xs: 1.8,
            sm: 2.2,
          },

          "&:last-child": {
            pb: {
              xs: 1.8,
              sm: 2.2,
            },
          },
        }}
      >

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1.5,
          }}
        >

          <Box
            sx={{
              width: {
                xs: 40,
                sm: 46,
              },

              height: {
                xs: 40,
                sm: 46,
              },

              borderRadius: 2,

              bgcolor:
                "#EEF7EE",

              color:
                "#2E7D32",

              display: "flex",

              alignItems: "center",

              justifyContent: "center",

              flexShrink: 0,
            }}
          >
            {icon}
          </Box>


          <Box
            sx={{
              minWidth: 0,
            }}
          >

            <Typography
              sx={{
                fontSize: {
                  xs: 11,
                  sm: 12,
                },

                color:
                  "text.secondary",

                mb: 0.3,
              }}
            >
              {title}
            </Typography>


            <Typography
              sx={{
                fontSize: {
                  xs: 18,
                  sm: 21,
                },

                fontWeight: 800,

                lineHeight: 1.2,

                overflow: "hidden",

                textOverflow: "ellipsis",

                whiteSpace: "nowrap",
              }}
            >
              {value}
            </Typography>


            {subtitle && (
              <Typography
                sx={{
                  mt: 0.4,

                  fontSize: 11,

                  color:
                    "text.secondary",
                }}
              >
                {subtitle}
              </Typography>
            )}

          </Box>

        </Box>

      </CardContent>

    </Card>

  );

};


/*
=========================================================
SECTION CARD
=========================================================
*/

const SectionCard = ({
  title,
  children,
  action,
}) => {

  return (

    <Card
      elevation={0}
      sx={{
        border:
          "1px solid #E5E7EB",

        borderRadius: 3,

        overflow: "hidden",

        mb: 2,
      }}
    >

      <Box
        sx={{
          px: {
            xs: 1.8,
            sm: 2.5,
          },

          py: 1.6,

          display: "flex",

          alignItems: "center",

          justifyContent:
            "space-between",

          gap: 1,

          borderBottom:
            "1px solid #EEF0F2",

          bgcolor: "#fff",
        }}
      >

        <Typography
          sx={{
            fontSize: {
              xs: 16,
              sm: 18,
            },

            fontWeight: 800,

            color: "#172033",
          }}
        >
          {title}
        </Typography>

        {action}

      </Box>


      <Box
        sx={{
          p: {
            xs: 1.8,
            sm: 2.5,
          },
        }}
      >
        {children}
      </Box>

    </Card>

  );

};


/*
=========================================================
DETAIL ITEM
=========================================================
*/

const DetailItem = ({
  label,
  value,
  icon,
}) => {

  return (

    <Box
      sx={{
        display: "flex",

        alignItems: "flex-start",

        gap: 1.3,

        minWidth: 0,
      }}
    >

      <Box
        sx={{
          color: "#2E7D32",

          mt: 0.2,

          flexShrink: 0,

          display: "flex",
        }}
      >
        {icon}
      </Box>


      <Box
        sx={{
          minWidth: 0,
        }}
      >

        <Typography
          sx={{
            fontSize: 11,

            color:
              "text.secondary",

            mb: 0.3,
          }}
        >
          {label}
        </Typography>


        <Typography
          sx={{
            fontSize: {
              xs: 13,
              sm: 14,
            },

            fontWeight: 600,

            overflowWrap:
              "anywhere",

            wordBreak:
              "break-word",
          }}
        >
          {value || "-"}
        </Typography>

      </Box>

    </Box>

  );

};


/*
=========================================================
EMPTY STATE
=========================================================
*/

const EmptyState = ({
  text,
}) => {

  return (

    <Box
      sx={{
        py: 3,

        textAlign: "center",

        color:
          "text.secondary",
      }}
    >

      <Typography
        fontSize={13}
      >
        {text}
      </Typography>

    </Box>

  );

};


/*
=========================================================
PAGE
=========================================================
*/

const MemberDetails = () => {

  const {
    id,
  } = useParams();


  const navigate =
    useNavigate();


  const [
    data,
    setData,
  ] = useState(null);


  const [
    loading,
    setLoading,
  ] = useState(true);


  const [
    error,
    setError,
  ] = useState("");


  useEffect(
    () => {

      loadDetails();

    },
    [id]
  );


  const loadDetails =
    async () => {

      try {

        setLoading(true);

        setError("");


        const response =
          await getMemberDetails(
            id
          );


        setData(
          response?.data ||
          response
        );

      } catch (err) {

        console.error(
          "Member Details Error:",
          err
        );


        setError(
          err?.response?.data?.message ||
          "Unable to load member details."
        );

      } finally {

        setLoading(false);

      }

    };


  /*
  =======================================================
  LOADING
  =======================================================
  */

  if (loading) {

    return (

      <Box
        sx={{
          minHeight:
            "60vh",

          display:
            "flex",

          alignItems:
            "center",

          justifyContent:
            "center",
        }}
      >

        <CircularProgress
          color="success"
        />

      </Box>

    );

  }


  /*
  =======================================================
  ERROR
  =======================================================
  */

  if (error || !data) {

    return (

      <Box
        sx={{
          width: "100%",

          maxWidth: 700,

          mx: "auto",

          py: 3,
        }}
      >

        <Alert
          severity="error"
          sx={{
            borderRadius: 2,
            mb: 2,
          }}
        >
          {error ||
            "Member details not found."}
        </Alert>


        <Button
          variant="contained"
          color="success"
          startIcon={
            <ArrowBack />
          }
          onClick={() =>
            navigate(
              "/manager/members"
            )
          }
          sx={{
            borderRadius: 2,
          }}
        >
          Back to Members
        </Button>

      </Box>

    );

  }


  const member =
    data.member || {};


  const wallet =
    data.wallet || {};


  const commission =
    data.commissionSummary ||
    data.commission ||
    {};


  const sellingPoints =
    data.sellingPoints || {};


  const orderSummary =
    data.orderSummary ||
    data.orders ||
    {};


  const walletTransactions =
    Array.isArray(
      data.walletTransactions
    )
      ? data.walletTransactions
      : [];


  const withdrawals =
    Array.isArray(
      data.withdrawals
    )
      ? data.withdrawals
      : [];


  const commissions =
    Array.isArray(
      data.commissions
    )
      ? data.commissions
      : [];


  const sellingPointHistory =
    Array.isArray(
      data.sellingPointHistory
    )
      ? data.sellingPointHistory
      : [];


  const orders =
    Array.isArray(
      data.orders
    )
      ? data.orders
      : [];


  const downline =
    Array.isArray(
      data.downline
    )
      ? data.downline
      : [];


  return (

    <Box
      sx={{
        width: "100%",

        maxWidth: 1600,

        mx: "auto",

        minWidth: 0,

        overflowX: "hidden",
      }}
    >

      {/* =================================================
          TOP BAR
      ================================================= */}

      <Box
        sx={{
          display: "flex",

          flexDirection: {
            xs: "column",
            sm: "row",
          },

          alignItems: {
            xs: "stretch",
            sm: "center",
          },

          justifyContent:
            "space-between",

          gap: 1.5,

          mb: 2,
        }}
      >

        <Box
          sx={{
            minWidth: 0,
          }}
        >

          <Typography
            sx={{
              fontSize: {
                xs: 22,
                sm: 27,
                md: 30,
              },

              fontWeight: 800,

              lineHeight: 1.2,
            }}
          >
            Member Details
          </Typography>


          <Typography
            sx={{
              mt: 0.4,

              fontSize: {
                xs: 12,
                sm: 13,
              },

              color:
                "text.secondary",
            }}
          >
            Complete read-only member information
          </Typography>

        </Box>


        <Button
          variant="contained"
          color="success"
          startIcon={
            <ArrowBack />
          }
          onClick={() =>
            navigate(
              "/manager/members"
            )
          }
          sx={{
            alignSelf: {
              xs: "stretch",
              sm: "auto",
            },

            minHeight: 42,

            borderRadius: 2,

            whiteSpace: "nowrap",
          }}
        >
          Back to Members
        </Button>

      </Box>


      {/* =================================================
          MEMBER PROFILE
      ================================================= */}

      <Card
        elevation={0}
        sx={{
          border:
            "1px solid #E5E7EB",

          borderRadius: 3,

          mb: 2,

          overflow: "hidden",
        }}
      >

        <CardContent
          sx={{
            p: {
              xs: 2,
              sm: 2.5,
              md: 3,
            },

            "&:last-child": {
              pb: {
                xs: 2,
                sm: 2.5,
                md: 3,
              },
            },
          }}
        >

          <Box
            sx={{
              display: "flex",

              flexDirection: {
                xs: "column",
                sm: "row",
              },

              alignItems: {
                xs: "flex-start",
                sm: "center",
              },

              gap: 1.8,
            }}
          >

            <Avatar
              sx={{
                width: {
                  xs: 58,
                  sm: 70,
                },

                height: {
                  xs: 58,
                  sm: 70,
                },

                bgcolor: "#66BB6A",

                color: "#14532D",

                fontSize: {
                  xs: 24,
                  sm: 28,
                },

                fontWeight: 800,

                flexShrink: 0,
              }}
            >
              {(
                member.name ||
                "M"
              )
                .charAt(0)
                .toUpperCase()}
            </Avatar>


            <Box
              sx={{
                minWidth: 0,

                flex: 1,
              }}
            >

              <Typography
                sx={{
                  fontSize: {
                    xs: 20,
                    sm: 24,
                  },

                  fontWeight: 800,

                  overflowWrap:
                    "anywhere",
                }}
              >
                {member.name ||
                  "-"}
              </Typography>


              <Typography
                sx={{
                  fontSize: 13,

                  color:
                    "text.secondary",

                  mb: 1,
                }}
              >
                {member.userId ||
                  "-"}
              </Typography>


              <Stack
                direction="row"
                spacing={1}
                flexWrap="wrap"
                useFlexGap
              >

                <Chip
                  size="small"
                  label={
                    member.isActive
                      ? "Active"
                      : "Inactive"
                  }
                  color={
                    member.isActive
                      ? "success"
                      : "error"
                  }
                />


                <Chip
                  size="small"
                  label={
                    member.paymentStatus ||
                    "Pending"
                  }
                  color={
                    String(
                      member.paymentStatus ||
                      ""
                    ).toUpperCase() ===
                    "PAID"
                      ? "success"
                      : "warning"
                  }
                />

              </Stack>

            </Box>

          </Box>


          <Divider
            sx={{
              my: 2.5,
            }}
          />


          <Grid
            container
            spacing={{
              xs: 2,
              sm: 2.5,
            }}
          >

            <Grid
              item
              xs={12}
              sm={6}
              md={4}
            >
              <DetailItem
                label="Member ID"
                value={
                  member.userId
                }
                icon={
                  <Groups
                    fontSize="small"
                  />
                }
              />
            </Grid>


            <Grid
              item
              xs={12}
              sm={6}
              md={4}
            >
              <DetailItem
                label="Mobile"
                value={
                  member.mobile
                }
                icon={
                  <Payments
                    fontSize="small"
                  />
                }
              />
            </Grid>


            <Grid
              item
              xs={12}
              sm={6}
              md={4}
            >
              <DetailItem
                label="Email"
                value={
                  member.email
                }
                icon={
                  <ReceiptLong
                    fontSize="small"
                  />
                }
              />
            </Grid>


            <Grid
              item
              xs={12}
              sm={6}
              md={4}
            >
              <DetailItem
                label="Referral Code"
                value={
                  member.referralCode
                }
                icon={
                  <AccountTree
                    fontSize="small"
                  />
                }
              />
            </Grid>


            <Grid
              item
              xs={12}
              sm={6}
              md={4}
            >
              <DetailItem
                label="Sponsor"
                value={
                  member.sponsorId?.userId ||
                  member.sponsorId ||
                  "-"
                }
                icon={
                  <Groups
                    fontSize="small"
                  />
                }
              />
            </Grid>


            <Grid
              item
              xs={12}
              sm={6}
              md={4}
            >
              <DetailItem
                label="Joining Date"
                value={
                  dateFormat(
                    member.createdAt
                  )
                }
                icon={
                  <History
                    fontSize="small"
                  />
                }
              />
            </Grid>

          </Grid>

        </CardContent>

      </Card>


      {/* =================================================
          FINANCIAL SUMMARY
      ================================================= */}

      <Grid
        container
        spacing={{
          xs: 1.5,
          sm: 2,
        }}
        sx={{
          mb: 2,
        }}
      >

        <Grid
          item
          xs={12}
          sm={6}
          md={3}
        >
          <SummaryCard
            icon={
              <AccountBalanceWallet />
            }
            title="Wallet Balance"
            value={
              money(
                wallet.balance
              )
            }
            subtitle={
              `${wallet.transactionCount || 0} transactions`
            }
          />
        </Grid>


        <Grid
          item
          xs={12}
          sm={6}
          md={3}
        >
          <SummaryCard
            icon={
              <Star />
            }
            title="Selling Points"
            value={
              Number(
                sellingPoints.current ||
                0
              ).toLocaleString(
                "en-IN"
              )
            }
            subtitle={
              `${sellingPoints.transactionCount || 0} history records`
            }
          />
        </Grid>


        <Grid
          item
          xs={12}
          sm={6}
          md={3}
        >
          <SummaryCard
            icon={
              <TrendingUp />
            }
            title="Commission"
            value={
              money(
                commission.total
              )
            }
            subtitle={
              `${commission.transactionCount || 0} records`
            }
          />
        </Grid>


        <Grid
          item
          xs={12}
          sm={6}
          md={3}
        >
          <SummaryCard
            icon={
              <ReceiptLong />
            }
            title="Orders"
            value={
              orderSummary.total ||
              orders.length ||
              0
            }
            subtitle={
              money(
                orderSummary.totalPurchase
              )
            }
          />
        </Grid>

      </Grid>


      {/* =================================================
          WALLET + COMMISSION
      ================================================= */}

      <Grid
        container
        spacing={2}
      >

        <Grid
          item
          xs={12}
          md={6}
        >

          <SectionCard
            title="Wallet Summary"
          >

            <Grid
              container
              spacing={2}
            >

              <Grid
                item
                xs={6}
              >
                <DetailItem
                  label="Balance"
                  value={
                    money(
                      wallet.balance
                    )
                  }
                  icon={
                    <AccountBalanceWallet
                      fontSize="small"
                    />
                  }
                />
              </Grid>


              <Grid
                item
                xs={6}
              >
                <DetailItem
                  label="Total Commission"
                  value={
                    money(
                      wallet.totalCommission
                    )
                  }
                  icon={
                    <TrendingUp
                      fontSize="small"
                    />
                  }
                />
              </Grid>


              <Grid
                item
                xs={6}
              >
                <DetailItem
                  label="Bonus"
                  value={
                    money(
                      wallet.totalBonus
                    )
                  }
                  icon={
                    <Star
                      fontSize="small"
                    />
                  }
                />
              </Grid>


              <Grid
                item
                xs={6}
              >
                <DetailItem
                  label="Withdrawn"
                  value={
                    money(
                      wallet.totalWithdrawn
                    )
                  }
                  icon={
                    <Payments
                      fontSize="small"
                    />
                  }
                />
              </Grid>

            </Grid>

          </SectionCard>

        </Grid>


        <Grid
          item
          xs={12}
          md={6}
        >

          <SectionCard
            title="Commission Summary"
          >

            <Grid
              container
              spacing={2}
            >

              <Grid
                item
                xs={4}
              >
                <Typography
                  fontSize={11}
                  color="text.secondary"
                >
                  Total
                </Typography>

                <Typography
                  fontWeight={800}
                >
                  {money(
                    commission.total
                  )}
                </Typography>
              </Grid>


              <Grid
                item
                xs={4}
              >
                <Typography
                  fontSize={11}
                  color="text.secondary"
                >
                  Paid
                </Typography>

                <Typography
                  fontWeight={800}
                  color="success.main"
                >
                  {money(
                    commission.paid
                  )}
                </Typography>
              </Grid>


              <Grid
                item
                xs={4}
              >
                <Typography
                  fontSize={11}
                  color="text.secondary"
                >
                  Pending
                </Typography>

                <Typography
                  fontWeight={800}
                  color="warning.main"
                >
                  {money(
                    commission.pending
                  )}
                </Typography>
              </Grid>

            </Grid>

          </SectionCard>

        </Grid>

      </Grid>


      {/* =================================================
          ORDERS
      ================================================= */}

      <SectionCard
        title={`Order History (${orders.length})`}
      >

        {orders.length === 0 ? (

          <EmptyState
            text="No orders found for this member."
          />

        ) : (

          <Stack
            spacing={1.2}
          >

            {orders.map(
              (
                order,
                index
              ) => (

                <Box
                  key={
                    order._id ||
                    index
                  }
                  sx={{
                    p: 1.5,

                    border:
                      "1px solid #E5E7EB",

                    borderRadius: 2,

                    display: "grid",

                    gridTemplateColumns: {
                      xs: "1fr 1fr",
                      sm: "1.5fr 1fr 1fr 1fr",
                    },

                    gap: 1.2,

                    minWidth: 0,
                  }}
                >

                  <Box
                    sx={{
                      minWidth: 0,
                    }}
                  >

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Order
                    </Typography>

                    <Typography
                      fontSize={13}
                      fontWeight={700}
                      sx={{
                        overflowWrap:
                          "anywhere",
                      }}
                    >
                      {order.orderNumber ||
                        order._id ||
                        "-"}
                    </Typography>

                  </Box>


                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Amount
                    </Typography>

                    <Typography
                      fontSize={13}
                      fontWeight={700}
                    >
                      {money(
                        order.finalAmount
                      )}
                    </Typography>

                  </Box>


                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Payment
                    </Typography>

                    <Chip
                      size="small"
                      label={
                        order.paymentStatus ||
                        "Pending"
                      }
                      color={
                        String(
                          order.paymentStatus ||
                          ""
                        ).toUpperCase() ===
                        "PAID"
                          ? "success"
                          : "warning"
                      }
                    />

                  </Box>


                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Date
                    </Typography>

                    <Typography
                      fontSize={13}
                    >
                      {dateFormat(
                        order.createdAt
                      )}
                    </Typography>

                  </Box>

                </Box>

              )
            )}

          </Stack>

        )}

      </SectionCard>


      {/* =================================================
          COMMISSION HISTORY
      ================================================= */}

      <SectionCard
        title={`Commission History (${commissions.length})`}
      >

        {commissions.length === 0 ? (

          <EmptyState
            text="No commission records found."
          />

        ) : (

          <Stack
            spacing={1.2}
          >

            {commissions.map(
              (
                item,
                index
              ) => (

                <Box
                  key={
                    item._id ||
                    index
                  }
                  sx={{
                    p: 1.5,

                    border:
                      "1px solid #E5E7EB",

                    borderRadius: 2,

                    display: "grid",

                    gridTemplateColumns: {
                      xs: "1fr 1fr",
                      sm: "2fr 1fr 1fr",
                    },

                    gap: 1.2,
                  }}
                >

                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Description
                    </Typography>

                    <Typography
                      fontSize={13}
                      fontWeight={600}
                    >
                      {item.description ||
                        item.type ||
                        "Commission"}
                    </Typography>

                  </Box>


                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Amount
                    </Typography>

                    <Typography
                      fontSize={13}
                      fontWeight={800}
                      color="success.main"
                    >
                      {money(
                        item.commissionAmount
                      )}
                    </Typography>

                  </Box>


                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Status
                    </Typography>

                    <Chip
                      size="small"
                      label={
                        item.status ||
                        "Pending"
                      }
                      color={
                        String(
                          item.status ||
                          ""
                        ).toUpperCase() ===
                        "PAID"
                          ? "success"
                          : "warning"
                      }
                    />

                  </Box>

                </Box>

              )
            )}

          </Stack>

        )}

      </SectionCard>


      {/* =================================================
          WALLET TRANSACTIONS
      ================================================= */}

      <SectionCard
        title={`Wallet Transactions (${walletTransactions.length})`}
      >

        {walletTransactions.length === 0 ? (

          <EmptyState
            text="No wallet transactions found."
          />

        ) : (

          <Stack
            spacing={1.2}
          >

            {walletTransactions.map(
              (
                item,
                index
              ) => (

                <Box
                  key={
                    item._id ||
                    index
                  }
                  sx={{
                    p: 1.5,

                    border:
                      "1px solid #E5E7EB",

                    borderRadius: 2,

                    display: "grid",

                    gridTemplateColumns: {
                      xs: "1fr 1fr",
                      sm: "2fr 1fr 1fr",
                    },

                    gap: 1,
                  }}
                >

                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Type
                    </Typography>

                    <Typography
                      fontSize={13}
                      fontWeight={600}
                    >
                      {item.type ||
                        item.transactionType ||
                        "-"}
                    </Typography>

                  </Box>


                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Amount
                    </Typography>

                    <Typography
                      fontWeight={800}
                    >
                      {money(
                        item.amount
                      )}
                    </Typography>

                  </Box>


                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Date
                    </Typography>

                    <Typography
                      fontSize={12}
                    >
                      {dateFormat(
                        item.createdAt
                      )}
                    </Typography>

                  </Box>

                </Box>

              )
            )}

          </Stack>

        )}

      </SectionCard>


      {/* =================================================
          WITHDRAWALS
      ================================================= */}

      <SectionCard
        title={`Withdrawal History (${withdrawals.length})`}
      >

        {withdrawals.length === 0 ? (

          <EmptyState
            text="No withdrawal records found."
          />

        ) : (

          <Stack
            spacing={1.2}
          >

            {withdrawals.map(
              (
                item,
                index
              ) => (

                <Box
                  key={
                    item._id ||
                    index
                  }
                  sx={{
                    p: 1.5,

                    border:
                      "1px solid #E5E7EB",

                    borderRadius: 2,

                    display: "grid",

                    gridTemplateColumns: {
                      xs: "1fr 1fr",
                      sm: "1fr 1fr 1fr",
                    },

                    gap: 1,
                  }}
                >

                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Amount
                    </Typography>

                    <Typography
                      fontWeight={800}
                    >
                      {money(
                        item.amount
                      )}
                    </Typography>

                  </Box>


                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Status
                    </Typography>

                    <Chip
                      size="small"
                      label={
                        item.status ||
                        "Pending"
                      }
                    />

                  </Box>


                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Date
                    </Typography>

                    <Typography
                      fontSize={12}
                    >
                      {dateFormat(
                        item.createdAt
                      )}
                    </Typography>

                  </Box>

                </Box>

              )
            )}

          </Stack>

        )}

      </SectionCard>


      {/* =================================================
          SELLING POINT HISTORY
      ================================================= */}

      <SectionCard
        title={`Selling Point History (${sellingPointHistory.length})`}
      >

        {sellingPointHistory.length === 0 ? (

          <EmptyState
            text="No selling point history found."
          />

        ) : (

          <Stack
            spacing={1.2}
          >

            {sellingPointHistory.map(
              (
                item,
                index
              ) => (

                <Box
                  key={
                    item._id ||
                    index
                  }
                  sx={{
                    p: 1.5,

                    border:
                      "1px solid #E5E7EB",

                    borderRadius: 2,

                    display: "grid",

                    gridTemplateColumns: {
                      xs: "1fr 1fr",
                      sm: "2fr 1fr 1fr",
                    },

                    gap: 1,
                  }}
                >

                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Description
                    </Typography>

                    <Typography
                      fontSize={13}
                    >
                      {item.description ||
                        item.type ||
                        "Selling Points"}
                    </Typography>

                  </Box>


                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Points
                    </Typography>

                    <Typography
                      fontWeight={800}
                    >
                      {Number(
                        item.points ||
                        item.sellingPoints ||
                        item.amount ||
                        0
                      )}
                    </Typography>

                  </Box>


                  <Box>

                    <Typography
                      fontSize={11}
                      color="text.secondary"
                    >
                      Date
                    </Typography>

                    <Typography
                      fontSize={12}
                    >
                      {dateFormat(
                        item.createdAt
                      )}
                    </Typography>

                  </Box>

                </Box>

              )
            )}

          </Stack>

        )}

      </SectionCard>


      {/* =================================================
          DOWNLINE
      ================================================= */}

      <SectionCard
        title={`Direct Downline (${downline.length})`}
        action={
          <AccountTree
            color="success"
          />
        }
      >

        {downline.length === 0 ? (

          <EmptyState
            text="This member has no direct downline."
          />

        ) : (

          <Grid
            container
            spacing={1.5}
          >

            {downline.map(
              (
                item,
                index
              ) => (

                <Grid
                  item
                  xs={12}
                  sm={6}
                  md={4}
                  key={
                    item._id ||
                    index
                  }
                >

                  <Card
                    elevation={0}
                    sx={{
                      height: "100%",

                      border:
                        "1px solid #E5E7EB",

                      borderRadius: 2,
                    }}
                  >

                    <CardContent
                      sx={{
                        p: 1.7,

                        "&:last-child": {
                          pb: 1.7,
                        },
                      }}
                    >

                      <Box
                        sx={{
                          display:
                            "flex",

                          alignItems:
                            "center",

                          gap: 1.2,
                        }}
                      >

                        <Avatar
                          sx={{
                            width: 40,
                            height: 40,

                            bgcolor:
                              "#E8F5E9",

                            color:
                              "#2E7D32",

                            fontWeight: 800,
                          }}
                        >
                          {(
                            item.name ||
                            "M"
                          )
                            .charAt(0)
                            .toUpperCase()}
                        </Avatar>


                        <Box
                          sx={{
                            minWidth: 0,
                          }}
                        >

                          <Typography
                            fontWeight={700}
                            fontSize={14}
                            sx={{
                              overflowWrap:
                                "anywhere",
                            }}
                          >
                            {item.name ||
                              "-"}
                          </Typography>


                          <Typography
                            fontSize={11}
                            color="text.secondary"
                          >
                            {item.userId ||
                              "-"}
                          </Typography>

                        </Box>

                      </Box>


                      <Divider
                        sx={{
                          my: 1.2,
                        }}
                      />


                      <Typography
                        fontSize={12}
                      >
                        SP:{" "}
                        <strong>
                          {Number(
                            item.sellingPoints ||
                            0
                          )}
                        </strong>
                      </Typography>


                      <Typography
                        fontSize={12}
                        mt={0.5}
                      >
                        Status:{" "}

                        <strong>
                          {item.isActive
                            ? "Active"
                            : "Inactive"}
                        </strong>
                      </Typography>

                    </CardContent>

                  </Card>

                </Grid>

              )
            )}

          </Grid>

        )}

      </SectionCard>


      {/* =================================================
          READ ONLY NOTICE
      ================================================= */}

      <Alert
        severity="info"
        sx={{
          borderRadius: 2,

          mb: 2,

          fontSize: {
            xs: 11,
            sm: 13,
          },
        }}
      >
        Manager access is read-only. Member records,
        wallet information, commissions, orders and
        network information cannot be edited from this
        panel.
      </Alert>

    </Box>

  );

};


export default MemberDetails;