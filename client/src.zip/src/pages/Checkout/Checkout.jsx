import {
  Box,
  Button,
  Card,
  CardContent,
  Container,
  Divider,
  Grid,
  Stack,
  TextField,
  Typography,
  Alert,
} from "@mui/material";

import {
  ArrowBack,
  ShoppingBag,
  LockOutlined,
} from "@mui/icons-material";

import {
  useLocation,
  useNavigate,
} from "react-router-dom";

import {
  useState,
} from "react";

import { useCart } from "../../context/CartContext";

const Checkout = () => {
  const navigate = useNavigate();

  const location = useLocation();

  const { cart } = useCart();

  const [error, setError] =
    useState("");

  const [form, setForm] =
    useState({
      name: "",
      mobile: "",
      email: "",
      address: "",
      city: "",
      state: "",
      pincode: "",
    });

  /*
  ==========================================================
  CHECKOUT TYPE
  ==========================================================
  */

  const isMemberCheckout =
    location.pathname.startsWith(
      "/member/"
    );

  /*
  ==========================================================
  DELIVERY CHARGE
  ==========================================================
  */

  const DELIVERY_CHARGE = 50;

  /*
  ==========================================================
  FORM CHANGE
  ==========================================================
  */

  const handleChange = (
    event
  ) => {
    const {
      name,
      value,
    } = event.target;

    /*
    Keep mobile number numeric
    */

    if (name === "mobile") {
      const numericValue =
        value
          .replace(/\D/g, "")
          .slice(0, 10);

      setForm((previous) => ({
        ...previous,
        [name]: numericValue,
      }));

      setError("");

      return;
    }

    /*
    Keep pincode numeric
    */

    if (name === "pincode") {
      const numericValue =
        value
          .replace(/\D/g, "")
          .slice(0, 6);

      setForm((previous) => ({
        ...previous,
        [name]: numericValue,
      }));

      setError("");

      return;
    }

    setForm((previous) => ({
      ...previous,
      [name]: value,
    }));

    setError("");
  };

  /*
  ==========================================================
  BACK TO CART
  ==========================================================
  */

  const handleBack = () => {
    navigate(
      isMemberCheckout
        ? "/member/cart"
        : "/cart"
    );
  };

  /*
  ==========================================================
  VALIDATE DELIVERY DETAILS
  ==========================================================
  */

  const validateForm = () => {
    if (!form.name.trim()) {
      return "Please enter your full name.";
    }

    if (!form.mobile.trim()) {
      return "Please enter your mobile number.";
    }

    if (
      form.mobile.length !== 10
    ) {
      return "Please enter a valid 10-digit mobile number.";
    }

    if (!form.address.trim()) {
      return "Please enter your delivery address.";
    }

    if (!form.city.trim()) {
      return "Please enter your city.";
    }

    if (!form.state.trim()) {
      return "Please enter your state.";
    }

    if (
      form.pincode.length !== 6
    ) {
      return "Please enter a valid 6-digit pincode.";
    }

    if (
      form.email.trim() &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        form.email.trim()
      )
    ) {
      return "Please enter a valid email address.";
    }

    return "";
  };

  /*
  ==========================================================
  PAYMENT BUTTON
  ==========================================================

  PhonePe is intentionally disabled until:
  - GST is received
  - PhonePe merchant account is configured
  - Backend credentials are added
  ==========================================================
  */

  const handlePaymentClick = () => {
    const validationError =
      validateForm();

    if (validationError) {
      setError(
        validationError
      );

      return;
    }

    setError("");

    /*
    Payment intentionally disabled.

    We do NOT:
    - create an order
    - call PhonePe
    - call payment API

    until the gateway is configured.
    */

    console.log(
      "Payment gateway is currently under development."
    );
  };

  /*
  ==========================================================
  EMPTY CART
  ==========================================================
  */

  if (
    !cart ||
    !cart.items ||
    cart.items.length === 0
  ) {
    return (
      <Container
        maxWidth="md"
        sx={{
          py: 8,
          textAlign: "center",
        }}
      >
        <ShoppingBag
          sx={{
            fontSize: 80,
            color:
              "text.secondary",
            mb: 2,
          }}
        />

        <Typography
          variant="h5"
          fontWeight={700}
          gutterBottom
        >
          Your Cart is Empty
        </Typography>

        <Typography
          color="text.secondary"
          sx={{
            mb: 3,
          }}
        >
          Add products to your cart
          before proceeding to
          checkout.
        </Typography>

        <Button
          variant="contained"
          color="success"
          onClick={() =>
            navigate(
              isMemberCheckout
                ? "/member/products"
                : "/products"
            )
          }
          sx={{
            textTransform:
              "none",
            fontWeight: 700,
          }}
        >
          Continue Shopping
        </Button>
      </Container>
    );
  }

  /*
  ==========================================================
  CALCULATE TOTALS
  ==========================================================
  */

  const subtotal =
    Number(
      cart.totalAmount || 0
    );

  /*
  ₹50 delivery charge on every order
  */

  const deliveryCharge =
    DELIVERY_CHARGE;

  const grandTotal =
    subtotal +
    deliveryCharge;

  /*
  ==========================================================
  PAGE
  ==========================================================
  */

  return (
    <Container
      maxWidth="lg"
      sx={{
        py: {
          xs: 2,
          sm: 4,
          md: 5,
        },
      }}
    >
      {/* ==================================================
          HEADER
      ================================================== */}

      <Box sx={{ mb: 3 }}>
        <Button
          startIcon={
            <ArrowBack />
          }
          onClick={handleBack}
          sx={{
            color: "#2E7D32",
            textTransform:
              "none",
            fontWeight: 600,
            mb: 2,
          }}
        >
          Back to Cart
        </Button>

        <Typography
          variant="h4"
          fontWeight={700}
          sx={{
            fontSize: {
              xs: "1.7rem",
              sm: "2.1rem",
              md: "2.4rem",
            },
          }}
        >
          Checkout
        </Typography>

        <Typography
          color="text.secondary"
          sx={{
            mt: 0.5,
          }}
        >
          Enter your delivery
          details to continue.
        </Typography>
      </Box>

      {error && (
        <Alert
          severity="error"
          sx={{
            mb: 3,
            borderRadius: 2,
          }}
        >
          {error}
        </Alert>
      )}

      <Grid
        container
        spacing={{
          xs: 2,
          md: 4,
        }}
      >
        {/* ==================================================
            DELIVERY INFORMATION
        ================================================== */}

        <Grid
          item
          xs={12}
          md={7}
        >
          <Card
            elevation={2}
            sx={{
              borderRadius: 3,
            }}
          >
            <CardContent
              sx={{
                p: {
                  xs: 2,
                  sm: 3,
                  md: 4,
                },
              }}
            >
              <Typography
                variant="h6"
                fontWeight={700}
                gutterBottom
              >
                Delivery Information
              </Typography>

              <Divider
                sx={{
                  mb: 3,
                }}
              />

              {!isMemberCheckout && (
                <Alert
                  severity="info"
                  sx={{
                    mb: 3,
                    borderRadius: 2,
                  }}
                >
                  You can continue as a
                  guest. Login is not
                  required for checkout.
                  Your mobile number is
                  required for order
                  identification.
                </Alert>
              )}

              <Stack spacing={2.5}>
                {/* FULL NAME */}

                <TextField
                  fullWidth
                  required
                  label="Full Name"
                  name="name"
                  value={
                    form.name
                  }
                  onChange={
                    handleChange
                  }
                  autoComplete="name"
                />

                {/* MOBILE */}

                <TextField
                  fullWidth
                  required
                  label="Mobile Number"
                  name="mobile"
                  value={
                    form.mobile
                  }
                  onChange={
                    handleChange
                  }
                  placeholder="10-digit mobile number"
                  inputProps={{
                    maxLength: 10,
                    inputMode:
                      "numeric",
                  }}
                  autoComplete="tel"
                />

                {/* EMAIL */}

                <TextField
                  fullWidth
                  label="Email Address (Optional)"
                  name="email"
                  type="email"
                  value={
                    form.email
                  }
                  onChange={
                    handleChange
                  }
                  autoComplete="email"
                />

                {/* ADDRESS */}

                <TextField
                  fullWidth
                  required
                  multiline
                  minRows={3}
                  label="Delivery Address"
                  name="address"
                  value={
                    form.address
                  }
                  onChange={
                    handleChange
                  }
                  placeholder="House number, street, area"
                  autoComplete="street-address"
                />

                {/* CITY / STATE / PINCODE */}

                <Grid
                  container
                  spacing={2}
                >
                  <Grid
                    item
                    xs={12}
                    sm={4}
                  >
                    <TextField
                      fullWidth
                      required
                      label="City"
                      name="city"
                      value={
                        form.city
                      }
                      onChange={
                        handleChange
                      }
                      autoComplete="address-level2"
                    />
                  </Grid>

                  <Grid
                    item
                    xs={12}
                    sm={4}
                  >
                    <TextField
                      fullWidth
                      required
                      label="State"
                      name="state"
                      value={
                        form.state
                      }
                      onChange={
                        handleChange
                      }
                      autoComplete="address-level1"
                    />
                  </Grid>

                  <Grid
                    item
                    xs={12}
                    sm={4}
                  >
                    <TextField
                      fullWidth
                      required
                      label="Pincode"
                      name="pincode"
                      value={
                        form.pincode
                      }
                      onChange={
                        handleChange
                      }
                      placeholder="6-digit pincode"
                      inputProps={{
                        maxLength: 6,
                        inputMode:
                          "numeric",
                      }}
                      autoComplete="postal-code"
                    />
                  </Grid>
                </Grid>
              </Stack>
            </CardContent>
          </Card>
        </Grid>

        {/* ==================================================
            ORDER SUMMARY
        ================================================== */}

        <Grid
          item
          xs={12}
          md={5}
        >
          <Card
            elevation={2}
            sx={{
              borderRadius: 3,

              position: {
                xs: "static",
                md: "sticky",
              },

              top: 100,
            }}
          >
            <CardContent
              sx={{
                p: {
                  xs: 2,
                  sm: 3,
                },
              }}
            >
              <Typography
                variant="h6"
                fontWeight={700}
                gutterBottom
              >
                Order Summary
              </Typography>

              <Divider
                sx={{
                  mb: 2,
                }}
              />

              {/* CART ITEMS */}

              <Stack spacing={2}>
                {cart.items.map(
                  (item, index) => {
                    const product =
                      item.product;

                    const productId =
                      product?._id ||
                      item.productId ||
                      index;

                    const productName =
                      product?.productName ||
                      "Product";

                    const quantity =
                      Number(
                        item.quantity ||
                          0
                      );

                    const price =
                      Number(
                        item.price ||
                          product?.price ||
                          0
                      );

                    const itemTotal =
                      quantity *
                      price;

                    return (
                      <Box
                        key={
                          productId
                        }
                        sx={{
                          display:
                            "flex",
                          justifyContent:
                            "space-between",
                          gap: 2,
                        }}
                      >
                        <Box
                          sx={{
                            minWidth: 0,
                          }}
                        >
                          <Typography
                            fontWeight={
                              600
                            }
                            sx={{
                              wordBreak:
                                "break-word",
                            }}
                          >
                            {
                              productName
                            }
                          </Typography>

                          <Typography
                            variant="body2"
                            color="text.secondary"
                          >
                            Qty:{" "}
                            {
                              quantity
                            }
                          </Typography>
                        </Box>

                        <Typography
                          fontWeight={
                            600
                          }
                          sx={{
                            whiteSpace:
                              "nowrap",
                          }}
                        >
                          ₹
                          {itemTotal.toLocaleString(
                            "en-IN"
                          )}
                        </Typography>
                      </Box>
                    );
                  }
                )}
              </Stack>

              <Divider
                sx={{
                  my: 2,
                }}
              />

              {/* SUBTOTAL */}

              <Box
                display="flex"
                justifyContent="space-between"
                mb={1.5}
              >
                <Typography>
                  Subtotal
                </Typography>

                <Typography>
                  ₹
                  {subtotal.toLocaleString(
                    "en-IN"
                  )}
                </Typography>
              </Box>

              {/* DELIVERY */}

              <Box
                display="flex"
                justifyContent="space-between"
                mb={1.5}
              >
                <Typography>
                  Delivery Charges
                </Typography>

                <Typography
                  fontWeight={600}
                >
                  ₹
                  {deliveryCharge.toLocaleString(
                    "en-IN"
                  )}
                </Typography>
              </Box>

              <Typography
                variant="caption"
                color="text.secondary"
                sx={{
                  display: "block",
                  mb: 2,
                }}
              >
                A flat ₹50 delivery
                charge is applicable
                to every order.
              </Typography>

              <Divider
                sx={{
                  my: 2,
                }}
              />

              {/* GRAND TOTAL */}

              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                gap={2}
              >
                <Typography
                  variant="h6"
                  fontWeight={700}
                >
                  Grand Total
                </Typography>

                <Typography
                  variant="h6"
                  fontWeight={700}
                  color="success.main"
                  sx={{
                    whiteSpace:
                      "nowrap",
                  }}
                >
                  ₹
                  {grandTotal.toLocaleString(
                    "en-IN"
                  )}
                </Typography>
              </Box>

              {/* =================================================
                  PAYMENT UNDER DEVELOPMENT
              ================================================= */}

              <Box
                sx={{
                  mt: 3,
                  p: {
                    xs: 2,
                    sm: 2.5,
                  },
                  borderRadius: 3,
                  backgroundColor:
                    "#FFF8E1",
                  border:
                    "1px solid #FFE082",
                }}
              >
                <Box
                  sx={{
                    display:
                      "flex",
                    alignItems:
                      "center",
                    gap: 1,
                    mb: 1,
                  }}
                >
                  <LockOutlined
                    sx={{
                      color:
                        "#8D6E00",
                    }}
                  />

                  <Typography
                    sx={{
                      fontWeight: 700,
                      color:
                        "#8D6E00",
                      fontSize: {
                        xs: "1rem",
                        sm: "1.05rem",
                      },
                    }}
                  >
                    Online Payment
                  </Typography>
                </Box>

                <Typography
                  variant="body2"
                  sx={{
                    color:
                      "#6D5A00",
                    lineHeight: 1.6,
                  }}
                >
                  Our secure online
                  payment gateway is
                  currently under
                  development. Once
                  the payment gateway
                  is activated, you
                  will be able to
                  proceed with your
                  payment securely.
                </Typography>

                <Button
                  fullWidth
                  disabled
                  variant="contained"
                  sx={{
                    mt: 2,
                    py: 1.4,
                    borderRadius: 2,
                    textTransform:
                      "none",
                    fontWeight: 700,

                    "&.Mui-disabled":
                      {
                        backgroundColor:
                          "#BDBDBD",
                        color:
                          "#FFFFFF",
                      },
                  }}
                >
                  Payment Gateway Under
                  Development
                </Button>
              </Box>

              {/* SECURITY MESSAGE */}

              <Typography
                variant="body2"
                color="text.secondary"
                textAlign="center"
                sx={{
                  mt: 2,
                  lineHeight: 1.5,
                }}
              >
                Your payment will be
                securely processed once
                the online payment
                gateway is activated.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Checkout;