import api from "../api";

/*
=========================================================
GET MANAGER DASHBOARD
=========================================================
*/

export const getDashboard = async () => {
  const response = await api.get(
    "/manager/dashboard"
  );

  return response.data;
};


/*
=========================================================
GET MANAGER MEMBERS
=========================================================
*/

export const getMembers = async () => {
  const response = await api.get(
    "/manager/members"
  );

  return response.data;
};


/*
=========================================================
GET SINGLE MEMBER
=========================================================
*/

export const getMemberById = async (
  memberId
) => {
  const response = await api.get(
    `/manager/members/${memberId}`
  );

  return response.data;
};


/*
=========================================================
GET COMPLETE MEMBER DETAILS
=========================================================
*/

export const getMemberDetails = async (memberId) => {
  const response = await api.get(
    `/manager/members/${memberId}/details`
  );

  return response.data;
};


/*
=========================================================
GET MANAGER REFERRAL TREE
=========================================================
*/

export const getReferralTree = async () => {
  const response = await api.get(
    "/manager/referral-tree"
  );

  return response.data;
};


/*
=========================================================
GET MANAGER PROFILE
=========================================================
*/

export const getProfile = async () => {
  const response = await api.get(
    "/manager/profile"
  );

  return response.data;
};

export const getManagerOrders = async () => {

  const response =
    await api.get(
      "/orders/manager-orders"
    );

  return response.data;

};

// =====================================================
// MANAGER PRODUCTS
// =====================================================

export const getManagerProducts = async () => {

  const response =
    await api.get(
      "/manager/products"
    );

  return response.data;

};

// =====================================================
// MANAGER COMMISSIONS
// =====================================================

export const getManagerCommissions = async () => {

  const response =
    await api.get(
      "/manager/commissions"
    );

  return response.data;

};