import API from "../api";

// ===========================================
// Get All Products
// ===========================================
export const getProducts = async () => {
  try {
    const response = await API.get("/products?active=true");

    return response.data?.data || [];
  } catch (error) {
    console.error("Get Products Error:", error);

    throw (
      error.response?.data || {
        success: false,
        message: "Unable to fetch products.",
      }
    );
  }
};

// ===========================================
// Get Product By ID
// ===========================================
export const getProductById = async (id) => {
  try {
    const response = await API.get(`/products/${id}`);

    return response.data?.data || null;
  } catch (error) {
    console.error("Get Product Error:", error);

    throw (
      error.response?.data || {
        success: false,
        message: "Unable to fetch product.",
      }
    );
  }
};

// ===========================================
// Create Product
// ===========================================
export const createProduct = async (formData) => {
  try {
    const response = await API.post("/products", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    return response.data;
  } catch (error) {
    console.error("Create Product Error:", error);

    throw (
      error.response?.data || {
        success: false,
        message: "Unable to create product.",
      }
    );
  }
};

// ===========================================
// Update Product
// ===========================================
export const updateProduct = async (id, formData) => {
  try {
    const response = await API.put(`/products/${id}`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    return response.data;
  } catch (error) {
    console.error("Update Product Error:", error);

    throw (
      error.response?.data || {
        success: false,
        message: "Unable to update product.",
      }
    );
  }
};

// ===========================================
// Delete Product
// ===========================================
export const deleteProduct = async (id) => {
  try {
    const response = await API.delete(`/products/${id}`);

    return response.data;
  } catch (error) {
    console.error("Delete Product Error:", error);

    throw (
      error.response?.data || {
        success: false,
        message: "Unable to delete product.",
      }
    );
  }
};