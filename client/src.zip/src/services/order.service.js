import api from "../api";

/* ======================================================
   GET MY ORDERS
====================================================== */

export const getMyOrders = async () => {
  const response = await api.get(
    "/orders/my-orders"
  );

  return (
    response.data?.data || []
  );
};

/* ======================================================
   GET ORDER BY ID
====================================================== */

export const getOrderById = async (
  id
) => {
  const response = await api.get(
    `/orders/${id}`
  );

  return (
    response.data?.data || null
  );
};

/* ======================================================
   CREATE MEMBER ORDER
====================================================== */

export const createOrder = async (
  payload
) => {
  const response = await api.post(
    "/orders",
    payload
  );

  return (
    response.data?.data || null
  );
};

/* ======================================================
   CREATE GUEST ORDER
======================================================

   IMPORTANT:

   This endpoint does NOT require login.

   Guest checkout sends:

   name
   mobile
   email
   address
   city
   state
   pincode
   deliveryCharge
   items
====================================================== */

export const createGuestOrder =
  async (payload) => {
    const response =
      await api.post(
        "/orders/guest",
        payload
      );

    return (
      response.data?.data ||
      null
    );
  };

/* ======================================================
   CANCEL ORDER
====================================================== */

export const cancelOrder = async (
  id
) => {
  const response = await api.put(
    `/orders/${id}/cancel`
  );

  return (
    response.data?.data || null
  );
};