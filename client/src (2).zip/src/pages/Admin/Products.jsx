import { useEffect, useState } from "react";
import {
  Container,
  Typography,
  Paper,
  Button,
  Box,
  CircularProgress,
  Alert,
} from "@mui/material";
import { Add } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";

import ProductTable from "../../components/products/ProductTable";
import { getProducts } from "../../services/product.service";

const Products = () => {
  const navigate = useNavigate();

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchProducts = async () => {
    try {
      setLoading(true);

      const response = await getProducts();

      setProducts(response.data);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Failed to fetch products."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  if (loading)
    return (
      <Box display="flex" justifyContent="center" mt={6}>
        <CircularProgress />
      </Box>
    );

  return (
    <Container maxWidth="xl">

      <Box
        display="flex"
        justifyContent="space-between"
        mb={3}
      >
        <Typography variant="h4" fontWeight={700}>
          Products
        </Typography>

        <Button
          variant="contained"
          startIcon={<Add />}
          onClick={() => navigate("/admin/products/add")}
        >
          Add Product
        </Button>
      </Box>

      {error && (
        <Alert severity="error">{error}</Alert>
      )}

      <Paper sx={{ p: 2 }}>
        <ProductTable
          products={products}
          reload={fetchProducts}
        />
      </Paper>

    </Container>
  );
};

export default Products;