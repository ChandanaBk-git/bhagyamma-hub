import axios from "axios";

const API = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
});

API.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  return config;
});

export const getDashboard = async () => {
  const response = await API.get("/admin/dashboard");
  return response.data;
};

export const getAllMembers = async () => {
  const response = await API.get("/admin/users");
  return response.data;
};

export const getReferralTree = async () => {
  const response = await API.get("/admin/referral-tree");
  return response.data;
};

export const getMemberById = async (id) => {
  const response = await API.get(`/admin/users/${id}`);
  return response.data;
};