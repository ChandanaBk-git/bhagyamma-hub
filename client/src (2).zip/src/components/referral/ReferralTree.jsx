import { useEffect, useState } from "react";
import { getReferralTree } from "../../services/admin.service";
import ReferralNode from "./ReferralNode";

const ReferralTree = () => {
  const [tree, setTree] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReferralTree();
  }, []);

  const loadReferralTree = async () => {
    try {
      const response = await getReferralTree();
      setTree(response.data);
    } catch (error) {
      console.error("Referral Tree Error:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-4">
        <div className="spinner-border text-primary"></div>
      </div>
    );
  }

  if (tree.length === 0) {
    return (
      <div className="alert alert-warning">
        No referral data found.
      </div>
    );
  }

  return (
    <div className="referral-tree">
      {tree.map((node) => (
        <ReferralNode key={node._id} node={node} />
      ))}
    </div>
  );
};

export default ReferralTree;