import { useState } from "react";
import "./ReferralTree.css";

const ReferralNode = ({ node }) => {
  const [expanded, setExpanded] = useState(true);

  return (
    <div className="tree-node">

      <div
        className="member-card"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="member-header">
          <h5>{node.name}</h5>
          <span className={`role ${node.role.toLowerCase()}`}>
            {node.role}
          </span>
        </div>

        <div className="member-body">
          <p>
            <strong>User ID:</strong> {node.userId}
          </p>

          <p>
            <strong>Referral:</strong> {node.referralCode}
          </p>

          <p>
            <strong>Joined:</strong>{" "}
            {new Date(node.createdAt).toLocaleDateString()}
          </p>

          <p>
            <strong>Direct Referrals:</strong>{" "}
            {node.children?.length || 0}
          </p>
        </div>

        {node.children?.length > 0 && (
          <button className="toggle-btn">
            {expanded ? "− Collapse" : "+ Expand"}
          </button>
        )}
      </div>

      {expanded && node.children?.length > 0 && (
        <div className="children">
          {node.children.map((child) => (
            <ReferralNode
              key={child._id}
              node={child}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default ReferralNode;